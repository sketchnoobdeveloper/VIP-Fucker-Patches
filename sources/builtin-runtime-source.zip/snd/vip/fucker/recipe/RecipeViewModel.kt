package snd.vip.fucker.recipe

import android.app.Application
import android.net.Uri
import android.os.Build
import android.os.StatFs
import android.provider.DocumentsContract
import android.system.Os
import android.system.OsConstants
import android.util.AtomicFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import snd.vip.fucker.nonroot.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import kotlin.coroutines.coroutineContext

data class RecipeScreenState(val recipe: PatchRecipe? = null, val archive: ApkArchive? = null,
    val inputSha256: String? = null, val tryOtherBuild: Boolean = false, val acknowledged: Boolean = false,
    val busy: Boolean = false, val stage: Int = snd.vip.fucker.R.string.recipe_intro,
    val output: PatchOutput? = null, val error: String? = null,
    val catalogAcknowledged: Boolean = false, val catalogSaved: Boolean = false,
    val cancellable: Boolean = false)

/** A separate workspace: imported smali recipes never modify built-in LSPosed settings/profiles. */
class RecipeViewModel @JvmOverloads constructor(application: Application, workspace: String = "recipes") : AndroidViewModel(application) {
    init { require(workspace == "recipes" || workspace == "default-recipes") }
    private val context get() = getApplication<Application>()
    private val mutable = MutableStateFlow(RecipeScreenState())
    val state = mutable.asStateFlow()
    private var input: File? = null
    private var work: File? = null
    private var operation: Job? = null
    private val outputs = File(application.filesDir, "$workspace/outputs")
    private val index = AtomicFile(File(outputs, "last-success.json"))
    private fun readIndex() = index.openRead().use { stream ->
        ByteArrayOutputStream().also { ApkFiles.copy(stream, it, PatchReceipt.MAX_RECORD) }.toByteArray()
    }
    private fun sync(directory: File) {
        val descriptor = Os.open(directory.path, OsConstants.O_RDONLY, 0)
        try { Os.fsync(descriptor) } finally { Os.close(descriptor) }
    }
    private val store = NonRootStore(outputs, File(application.noBackupFilesDir, "$workspace/jobs"),
        ::readIndex, { bytes -> PatchJournal.commit(bytes, index::startWrite, index::finishWrite,
            index::failWrite, ::readIndex, { sync(outputs) }) }, ::sync)
    private fun StoredPatch.screen() = PatchOutput(file, receipt.packageName, receipt.version,
        receipt.sha256, receipt.signer, receipt)
    init { viewModelScope.launch {
        val previous = runInterruptible(Dispatchers.IO) {
            try { store.exclusive { recover(PatchOutputVerifier::verify)?.takeIf { it.receipt.kind == "smali-method-v1" }?.screen() } }
            catch (error: InterruptedException) { throw error }
            catch (_: Exception) { null }
        }
        mutable.update { if (it.output == null) it.copy(output = previous) else it }
    } }
    private fun launch(stage: Int, block: suspend () -> Unit) {
        if (mutable.value.busy) return
        mutable.update { it.copy(busy = true, cancellable = true, stage = stage, error = null) }
        operation = viewModelScope.launch {
            try { block() }
            catch (error: CancellationException) {
                mutable.update { it.copy(busy = false, cancellable = false, stage = snd.vip.fucker.R.string.nonroot_cancelled) }
                throw error
            }
            catch (error: Exception) { mutable.update { it.copy(busy = false, cancellable = false, error = (error.message ?: error.javaClass.simpleName).take(300)) } }
        }
    }
    fun cancel() {
        if (!mutable.value.busy || !mutable.value.cancellable) return
        mutable.update { it.copy(cancellable = false, stage = snd.vip.fucker.R.string.nonroot_cancelling) }
        operation?.cancel()
    }
    fun importRecipe(uri: Uri) {
        if (uri.scheme == "content") importRecipe { requireNotNull(context.contentResolver.openInputStream(uri)) }
    }
    fun openDefault(packageName: String) {
        val asset = snd.vip.fucker.core.Profiles.byPackage(packageName)?.directPatchAsset ?: return
        importRecipe(saved = true) { context.assets.open(asset) }
    }
    fun openSaved(sha256: String) = launch(snd.vip.fucker.R.string.recipe_reading) {
        val recipe = runInterruptible(Dispatchers.IO) { context.patchCatalog().load(sha256) }
        loaded(recipe, saved = true)
    }
    private fun loaded(recipe: PatchRecipe, saved: Boolean = false) {
        input = null
        mutable.update { it.copy(recipe = recipe, archive = null, inputSha256 = null, busy = false,
            tryOtherBuild = false, acknowledged = false, catalogAcknowledged = false, catalogSaved = saved,
            stage = snd.vip.fucker.R.string.recipe_pick_hint) }
    }
    private fun importRecipe(saved: Boolean = false, open: () -> InputStream) = launch(snd.vip.fucker.R.string.recipe_reading) {
        val recipe = runInterruptible(Dispatchers.IO) { open().use { stream ->
            val bytes = ByteArrayOutputStream().also { ApkFiles.copy(stream, it, PatchDocuments.MAX_BYTES.toLong()) }.toByteArray()
            PatchDocuments.parse(bytes)
        } }
        loaded(recipe, saved)
    }
    fun trustCatalog(value: Boolean) { if (!mutable.value.busy) mutable.update { it.copy(catalogAcknowledged = value) } }
    fun saveToTargets() {
        val current = mutable.value
        val recipe = current.recipe ?: return
        if (!current.catalogAcknowledged || current.catalogSaved) return
        launch(snd.vip.fucker.R.string.recipe_reading) {
            runInterruptible(Dispatchers.IO) { context.patchCatalog().add(recipe) }
            mutable.update { it.copy(busy = false, catalogSaved = true, stage = snd.vip.fucker.R.string.catalog_saved) }
        }
    }
    fun select(uri: Uri) {
        if (uri.scheme != "content") return
        selectInput { requireNotNull(context.contentResolver.openInputStream(uri)) }
    }
    fun selectInstalled() {
        val recipe = mutable.value.recipe ?: return
        selectInput {
            val app = context.packageManager.getApplicationInfo(recipe.packageName, 0)
            DirectPatchInputPolicy.requireInstalled(recipe.packageName, app.packageName, !app.splitSourceDirs.isNullOrEmpty(),
                app.flags and (android.content.pm.ApplicationInfo.FLAG_SYSTEM or
                    android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0)
            File(app.sourceDir).inputStream()
        }
    }
    private fun selectInput(open: () -> InputStream) {
        if (mutable.value.recipe == null) return
        if (mutable.value.busy) return
        mutable.update { it.copy(archive = null, inputSha256 = null, acknowledged = false, tryOtherBuild = false) }
        launch(snd.vip.fucker.R.string.nonroot_inspecting) {
            val recipe = requireNotNull(mutable.value.recipe)
            var directory: File? = null
            var accepted = false
            try {
                val selected = runInterruptible(Dispatchers.IO) { store.exclusive {
                    require(Build.VERSION.SDK_INT >= 28) { "Android 9+ required" }
                    work?.let(::removeJob)
                    work = null; input = null
                    val job = newJob().also { directory = it }
                    val target = File(job, "original.apk")
                    val available = StatFs(context.noBackupFilesDir.path).availableBytes - 64L * 1024 * 1024
                    require(available > 0) { "Not enough storage" }
                    open().use { stream ->
                        target.outputStream().use { ApkFiles.copy(stream, it, minOf(available, ApkFiles.MAX_APK)) }
                    }
                    val archive = ApkFiles.inspect(target)
                    require(!archive.patched && archive.packageName == recipe.packageName) { "Choose this recipe's original target APK" }
                    java.util.zip.ZipFile(target).use { require(it.getEntry(RecipeApkEngine.AUDIT) == null) { "Choose the unmodified original APK" } }
                    require(archive.minSdk <= Build.VERSION.SDK_INT) { "APK needs a newer Android version" }
                    require(archive.nativeAbis.isEmpty() || archive.nativeAbis.any { it in Build.SUPPORTED_ABIS }) { "APK ABI unsupported" }
                    Triple(target, archive, ApkFiles.digest(target))
                } }
                input = selected.first; work = directory
                accepted = true
                mutable.update { it.copy(archive = selected.second, inputSha256 = selected.third, busy = false,
                    acknowledged = false, tryOtherBuild = false, stage = snd.vip.fucker.R.string.recipe_review) }
            } finally {
                if (!accepted) withContext(NonCancellable + Dispatchers.IO) { store.exclusive { directory?.let(::removeJob) } }
            }
        }
    }
    fun tryOtherBuild(value: Boolean) { if (!mutable.value.busy) mutable.update { it.copy(tryOtherBuild = value, acknowledged = false) } }
    fun acknowledge(value: Boolean) { if (!mutable.value.busy) mutable.update { it.copy(acknowledged = value) } }
    fun patch() {
        val current = mutable.value
        val recipe = current.recipe ?: return
        val archive = current.archive ?: return
        val source = input ?: return
        if (!current.acknowledged || (!recipe.exact(archive, current.inputSha256 ?: "") && !current.tryOtherBuild)) return
        launch(snd.vip.fucker.R.string.recipe_building) {
            var prepared: StoredPatch? = null
            var committed = false
            try {
                runInterruptible(Dispatchers.IO) { store.exclusive {
                    val job = requireNotNull(work)
                    require(StatFs(context.noBackupFilesDir.path).availableBytes >= source.length() * 5 + 128L * 1024 * 1024) { "Not enough storage" }
                    val key = NonRootSigner.entry { context.assets.open(it) }
                    val engine = RecipeApkEngine(key)
                    prepared = prepare { pending, id ->
                        engine.patch(source, pending, recipe, current.tryOtherBuild, job)
                        val receipt = PatchReceipt(id, archive.packageName, archive.versionName, ApkFiles.digest(pending),
                            NonRootSigner.fingerprint(key), ApkFiles.digest(source), recipe.sha256,
                            archive.versionCode, pending.length(), "smali-method-v1", recipe.sha256)
                        PatchOutputVerifier.verify(pending, receipt)
                        receipt
                    }
                } }
                coroutineContext.ensureActive()
                mutable.update { it.copy(cancellable = false) }
                withContext(NonCancellable + Dispatchers.IO) { store.exclusive {
                    val output = requireNotNull(prepared)
                    commit(output); committed = true
                    mutable.update { it.copy(busy = false, output = output.screen(), stage = snd.vip.fucker.R.string.nonroot_ready) }
                } }
            } finally {
                if (!committed) withContext(NonCancellable + Dispatchers.IO) { store.exclusive { prepared?.let(::discard) } }
            }
        }
    }
    fun export(uri: Uri) {
        val output = mutable.value.output ?: return
        if (uri.scheme != "content") return
        launch(snd.vip.fucker.R.string.nonroot_verifying) {
            var opened = false
            try {
                runInterruptible(Dispatchers.IO) { store.exclusive {
                    PatchOutputVerifier.verify(output.file, output.receipt)
                    VerifiedApkExport.transfer(output.file, output.sha256,
                        { requireNotNull(context.contentResolver.openOutputStream(uri, "wt")).also { opened = true } },
                        { requireNotNull(context.contentResolver.openInputStream(uri)) })
                } }
                mutable.update { it.copy(busy = false, stage = snd.vip.fucker.R.string.nonroot_exported) }
            } catch (error: Exception) {
                if (opened) withContext(NonCancellable + Dispatchers.IO) {
                    runCatching { if (DocumentsContract.isDocumentUri(context, uri)) DocumentsContract.deleteDocument(context.contentResolver, uri) }
                }
                throw error
            }
        }
    }
}
