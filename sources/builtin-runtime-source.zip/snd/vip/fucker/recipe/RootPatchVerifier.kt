package snd.vip.fucker.recipe

import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile
import java.io.File
import java.io.InputStream
import java.io.ByteArrayOutputStream
import java.lang.reflect.Method
import java.lang.reflect.Modifier
import java.util.zip.ZipFile
import snd.vip.fucker.core.Profile

data class VerifiedRootOperation(val operation: RootHookOperation, val accessFlags: Int)

/** Read-only preflight; all selected hashes verified before any hook is installed. */
object RootPatchVerifier {
    fun bundled(module: File, profile: Profile): RootPatch = ZipFile(module).use { zip ->
        val asset = requireNotNull(profile.rootPatchAsset)
        require(asset.startsWith("root-patches/") && ".." !in asset)
        val entry = zip.entries().asSequence().filter { it.name == "assets/$asset" }.toList().single()
        require(entry.size in 1..RootPatchDocument.MAX_BYTES)
        val patch = zip.getInputStream(entry).use { RootPatchDocument.parse(bounded(it, RootPatchDocument.MAX_BYTES)) }
        require(patch.packageName == profile.packageName && patch.versionCode == profile.versionCode &&
            patch.versionName == profile.versionName && patch.apkSha256 == profile.apkSha256) { "Bundled patch/profile mismatch" }
        require(patch.operations.all { operation -> profile.actions.any { it.id == operation.action && it.available } }) {
            "Unregistered bundled action"
        }
        patch
    }

    fun verify(apk: File, operations: List<RootHookOperation>): List<VerifiedRootOperation> {
        require(operations.size in 1..32 && apk.isFile)
        return ZipFile(apk).use { zip ->
            // Always inspect original DEX, never the wrapper loader. HookOriginalApk binds
            // and temporarily materializes a nested original for the non-root route.
            require(zip.getEntry("assets/lspatch/origin.apk") == null) { "Root asset preflight requires original sourceDir" }
            require(zip.size() <= 30000)
            val results = linkedMapOf<RootHookOperation, VerifiedRootOperation>()
            operations.groupBy { it.dex }.forEach { (name, group) ->
                val entries = zip.entries().asSequence().filter { it.name == name }.toList()
                require(entries.size == 1) { "Missing/ambiguous DEX: $name" }
                val entry = entries.single()
                require(entry.size in 1..SmaliMethodEngine.MAX_DEX)
                val dex = zip.getInputStream(entry).use { DexBackedDexFile(null, bounded(it, SmaliMethodEngine.MAX_DEX.toInt())) }
                require(dex.classes.size <= 30000)
                group.forEach { operation ->
                    val cls = dex.classes.singleOrNull { it.type == operation.owner } ?: error("Missing/ambiguous class")
                    val method = cls.methods.singleOrNull { SmaliMethodEngine.selector(it) == operation.method }
                        ?: error("Missing/ambiguous method")
                    require(RecipeJson.digest(SmaliMethodEngine.canonical(cls, method).toByteArray()) == operation.originalSha256) {
                        "Original method changed; new reviewed patch required"
                    }
                    require(!Modifier.isAbstract(method.accessFlags) && !Modifier.isNative(method.accessFlags))
                    results[operation] = VerifiedRootOperation(operation, method.accessFlags)
                }
            }
            operations.map { results.getValue(it) }
        }
    }

    fun bounded(stream: InputStream, maximum: Int): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var count = 0
        while (true) {
            val read = stream.read(buffer)
            if (read < 0) break
            if (read == 0) continue
            count += read
            require(count <= maximum) { "Patch/DEX size budget exceeded" }
            output.write(buffer, 0, read)
        }
        require(count > 0)
        return output.toByteArray()
    }

    /** Resolve exact types without initializing target classes; inherited lookalikes rejected. */
    fun resolve(verified: VerifiedRootOperation, loader: ClassLoader): Method {
        val operation = verified.operation
        val types = RootPatchDocument.types(operation.method)
        fun type(descriptor: String): Class<*> = when (descriptor) {
            "Z" -> Boolean::class.javaPrimitiveType!!
            "B" -> Byte::class.javaPrimitiveType!!
            "C" -> Char::class.javaPrimitiveType!!
            "S" -> Short::class.javaPrimitiveType!!
            "I" -> Int::class.javaPrimitiveType!!
            "J" -> Long::class.javaPrimitiveType!!
            "F" -> Float::class.javaPrimitiveType!!
            "D" -> Double::class.javaPrimitiveType!!
            "V" -> Void.TYPE
            else -> Class.forName(if (descriptor.startsWith('[')) descriptor.replace('/', '.')
                else descriptor.drop(1).dropLast(1).replace('/', '.'), false, loader)
        }
        val cls = type(operation.owner)
        val method = cls.getDeclaredMethod(operation.method.substringBefore('('), *types.dropLast(1).map(::type).toTypedArray())
        require(method.returnType == type(types.last()) && !Modifier.isAbstract(method.modifiers) && !Modifier.isNative(method.modifiers))
        // ART may expose additional implementation flags; Java identity bits must match DEX.
        val mask = Modifier.methodModifiers()
        require((method.modifiers and mask) == (verified.accessFlags and mask)) { "Runtime method access/static mismatch" }
        return method
    }
}
