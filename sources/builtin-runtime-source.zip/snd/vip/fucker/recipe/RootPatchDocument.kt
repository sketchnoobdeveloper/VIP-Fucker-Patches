package snd.vip.fucker.recipe

import java.nio.ByteBuffer

enum class RootHookMode { RETURN_BOOLEAN, SCOPED_PREFERENCE_BOOLEAN }
data class RootHookOperation(val action: String, val mode: RootHookMode, val dex: String,
    val owner: String, val method: String, val originalSha256: String, val value: Boolean, val key: String? = null)
data class RootPatch(val id: String, val title: String, val detail: String, val packageName: String,
    val versionCode: Long, val versionName: String, val apkSha256: String, val operations: List<RootHookOperation>)

/** Bounded declarative root hooks, not arbitrary smali execution or online administrator trust. */
object RootPatchDocument {
    const val MAX_BYTES = 64 * 1024
    const val MAGIC = "# vip-root-patch 1"
    private val hash = Regex("[a-f0-9]{64}")
    private val owner = Regex("L[a-zA-Z0-9_$/]+;")
    private val dex = Regex("classes(?:[2-9]|[1-9][0-9]+)?\\.dex")
    private val id = Regex("[a-z0-9][a-z0-9._-]{0,127}")
    private val required = setOf("id", "title", "detail", "package", "version-code", "version-name", "apk-sha256")
    fun parse(bytes: ByteArray): RootPatch {
        require(bytes.size in 1..MAX_BYTES)
        val text = Charsets.UTF_8.newDecoder().decode(ByteBuffer.wrap(bytes)).toString()
        require('\u0000' !in text)
        val lines = text.replace("\r\n", "\n").lines().map(String::trim)
        require(lines.firstOrNull() == MAGIC) { "Expected $MAGIC" }
        val headers = linkedMapOf<String, String>()
        val operations = mutableListOf<RootHookOperation>()
        lines.drop(1).forEach { line ->
            if (line.isEmpty() || (line.startsWith('#') && !line.startsWith("# @"))) return@forEach
            require(line.startsWith("# @")) { "Root patch cannot contain executable code" }
            val directive = line.removePrefix("# @").substringBefore(' ')
            val value = line.removePrefix("# @$directive").trim()
            if (directive != "hook") {
                require(operations.isEmpty() && directive in required && directive !in headers && value.isNotEmpty())
                headers[directive] = value
            } else {
                require(headers.keys == required && operations.size < 32)
                val parts = value.split(Regex("\\s+"))
                require(parts.size in 7..8)
                val mode = when (parts[1]) {
                    "return-boolean" -> RootHookMode.RETURN_BOOLEAN
                    "scoped-preference-boolean" -> RootHookMode.SCOPED_PREFERENCE_BOOLEAN
                    else -> error("Unsupported root hook mode")
                }
                require(id.matches(parts[0]) && dex.matches(parts[2]) && owner.matches(parts[3]) && hash.matches(parts[5]))
                val types = types(parts[4])
                require(parts[6] in setOf("true", "false"))
                require(if (mode == RootHookMode.RETURN_BOOLEAN) types.last() == "Z" && parts.size == 7
                    else parts.size == 8 && parts[7].length in 1..128 && parts[7].all { it.isLetterOrDigit() || it in "._-" })
                operations += RootHookOperation(parts[0], mode, parts[2], parts[3], parts[4], parts[5], parts[6] == "true", parts.getOrNull(7))
            }
        }
        require(headers.keys == required && operations.isNotEmpty())
        require(id.matches(headers.getValue("id")))
        require(headers.getValue("title").length <= 160 && headers.getValue("detail").length <= 4096)
        require(headers.getValue("package").length <= 255 && Regex("[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+").matches(headers.getValue("package")))
        require(headers.getValue("version-name").length <= 128 && hash.matches(headers.getValue("apk-sha256")))
        val code = headers.getValue("version-code").toLong()
        require(code >= 0 && operations.map { Triple(it.dex, it.owner, it.method) }.distinct().size == operations.size)
        require(operations.filter { it.mode == RootHookMode.SCOPED_PREFERENCE_BOOLEAN }.map { it.key to it.value }.distinct().size <= 1)
        return RootPatch(headers.getValue("id"), headers.getValue("title"), headers.getValue("detail"), headers.getValue("package"),
            code, headers.getValue("version-name"), headers.getValue("apk-sha256"), operations)
    }

    /** Exact DEX prototype descriptors: parameters followed by return type. */
    fun types(selector: String): List<String> {
        require(selector.length in 4..512)
        val open = selector.indexOf('(')
        require(open > 0 && Regex("[a-zA-Z_$][a-zA-Z0-9_$-]*").matches(selector.take(open)))
        val close = selector.indexOf(')', open)
        require(close > open && close < selector.lastIndex && selector.indexOf('(', open + 1) < 0)
        fun decode(text: String, allowVoid: Boolean): List<String> {
            val result = mutableListOf<String>()
            var i = 0
            while (i < text.length) {
                val start = i
                while (i < text.length && text[i] == '[') i++
                require(i < text.length && i - start <= 255)
                if (text[i] == 'L') {
                    val end = text.indexOf(';', i)
                    require(end > i && owner.matches(text.substring(i, end + 1)))
                    i = end + 1
                } else {
                    require(text[i] in "ZBCSIJFD" || (allowVoid && text[i] == 'V' && i == start))
                    i++
                }
                result += text.substring(start, i)
            }
            return result
        }
        val params = decode(selector.substring(open + 1, close), false)
        val returns = decode(selector.substring(close + 1), true)
        require(params.size <= 32 && returns.size == 1)
        return params + returns
    }
}
