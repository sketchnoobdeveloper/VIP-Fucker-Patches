package snd.vip.fucker.recipe

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import java.io.File
import snd.vip.fucker.core.Profiles

// Android can expose the app's filesDir through a system-owned /data/user alias.
// Canonicalize that trusted base; PatchCatalog still rejects links in catalog entries.
fun Context.patchCatalog() = PatchCatalog(File(filesDir.canonicalFile, "recipes/catalog"),
    Profiles.categories.mapNotNull { it.directPatchAsset }.map { asset ->
        assets.open(asset).use { PatchDocuments.parse(RootPatchVerifier.bounded(it, PatchDocuments.MAX_BYTES)) }
    })

data class CatalogApp(val title: String, val version: String?, val code: Long, val icon: Bitmap?)

/** Display only: no rooted registration, source APK digest claim or settings authorization. */
@Suppress("DEPRECATION")
fun catalogApp(context: Context, packageName: String): CatalogApp? {
    val info = try { context.packageManager.getPackageInfo(packageName, 0) }
        catch (_: PackageManager.NameNotFoundException) { return null }
    val app = info.applicationInfo ?: return null
    val title = context.packageManager.getApplicationLabel(app).toString()
    val code = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
    val icon = runCatching {
        val drawable = context.packageManager.getApplicationIcon(app)
        Bitmap.createBitmap(144, 144, Bitmap.Config.ARGB_8888).also {
            drawable.setBounds(0, 0, 144, 144); drawable.draw(Canvas(it))
        }
    }.getOrNull()
    return CatalogApp(title, info.versionName, code, icon)
}
