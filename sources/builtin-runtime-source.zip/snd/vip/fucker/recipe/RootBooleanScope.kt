package snd.vip.fucker.recipe

/** Synchronous, key-filtered scopes. Never persists preferences or propagates across threads. */
class RootBooleanScope {
    private data class Frame(val token: Any, val key: String, val value: Boolean)
    private val frames = ThreadLocal<MutableList<Frame>>()
    fun enter(key: String, value: Boolean): Any {
        val token = Any()
        val stack = frames.get() ?: mutableListOf<Frame>().also(frames::set)
        stack += Frame(token, key, value)
        return token
    }
    fun leave(token: Any) {
        val stack = frames.get() ?: return
        val index = stack.indexOfLast { it.token === token }
        if (index >= 0) stack.removeAt(index)
        if (stack.isEmpty()) frames.remove()
    }
    fun result(key: Any?, original: Any?, threw: Boolean): Any? {
        if (threw || original !is Boolean || key !is String) return original
        return frames.get()?.lastOrNull { it.key == key }?.value ?: original
    }
}
