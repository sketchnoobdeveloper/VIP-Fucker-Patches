package snd.vip.fucker.recipe

import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption

data class CatalogSnapshot(val recipes: List<PatchRecipe>, val rejected: Int)

/** Private immutable, hash-addressed local files. Never authenticates an administrator. */
class PatchCatalog(private val directory: File, private val bundled: List<PatchRecipe> = emptyList()) {
    companion object {
        const val MAX_PATCHES = 64
        const val MAX_TOTAL_BYTES = 8L * 1024 * 1024
        private val lock = Any()
        private val filename = Regex("([a-f0-9]{64})\\.patch")
    }
    private fun root() {
        require(directory.isAbsolute && directory.canonicalFile == directory.absoluteFile) { "Unsafe catalog path" }
        require(directory.isDirectory || directory.mkdirs()) { "Cannot create patch catalog" }
    }
    fun snapshot(): CatalogSnapshot = synchronized(lock) {
        root()
        val files = requireNotNull(directory.listFiles()).filter { filename.matches(it.name) }
        require(files.size <= MAX_PATCHES) { "Catalog file limit exceeded" }
        require(files.sumOf { it.length() } <= MAX_TOTAL_BYTES) { "Catalog exceeds 8 MiB" }
        var rejected = 0
        val imported = files.mapNotNull { file ->
            runCatching {
                require(file.isFile && file.canonicalFile == file.absoluteFile && file.length() in 1..PatchDocuments.MAX_BYTES.toLong())
                val bytes = file.readBytes()
                require(RecipeJson.digest(bytes) == file.name.removeSuffix(".patch")) { "Catalog digest mismatch" }
                PatchDocuments.parse(bytes)
            }.getOrElse { rejected++; null }
        }
        CatalogSnapshot((bundled + imported).distinctBy { it.sha256 }.sortedWith(
            compareBy<PatchRecipe> { it.packageName }.thenBy { it.title }.thenByDescending { it.versionCode }), rejected)
    }
    fun load(sha256: String): PatchRecipe = snapshot().recipes.singleOrNull { it.sha256 == sha256 }
        ?: error("Saved patch missing or corrupt; import again")
    fun add(recipe: PatchRecipe): PatchRecipe = synchronized(lock) {
        root()
        val bytes = recipe.document.toByteArray(Charsets.UTF_8)
        val validated = PatchDocuments.parse(bytes)
        require(validated == recipe) { "Patch model differs from imported document" }
        if (bundled.any { it.sha256 == validated.sha256 }) return@synchronized validated
        val output = File(directory, "${validated.sha256}.patch")
        if (output.exists() && runCatching { load(validated.sha256) == validated }.getOrDefault(false)) return@synchronized validated
        require(output.exists() || requireNotNull(directory.listFiles()).count { filename.matches(it.name) } < MAX_PATCHES) { "Catalog full (64 patches)" }
        val retainedBytes = requireNotNull(directory.listFiles()).filter { filename.matches(it.name) && it != output }.sumOf { it.length() }
        require(retainedBytes + bytes.size <= MAX_TOTAL_BYTES) { "Catalog exceeds 8 MiB" }
        val temporary = File.createTempFile("import-", ".pending", directory)
        try {
            FileOutputStream(temporary).use { it.write(bytes); it.fd.sync() }
            Files.move(temporary.toPath(), output.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
            require(load(validated.sha256) == validated) { "Saved patch read-back mismatch" }
            validated
        } finally { temporary.delete() }
    }
}
