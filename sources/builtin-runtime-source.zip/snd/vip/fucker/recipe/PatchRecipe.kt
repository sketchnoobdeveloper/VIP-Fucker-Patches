package snd.vip.fucker.recipe

import org.json.JSONObject
import snd.vip.fucker.nonroot.ApkArchive
import java.security.MessageDigest

data class SmaliEdit(val find: String, val replace: String)
data class MethodPatch(val dex: String, val owner: String, val method: String,
    val expectedMethodSha256: String, val edits: List<SmaliEdit>, val replacementSmali: String? = null)
data class PatchRecipe(val id: String, val title: String, val detail: String, val packageName: String,
    val versionCode: Long, val versionName: String, val apkSha256: String,
    val operations: List<MethodPatch>, val document: String) {
    val sha256 get() = RecipeJson.digest(document.toByteArray(Charsets.UTF_8))
    fun exact(archive: ApkArchive, digest: String) = archive.packageName == packageName &&
        archive.versionCode == versionCode && archive.versionName == versionName && digest == apkSha256
    fun requireTarget(archive: ApkArchive, digest: String, tryOtherBuild: Boolean) {
        require(!archive.patched && archive.packageName == packageName) { "Recipe package mismatch or wrapped APK" }
        require(exact(archive, digest) || tryOtherBuild) { "Exact reference APK required; explicitly select Try other builds" }
    }
}

/** Local, explicitly reviewed code recipes, not trusted remote configuration or purchase receipts. */
object RecipeJson {
    const val MAX_BYTES = 256 * 1024
    private val hash = Regex("[a-f0-9]{64}")
    private val packagePattern = Regex("[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+")
    private val ownerPattern = Regex("L[a-zA-Z0-9_$/]+;")
    private val dexPattern = Regex("classes(?:[2-9]|[1-9][0-9]+)?\\.dex")
    private fun JSONObject.fields(vararg names: String) = require(keys().asSequence().toSet() == names.toSet()) {
        "Unknown or missing recipe fields"
    }
    private fun JSONObject.text(name: String, max: Int = 1024): String {
        val value = get(name)
        require(value is String && value.length in 1..max && '\u0000' !in value) { "Invalid recipe field: $name" }
        return value
    }
    fun digest(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
    fun parse(bytes: ByteArray): PatchRecipe {
        require(bytes.size in 1..MAX_BYTES) { "Recipe exceeds 256 KiB" }
        val text = Charsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(bytes)).toString()
        val root = JSONObject(text)
        root.fields("schema", "engine", "id", "title", "detail", "target", "operations")
        require(root.get("schema") == 1 && root.get("engine") == "smali-method-v1") { "Unsupported recipe engine/schema" }
        val target = root.getJSONObject("target")
        target.fields("package", "versionCode", "versionName", "apkSha256")
        val code = target.get("versionCode")
        require((code is Int || code is Long) && (code as Number).toLong() >= 0) { "Invalid reference versionCode" }
        val packageName = target.text("package", 255)
        require(packagePattern.matches(packageName) && packageName != "snd.vip.fucker") { "Invalid target package" }
        val apkHash = target.text("apkSha256")
        require(hash.matches(apkHash)) { "Invalid reference SHA-256" }
        val operations = root.getJSONArray("operations")
        require(operations.length() in 1..32) { "Expected 1–32 method operations" }
        val parsed = (0 until operations.length()).map { index ->
            val op = operations.getJSONObject(index)
            op.fields("dex", "class", "method", "expectedMethodSha256", "edits")
            val dex = op.text("dex", 32)
            val owner = op.text("class", 512)
            val method = op.text("method", 1024)
            require(dexPattern.matches(dex) && ownerPattern.matches(owner)) { "Invalid DEX/class selector" }
            require(method.contains('(') && method.contains(')') && method.none { it.isWhitespace() } &&
                !method.startsWith("<")) { "Invalid method selector; constructors are not supported" }
            val expected = op.text("expectedMethodSha256")
            require(hash.matches(expected)) { "Expected method SHA-256 required" }
            val edits = op.getJSONArray("edits")
            require(edits.length() in 1..16) { "Expected 1–16 exact edits per method" }
            MethodPatch(dex, owner, method, expected, (0 until edits.length()).map {
                val edit = edits.getJSONObject(it)
                edit.fields("find", "replace")
                SmaliEdit(edit.text("find", 32768), edit.text("replace", 32768)).also { change ->
                    require(change.find != change.replace) { "No-op edit" }
                }
            })
        }
        require(parsed.map { Triple(it.dex, it.owner, it.method) }.distinct().size == parsed.size) { "Duplicate method operation" }
        return PatchRecipe(root.text("id", 128).also { require(Regex("[a-z0-9][a-z0-9._-]*").matches(it)) },
            root.text("title", 160), root.text("detail", 4096), packageName, (code as Number).toLong(),
            target.text("versionName", 128), apkHash, parsed, text)
    }
}
