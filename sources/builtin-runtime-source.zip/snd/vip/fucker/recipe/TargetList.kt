package snd.vip.fucker.recipe

import snd.vip.fucker.core.Profile
import snd.vip.fucker.core.Profiles

/** One row per target, including imported patches for an already registered package. */
data class TargetListEntry(val key: String, val profile: Profile?, val patches: List<PatchRecipe>) {
    val packageName get() = profile?.packageName ?: patches.first().packageName
}

object TargetList {
    fun merge(patches: List<PatchRecipe>): List<TargetListEntry> {
        val grouped = patches.distinctBy { it.sha256 }.groupBy { it.packageName }
        val registered = Profiles.all.map { it.packageName }.toSet()
        val defaults = Profiles.categories.map { profile ->
            val packages = if (profile.hookFamily == "telegram") Profiles.telegramClients.map { it.packageName }
                else listOf(profile.packageName)
            TargetListEntry(profile.id, profile, packages.flatMap { grouped[it].orEmpty() })
        }
        return defaults + grouped.filterKeys { it !in registered }.toSortedMap().map { (pkg, recipes) ->
            TargetListEntry("imported_$pkg", null, recipes)
        }
    }
}
