package snd.vip.fucker.recipe

import com.android.tools.smali.baksmali.Adaptors.ClassDefinition
import com.android.tools.smali.baksmali.Adaptors.MethodDefinition
import com.android.tools.smali.baksmali.BaksmaliOptions
import com.android.tools.smali.baksmali.formatter.BaksmaliWriter
import com.android.tools.smali.dexlib2.DexFileFactory
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile
import com.android.tools.smali.dexlib2.iface.ClassDef
import com.android.tools.smali.dexlib2.iface.Method
import com.android.tools.smali.dexlib2.immutable.ImmutableClassDef
import com.android.tools.smali.dexlib2.immutable.ImmutableMethod
import com.android.tools.smali.dexlib2.writer.io.FileDataStore
import com.android.tools.smali.dexlib2.writer.pool.DexPool
import com.android.tools.smali.smali.Smali
import com.android.tools.smali.smali.SmaliOptions
import java.io.File
import java.io.StringWriter

/** Offline literal edits or complete replacement methods; never executes target/patch code. */
object SmaliMethodEngine {
    const val MAX_DEX = 64L * 1024 * 1024
    fun selector(method: Method) = method.name + "(" + method.parameterTypes.joinToString("") + ")" + method.returnType
    fun canonical(owner: ClassDef, method: Method): String {
        val implementation = requireNotNull(method.implementation) { "Native/abstract method cannot be edited" }
        require(implementation.instructions.count() <= 20000) { "Method instruction budget exceeded" }
        val options = BaksmaliOptions().apply { debugInfo = false; accessorComments = false }
        val classDefinition = ClassDefinition(options, owner)
        val output = StringWriter()
        BaksmaliWriter(output).use { writer -> MethodDefinition(classDefinition, method, implementation).writeTo(writer) }
        require(!classDefinition.hadValidationErrors()) { "Invalid original method" }
        return normalize(output.toString()).also { require(it.length <= 256 * 1024) { "Method text budget exceeded" } }
    }
    fun normalize(text: String) = text.replace("\r\n", "\n").lines().map(String::trim)
        .filter { it.isNotEmpty() && !it.startsWith('#') }.joinToString("\n", postfix = "\n")
    fun edited(source: String, patch: MethodPatch): String {
        require(RecipeJson.digest(source.toByteArray(Charsets.UTF_8)) == patch.expectedMethodSha256) {
            "Original method changed: ${patch.owner}->${patch.method}; obtain a new recipe"
        }
        patch.replacementSmali?.let { replacement ->
            require(patch.edits.isEmpty()) { "Mixed method replacement and literal edits" }
            val result = normalize(replacement)
            require(result != source && result.length <= 256 * 1024) { "No-op or oversized method replacement" }
            return result
        }
        var result = source
        patch.edits.forEach { edit ->
            val find = normalize(edit.find).trimEnd('\n')
            val replace = normalize(edit.replace).trimEnd('\n')
            require(find.isNotEmpty() && find != replace)
            val at = result.indexOf(find)
            require(at >= 0 && result.indexOf(find, at + 1) < 0) { "Edit must match exactly once: ${patch.method}" }
            result = result.replaceRange(at, at + find.length, replace)
            require(result.length <= 256 * 1024) { "Edited method text budget exceeded" }
        }
        return result
    }
    fun rewrite(input: File, output: File, patches: List<MethodPatch>, scratch: File) {
        require(input.length() in 1..MAX_DEX && !output.exists() && patches.isNotEmpty())
        require(patches.size <= 32 && patches.map { it.owner to it.method }.distinct().size == patches.size)
        if (Thread.currentThread().isInterrupted) throw InterruptedException()
        val dex = DexFileFactory.loadDexFile(input, null)
        require(dex.classes.size <= 30000) { "DEX class budget exceeded" }
        val replacements = linkedMapOf<Pair<String, String>, Method>()
        // Validate every selector/hash/literal before assembling or writing the resulting DEX.
        val prepared = patches.map { patch ->
            val owner = dex.classes.singleOrNull { it.type == patch.owner } ?: error("Missing/ambiguous class: ${patch.owner}")
            val method = owner.methods.singleOrNull { selector(it) == patch.method } ?: error("Missing/ambiguous method: ${patch.method}")
            Triple(owner, method, edited(canonical(owner, method), patch))
        }
        prepared.forEachIndexed { index, (owner, original, text) ->
            if (Thread.currentThread().isInterrupted) throw InterruptedException()
            val source = File(scratch, "method-$index.smali")
            val assembled = File(scratch, "method-$index.dex")
            require(!source.exists() && !assembled.exists())
            try {
                source.writeText(".class public ${owner.type}\n.super Ljava/lang/Object;\n$text")
                val options = SmaliOptions().apply { apiLevel = dex.opcodes.api; jobs = 1; outputDexFile = assembled.path }
                require(Smali.assemble(options, listOf(source.path))) { "Smali assembly failed: ${selector(original)}" }
                val compiled = DexFileFactory.loadDexFile(assembled, dex.opcodes)
                val cls = compiled.classes.single()
                require(cls.type == owner.type && cls.fields.none()) { "Edits must remain within one method" }
                val method = cls.methods.single()
                require(selector(method) == selector(original) && method.accessFlags == original.accessFlags &&
                    method.implementation != null) { "Method identity/access flags changed" }
                require(method.implementation!!.instructions.count() <= 20000) { "Replacement instruction budget exceeded" }
                replacements[owner.type to selector(original)] = ImmutableMethod(original.definingClass, original.name,
                    original.parameters, original.returnType, original.accessFlags, original.annotations,
                    original.hiddenApiRestrictions, method.implementation)
            } finally { source.delete(); assembled.delete() }
        }
        val pool = DexPool(dex.opcodes)
        dex.classes.forEach { cls ->
            if (Thread.currentThread().isInterrupted) throw InterruptedException()
            if (replacements.keys.none { it.first == cls.type }) pool.internClass(cls)
            else pool.internClass(ImmutableClassDef(cls.type, cls.accessFlags, cls.superclass, cls.interfaces,
                cls.sourceFile, cls.annotations, cls.fields,
                cls.methods.map { replacements[cls.type to selector(it)] ?: it }))
        }
        try {
            val data = FileDataStore(output)
            try { pool.writeTo(data) } finally { data.close() }
            require(output.length() in 1..MAX_DEX) { "Rebuilt DEX exceeds budget" }
            val result: DexBackedDexFile = DexFileFactory.loadDexFile(output, dex.opcodes)
            require(result.classes.map { it.type }.toSet() == dex.classes.map { it.type }.toSet()) { "DEX class inventory changed" }
            prepared.forEach { (owner, original, _) ->
                val cls = result.classes.single { it.type == owner.type }
                val rebuilt = cls.methods.single { selector(it) == selector(original) }
                val expected = replacements.getValue(owner.type to selector(original))
                require(canonical(cls, rebuilt) == canonical(owner, expected)) { "Rebuilt method verification failed" }
            }
        } catch (error: Exception) { output.delete(); throw error }
    }
}
