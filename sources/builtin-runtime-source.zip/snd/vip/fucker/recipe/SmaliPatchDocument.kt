package snd.vip.fucker.recipe

import java.nio.ByteBuffer

/** Annotated .smali: bounded metadata followed by complete existing-method replacements. */
object SmaliPatchDocument {
    const val MAX_BYTES = 1024 * 1024
    const val MAGIC = "# vip-smali-patch 1"
    private val hash = Regex("[a-f0-9]{64}")
    private val dex = Regex("classes(?:[2-9]|[1-9][0-9]+)?\\.dex")
    private val owner = Regex("L[a-zA-Z0-9_$/]+;")
    private val packageName = Regex("[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+")
    fun parse(bytes: ByteArray): PatchRecipe {
        require(bytes.size in 1..MAX_BYTES) { "Smali patch exceeds 1 MiB" }
        val document = Charsets.UTF_8.newDecoder().decode(ByteBuffer.wrap(bytes)).toString()
        require('\u0000' !in document) { "NUL in smali patch" }
        val lines = document.replace("\r\n", "\n").lines().map(String::trim)
        require(lines.firstOrNull() == MAGIC) { "Expected $MAGIC; raw classes need patch metadata" }
        val headers = linkedMapOf<String, String>()
        val methods = mutableListOf<MethodPatch>()
        val required = setOf("id", "title", "detail", "package", "version-code", "version-name", "apk-sha256")
        var index = 1
        while (index < lines.size) {
            val line = lines[index++]
            if (line.isEmpty() || (line.startsWith('#') && !line.startsWith("# @"))) continue
            if (!line.startsWith("# @method ")) {
                require(methods.isEmpty() && line.startsWith("# @")) { "Metadata must precede methods; unexpected smali outside method" }
                val parts = line.removePrefix("# @").split(' ', limit = 2)
                require(parts.size == 2 && parts[0] in required && parts[0] !in headers && parts[1].isNotBlank()) {
                    "Unknown, duplicate or missing smali header"
                }
                headers[parts[0]] = parts[1]
                continue
            }
            require(headers.keys == required && methods.size < 32) { "Complete metadata and 1–32 methods required" }
            val parts = line.removePrefix("# @method ").split(' ')
            require(parts.size == 3 && dex.matches(parts[0]) && owner.matches(parts[1]) && hash.matches(parts[2])) {
                "Method requires DEX, class and original canonical SHA-256"
            }
            val body = mutableListOf<String>()
            while (index < lines.size) {
                val current = lines[index++]
                require(!current.startsWith("# @")) { "Missing .end method or misplaced metadata" }
                body += current
                if (current == ".end method") break
            }
            val normalized = SmaliMethodEngine.normalize(body.joinToString("\n"))
            val declaration = normalized.lineSequence().first()
            require(declaration.startsWith(".method ") && body.lastOrNull() == ".end method" &&
                normalized.length <= 256 * 1024 && normalized.lines().count { it.startsWith(".method ") } == 1) {
                "Exactly one complete .method body required"
            }
            require(normalized.lines().none { it.startsWith(".class ") || it.startsWith(".super ") ||
                it.startsWith(".field ") || it.startsWith(".source ") || it.startsWith(".implements ") }) {
                "Only existing method bodies are supported"
            }
            val selector = declaration.substringAfterLast(' ')
            require(selector.contains('(') && selector.contains(')') && !selector.startsWith('<') && selector.length <= 1024) {
                "Invalid method selector; constructors unsupported"
            }
            methods += MethodPatch(parts[0], parts[1], selector, parts[2], emptyList(), normalized)
        }
        require(headers.keys == required && methods.isNotEmpty()) { "Incomplete smali patch" }
        require(methods.map { Triple(it.dex, it.owner, it.method) }.distinct().size == methods.size) { "Duplicate method" }
        fun header(key: String, max: Int): String = headers.getValue(key).also {
            require(it.length in 1..max) { "Invalid header: $key" }
        }
        val pkg = header("package", 255)
        require(packageName.matches(pkg) && pkg != "snd.vip.fucker") { "Invalid target package" }
        val id = header("id", 128)
        require(Regex("[a-z0-9][a-z0-9._-]*").matches(id)) { "Invalid patch ID" }
        val versionCode = header("version-code", 20).toLongOrNull()
        require(versionCode != null && versionCode >= 0) { "Invalid version code" }
        val apkHash = header("apk-sha256", 64)
        require(hash.matches(apkHash)) { "Reference APK SHA-256 required" }
        return PatchRecipe(id, header("title", 160), header("detail", 4096), pkg, versionCode,
            header("version-name", 128), apkHash, methods, document)
    }
}

/** Retain old JSON files; never treat regular baksmali classes as patch documents. */
object PatchDocuments {
    const val MAX_BYTES = SmaliPatchDocument.MAX_BYTES
    fun parse(bytes: ByteArray): PatchRecipe {
        require(bytes.size in 1..MAX_BYTES) { "Patch file exceeds 1 MiB" }
        return if (bytes.first().toInt() == '#'.code) SmaliPatchDocument.parse(bytes) else RecipeJson.parse(bytes)
    }
}
