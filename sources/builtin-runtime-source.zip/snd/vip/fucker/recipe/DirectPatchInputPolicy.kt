package snd.vip.fucker.recipe

/** Recipe-bound installed inputs, not wrapper eligibility or rooted package authorization. */
object DirectPatchInputPolicy {
    fun requireInstalled(expectedPackage: String, actualPackage: String, hasSplits: Boolean, systemApp: Boolean) {
        require(expectedPackage == actualPackage) { "Installed APK package changed during selection" }
        require(!hasSplits) { "Installed app uses split APKs; choose a standalone distribution" }
        require(!systemApp) { "System apps cannot be patched" }
    }
}
