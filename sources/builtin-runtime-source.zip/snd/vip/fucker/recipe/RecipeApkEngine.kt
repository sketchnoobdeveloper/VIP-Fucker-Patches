package snd.vip.fucker.recipe

import com.android.apksig.ApkVerifier
import com.android.tools.build.apkzlib.sign.SigningExtension
import com.android.tools.build.apkzlib.sign.SigningOptions
import com.android.tools.build.apkzlib.zip.AlignmentRules
import com.android.tools.build.apkzlib.zip.ZFile
import com.android.tools.build.apkzlib.zip.ZFileOptions
import com.android.tools.build.apkzlib.bytestorage.ChunkBasedByteStorageFactory
import com.android.tools.build.apkzlib.bytestorage.OverflowToDiskByteStorageFactory
import com.android.tools.build.apkzlib.bytestorage.TemporaryDirectoryFactory
import org.json.JSONObject
import snd.vip.fucker.nonroot.*
import java.io.File
import java.security.KeyStore
import java.security.cert.X509Certificate
import java.util.zip.ZipFile

/** Direct DEX rewrite/sign route. No LSPatch loader, embedded module, root, or purchase execution. */
class RecipeApkEngine(private val key: KeyStore.PrivateKeyEntry) {
    companion object {
        const val AUDIT = "assets/vip-fucker/smali-recipe.json"
        fun verifyReceipt(file: File, archive: ApkArchive, receipt: PatchReceipt) {
            require(receipt.kind == "smali-method-v1" && receipt.recipeSha256?.matches(Regex("[a-f0-9]{64}")) == true &&
                receipt.moduleSha256 == receipt.recipeSha256 && receipt.bytes == file.length() &&
                !archive.patched && archive.packageName == receipt.packageName &&
                archive.versionCode == receipt.versionCode && archive.versionName == receipt.version) { "Recipe output identity mismatch" }
            ApkAlignment.verify(file)
            ZipFile(file).use { zip ->
                val entry = requireNotNull(zip.getEntry(AUDIT)) { "Missing recipe audit" }
                val audit = zip.getInputStream(entry).use { JSONObject(ApkFiles.bounded(it, 8192).readBytes().toString(Charsets.UTF_8)) }
                require(audit.get("schema") == 1 && audit.getString("engine") == "smali-method-v1" &&
                    audit.getString("originalSha256") == receipt.originalSha256 &&
                    audit.getString("recipeSha256") == receipt.recipeSha256 && audit.getString("package") == receipt.packageName) {
                    "Recipe audit mismatch"
                }
            }
        }
    }
    fun patch(original: File, destination: File, recipe: PatchRecipe, tryOtherBuild: Boolean, scratch: File) {
        require(!destination.exists() && scratch.isDirectory)
        val archive = ApkFiles.inspect(original)
        val originalHash = ApkFiles.digest(original)
        recipe.requireTarget(archive, originalHash, tryOtherBuild)
        val dexOutputs = linkedMapOf<String, File>()
        try {
            ZipFile(original).use { source ->
                require(source.getEntry(AUDIT) == null) { "Already recipe-patched; choose the original APK" }
                val inflated = source.entries().asSequence().sumOf { it.size }
                require(inflated in 1..384L * 1024 * 1024) { "Direct patch materialization budget exceeded" }
                recipe.operations.groupBy { it.dex }.forEach { (name, operations) ->
                    if (Thread.currentThread().isInterrupted) throw InterruptedException()
                    val entry = requireNotNull(source.getEntry(name)) { "Recipe DEX missing: $name" }
                    require(entry.size in 1..SmaliMethodEngine.MAX_DEX) { "DEX exceeds 64 MiB" }
                    val input = File(scratch, "input-$name")
                    val output = File(scratch, "output-$name")
                    require(!input.exists() && !output.exists())
                    try {
                        source.getInputStream(entry).use { stream -> input.outputStream().use { ApkFiles.copy(stream, it, entry.size) } }
                        SmaliMethodEngine.rewrite(input, output, operations, scratch)
                        dexOutputs[name] = output
                    } finally { input.delete() }
                }
                val options = ZFileOptions().setAlignmentRule(AlignmentRules.compose(
                    AlignmentRules.constantForSuffix(".so", NonRootEngine.PAGE), AlignmentRules.constant(4)))
                    .setStorageFactory(ChunkBasedByteStorageFactory(OverflowToDiskByteStorageFactory(4L * 1024 * 1024,
                        TemporaryDirectoryFactory.fixed(scratch))))
                ZFile.openReadWrite(destination, options).use { target ->
                    SigningExtension(SigningOptions.builder().setMinSdkVersion(maxOf(28, archive.minSdk)).setV2SigningEnabled(true)
                        .setCertificates(*key.certificateChain.map { it as X509Certificate }.toTypedArray())
                        .setKey(key.privateKey).build()).register(target)
                    source.entries().asSequence().forEach { entry ->
                        if (NonRootEngine.signatureEntry(entry.name) || entry.name in dexOutputs || entry.isDirectory ||
                            entry.name in setOf("assets/dexopt/baseline.prof", "assets/dexopt/baseline.profm")) return@forEach
                        source.getInputStream(entry).use { stream ->
                            ApkFiles.bounded(stream, entry.size).use { target.add(entry.name, it, entry.method != 0) }
                        }
                    }
                    dexOutputs.forEach { (name, file) -> file.inputStream().use { target.add(name, it, false) } }
                    val audit = JSONObject().put("schema", 1).put("engine", "smali-method-v1").put("id", recipe.id)
                        .put("package", recipe.packageName).put("originalSha256", originalHash).put("recipeSha256", recipe.sha256)
                        .put("referenceMatch", recipe.exact(archive, originalHash)).put("methods", recipe.operations.size)
                        .toString().toByteArray(Charsets.UTF_8)
                    target.add(AUDIT, audit.inputStream())
                    target.realign()
                }
                require(destination.length() in 1..ApkFiles.MAX_APK)
                val signature = ApkVerifier.Builder(destination).setMinCheckedPlatformVersion(maxOf(28, archive.minSdk)).build().verify()
                require(signature.isVerified && signature.isVerifiedUsingV2Scheme && signature.signerCertificates.size == 1 &&
                    signature.signerCertificates.single().encoded.contentEquals(key.certificate.encoded)) { "Recipe APK signing failed" }
                val result = ApkFiles.inspect(destination)
                require(!result.patched && result.packageName == archive.packageName && result.versionCode == archive.versionCode &&
                    result.versionName == archive.versionName) { "Repacked APK identity changed" }
                ApkAlignment.verify(destination)
                ZipFile(destination).use { resultZip ->
                    dexOutputs.forEach { (name, dex) ->
                        require(resultZip.getInputStream(resultZip.getEntry(name)).use(ApkFiles::digest) == ApkFiles.digest(dex)) {
                            "Saved DEX mismatch"
                        }
                    }
                    // Manifest/resources/native payloads must be byte-identical, not merely named alike.
                    source.entries().asSequence().filter { !it.isDirectory && !NonRootEngine.signatureEntry(it.name) &&
                        it.name !in dexOutputs && it.name !in setOf("assets/dexopt/baseline.prof", "assets/dexopt/baseline.profm") }
                        .forEach { entry ->
                            require(resultZip.getInputStream(requireNotNull(resultZip.getEntry(entry.name))).use(ApkFiles::digest) ==
                                source.getInputStream(entry).use(ApkFiles::digest)) { "Preserved member changed: ${entry.name}" }
                        }
                }
            }
        } catch (error: Exception) { destination.delete(); throw error }
        finally { dexOutputs.values.forEach { it.delete() } }
    }
}
