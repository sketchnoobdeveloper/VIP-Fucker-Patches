package snd.vip.fucker.nonroot

import org.json.JSONObject
import snd.vip.fucker.core.Profiles
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.file.Files
import java.nio.file.SimpleFileVisitor
import java.nio.file.FileVisitResult
import java.nio.file.Path
import java.nio.file.attribute.BasicFileAttributes
import java.util.UUID
import java.util.concurrent.locks.ReentrantLock

/** Private receipts are evidence of a completed build, not target execution. */
data class PatchReceipt(val id: String, val packageName: String, val version: String?,
    val sha256: String, val signer: String, val originalSha256: String, val moduleSha256: String,
    val versionCode: Long? = null, val bytes: Long? = null,
    val kind: String = "lspatch", val recipeSha256: String? = null) {
    fun encode(): ByteArray = JSONObject().put("schema", 1).put("id", id).put("package", packageName)
        .put("version", version ?: "").put("sha256", sha256).put("signer", signer)
        .put("originalSha256", originalSha256).put("moduleSha256", moduleSha256)
        .apply { versionCode?.let { put("versionCode", it) }; bytes?.let { put("bytes", it) } }
        .apply { if (kind != "lspatch") put("kind", kind); recipeSha256?.let { put("recipeSha256", it) } }
        .toString().toByteArray(Charsets.UTF_8)

    companion object {
        const val MAX_RECORD = 8192L
        private val hash = Regex("[a-f0-9]{64}")
        fun validId(id: String) = runCatching { UUID.fromString(id).toString() == id }.getOrDefault(false)
        fun parse(bytes: ByteArray): PatchReceipt {
            require(bytes.size.toLong() in 1..MAX_RECORD) { "Invalid patch receipt size" }
            val json = JSONObject(bytes.toString(Charsets.UTF_8))
            // Revision 17/18 receipts have no schema, byte count or versionCode.
            require(!json.has("schema") || json.get("schema") == 1) { "Unsupported patch receipt" }
            fun text(key: String) = (json.get(key) as? String) ?: error("Invalid receipt field: $key")
            fun number(key: String): Long? = if (!json.has(key)) null else {
                val value = json.get(key)
                require(value is Int || value is Long) { "Invalid receipt number" }
                (value as Number).toLong()
            }
            val result = PatchReceipt(text("id"), text("package"), text("version").takeIf { it.isNotEmpty() },
                text("sha256"), text("signer"), text("originalSha256"), text("moduleSha256"),
                number("versionCode"), number("bytes"), if (json.has("kind")) text("kind") else "lspatch",
                if (json.has("recipeSha256")) text("recipeSha256") else null)
            require(validId(result.id)) { "Invalid receipt identity" }
            when (result.kind) {
                "lspatch" -> require(Profiles.byPackage(result.packageName)?.wrapperSupported == true && result.recipeSha256 == null) { "Invalid registered wrapper target" }
                "smali-method-v1" -> require(Regex("[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+").matches(result.packageName) &&
                    result.packageName != "snd.vip.fucker" && result.recipeSha256?.let(hash::matches) == true &&
                    result.moduleSha256 == result.recipeSha256 && result.versionCode != null && result.bytes != null) { "Invalid recipe receipt" }
                else -> error("Unsupported output kind")
            }
            require(listOf(result.sha256, result.signer, result.originalSha256, result.moduleSha256).all(hash::matches)) { "Invalid receipt digest" }
            require(result.versionCode == null || result.versionCode >= 0)
            require(result.bytes == null || result.bytes in 1..ApkFiles.MAX_APK)
            return result
        }
    }
}

data class StoredPatch(val file: File, val receipt: PatchReceipt)

/** Serialized, UUID-scoped storage. Ready outputs are never automatically pruned. */
class NonRootStore(outputs: File, jobs: File, private val readIndex: () -> ByteArray,
    private val commitIndex: (ByteArray) -> Unit, private val syncDirectory: (File) -> Unit = {}) {
    val outputs = outputs.canonicalFile
    private val jobs = jobs.canonicalFile
    private class Gate { val lock = ReentrantLock(); var initialized = false }
    companion object {
        private val gates = HashMap<String, Gate>()
        private fun gate(root: File) = synchronized(gates) { gates.getOrPut(root.path) { Gate() } }
    }
    private val gate = gate(this.outputs)

    fun <T> exclusive(block: NonRootStore.() -> T): T {
        gate.lock.lockInterruptibly()
        try {
            require(outputs.isDirectory || outputs.mkdirs()) { "Cannot create output storage" }
            require(jobs.isDirectory || jobs.mkdirs()) { "Cannot create scratch storage" }
            RandomAccessFile(File(outputs, "workspace.lock"), "rw").use { lockFile ->
                val lease = requireNotNull(lockFile.channel.tryLock()) { "Another patch process is using this workspace" }
                lease.use {
                    if (!gate.initialized) { cleanInterrupted(); gate.initialized = true }
                    return block()
                }
            }
        } finally { gate.lock.unlock() }
    }

    private fun owned(root: File, id: String): File {
        require(PatchReceipt.validId(id)) { "Invalid workspace ID" }
        val file = File(root, id)
        require(file.canonicalFile == file.absoluteFile) { "Unsafe workspace path" }
        return file
    }
    private fun requireLease() = check(gate.lock.isHeldByCurrentThread) { "Workspace lease required" }
    private fun deleteOwned(root: File, directory: File) {
        require(directory == owned(root, directory.name))
        if (!directory.exists()) return
        // Do not follow symbolic links, including links inside a killed backend job.
        Files.walkFileTree(directory.toPath(), object : SimpleFileVisitor<Path>() {
            override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                Files.delete(file); return FileVisitResult.CONTINUE
            }
            override fun postVisitDirectory(dir: Path, error: java.io.IOException?): FileVisitResult {
                if (error != null) throw error
                Files.delete(dir); return FileVisitResult.CONTINUE
            }
        })
    }
    private fun cleanInterrupted() {
        for (directory in jobs.listFiles().orEmpty()) {
            if (PatchReceipt.validId(directory.name) && directory.canonicalFile == directory.absoluteFile)
                deleteOwned(jobs, directory)
        }
        for (directory in outputs.listFiles().orEmpty()) {
            if (PatchReceipt.validId(directory.name) && directory.canonicalFile == directory.absoluteFile &&
                (!File(directory, "patched.apk").isFile || !File(directory, "preparation.json").isFile))
                deleteOwned(outputs, directory)
        }
    }
    fun newJob(): File {
        requireLease()
        return owned(jobs, UUID.randomUUID().toString()).apply { require(mkdir()) { "Cannot create scratch job" } }
    }
    fun removeJob(directory: File) { requireLease(); deleteOwned(jobs, directory) }

    fun prepare(build: (File, String) -> PatchReceipt): StoredPatch {
        requireLease()
        val directory = owned(outputs, UUID.randomUUID().toString()).apply { require(mkdir()) }
        try {
            val pending = File(directory, "pending.apk")
            val receipt = PatchReceipt.parse(build(pending, directory.name).encode())
            require(receipt.id == directory.name && pending.isFile && ApkFiles.digest(pending) == receipt.sha256)
            require(receipt.bytes == pending.length()) { "Output byte count mismatch" }
            FileOutputStream(pending, true).use { it.fd.sync() }
            val ready = File(directory, "patched.apk")
            require(pending.renameTo(ready)) { "Cannot publish APK" }
            FileOutputStream(File(directory, "preparation.json")).use { it.write(receipt.encode()); it.fd.sync() }
            syncDirectory(directory)
            syncDirectory(outputs)
            return StoredPatch(ready, receipt)
        } catch (error: Exception) {
            deleteOwned(outputs, directory)
            throw error
        }
    }
    fun commit(output: StoredPatch) {
        requireLease()
        require(output.file == File(owned(outputs, output.receipt.id), "patched.apk"))
        require(ApkFiles.digest(output.file) == output.receipt.sha256) { "Output changed before commit" }
        // The caller runs final digest validation + journal commit in a NonCancellable context.
        commitIndex(output.receipt.encode())
    }
    fun discard(output: StoredPatch) {
        requireLease()
        // Never delete an output whose journal commit already completed.
        val committed = runCatching { PatchReceipt.parse(readIndex()).id == output.receipt.id }.getOrDefault(false)
        if (!committed) deleteOwned(outputs, owned(outputs, output.receipt.id))
    }
    fun recover(validate: (File, PatchReceipt) -> Unit): StoredPatch? {
        requireLease()
        return try {
            val receipt = PatchReceipt.parse(readIndex())
            val directory = owned(outputs, receipt.id)
            val receiptFile = File(directory, "preparation.json")
            require(receiptFile.canonicalFile == receiptFile.absoluteFile) { "Unsafe patch receipt path" }
            val local = receiptFile.inputStream().use {
                java.io.ByteArrayOutputStream().also { bytes -> ApkFiles.copy(it, bytes, PatchReceipt.MAX_RECORD) }.toByteArray()
            }
            require(PatchReceipt.parse(local) == receipt) { "Patch journal/receipt mismatch" }
            val file = File(directory, "patched.apk")
            validate(file, receipt)
            StoredPatch(file, receipt)
        } catch (error: InterruptedException) { throw error }
        catch (_: Exception) { null }
    }
}
