package snd.vip.fucker.nonroot

import com.android.apksig.ApkVerifier
import com.android.apksig.util.DataSources
import com.google.gson.Gson
import org.lsposed.lspatch.share.Constants
import org.lsposed.lspatch.share.PatchConfig
import java.io.File
import java.io.RandomAccessFile
import java.util.zip.ZipFile

/** App-local compatibility, NOT an Android installer/server/attestation bypass. */
object PatchSignaturePolicy {
    private fun certificate(result: ApkVerifier.Result): String {
        require(result.isVerified && result.signerCertificates.size == 1) {
            "Signature compatibility needs a valid single-signer original APK. Disable it for unsigned or unsupported inputs."
        }
        return result.signerCertificates.single().encoded.joinToString("") { "%02x".format(it) }
    }
    fun configuration(original: File, factory: String?, enabled: Boolean): PatchConfig {
        val certificate = if (enabled) {
            val result = ApkVerifier.Builder(original).setMinCheckedPlatformVersion(28).build().verify()
            certificate(result)
        } else null
        // Level 3 instruments native syscall sites and can introduce new detection/crash risks.
        return PatchConfig(false, false, null,
            if (enabled) Constants.SIGBYPASS_LV_PM_OPENAT else Constants.SIGBYPASS_LV_DISABLE,
            certificate, factory, false, emptyArray(), false, null)
    }

    /** Verify the compatibility identity against the exact nested signed APK, without extracting it. */
    fun verifyStored(file: File, zip: ZipFile) {
        val member = requireNotNull(zip.getEntry(ApkFiles.CONFIG)) { "Missing loader configuration" }
        require(member.size in 1..65536)
        val config = zip.getInputStream(member).use {
            Gson().fromJson(ApkFiles.bounded(it, member.size).reader(), PatchConfig::class.java)
        }
        require(config != null && config.sigBypassLevel in setOf(Constants.SIGBYPASS_LV_DISABLE, Constants.SIGBYPASS_LV_PM_OPENAT)) {
            "Unsupported signature compatibility mode"
        }
        if (config.sigBypassLevel == Constants.SIGBYPASS_LV_DISABLE) {
            require(config.originalSignature == null) { "Unexpected original certificate in disabled mode" }
            return
        }
        val original = requireNotNull(zip.getEntry(ApkFiles.ORIGINAL))
        require(original.method == 0 && original.size in 1..ApkFiles.MAX_APK)
        val offset = requireNotNull(ApkAlignment.storedOffsets(file)[ApkFiles.ORIGINAL])
        RandomAccessFile(file, "r").use { input ->
            require(offset >= 0 && original.size <= input.length() - offset)
            val result = ApkVerifier.Builder(DataSources.asDataSource(input, offset, original.size))
                .setMinCheckedPlatformVersion(28).build().verify()
            require(config.originalSignature == certificate(result)) { "Compatibility certificate differs from embedded original" }
        }
    }
}
