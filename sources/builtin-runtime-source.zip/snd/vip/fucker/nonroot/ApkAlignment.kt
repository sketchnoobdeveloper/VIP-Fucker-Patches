package snd.vip.fucker.nonroot

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Check actual local-header offsets, not merely STORED flags or alignment requests. */
object ApkAlignment {
    fun storedOffsets(file: File): Map<String, Long> = RandomAccessFile(file, "r").use { input ->
        require(input.length() in 22..ApkFiles.MAX_APK)
        val tailSize = minOf(input.length(), 65557).toInt()
        val tail = ByteArray(tailSize)
        input.seek(input.length() - tailSize); input.readFully(tail)
        val data = ByteBuffer.wrap(tail).order(ByteOrder.LITTLE_ENDIAN)
        val end = (tailSize - 22 downTo 0).firstOrNull {
            data.getInt(it) == 0x06054b50 && it + 22 + (data.getShort(it + 20).toInt() and 0xffff) == tailSize
        } ?: throw IllegalArgumentException("Missing ZIP directory")
        require(data.getShort(end + 4).toInt() == 0 && data.getShort(end + 6).toInt() == 0)
        val count = data.getShort(end + 10).toInt() and 0xffff
        require(count != 0xffff && count == (data.getShort(end + 8).toInt() and 0xffff)) { "ZIP64/multi-disk APK not supported" }
        var cursor = data.getInt(end + 16).toLong() and 0xffffffffL
        val directoryEnd = input.length() - tailSize + end
        val result = linkedMapOf<String, Long>()
        repeat(count) {
            if (Thread.currentThread().isInterrupted) throw InterruptedException()
            require(cursor + 46 <= directoryEnd)
            val header = ByteArray(46)
            input.seek(cursor); input.readFully(header)
            val central = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
            require(central.getInt(0) == 0x02014b50)
            val nameLength = central.getShort(28).toInt() and 0xffff
            val extra = central.getShort(30).toInt() and 0xffff
            val comment = central.getShort(32).toInt() and 0xffff
            require(cursor + 46 + nameLength + extra + comment <= directoryEnd)
            val nameBytes = ByteArray(nameLength); input.readFully(nameBytes)
            val name = nameBytes.toString(Charsets.UTF_8)
            if (central.getShort(10).toInt() == 0) {
                val local = central.getInt(42).toLong() and 0xffffffffL
                require(local + 30 < directoryEnd)
                val localBytes = ByteArray(30)
                input.seek(local); input.readFully(localBytes)
                val localHeader = ByteBuffer.wrap(localBytes).order(ByteOrder.LITTLE_ENDIAN)
                require(localHeader.getInt(0) == 0x04034b50)
                val localName = localHeader.getShort(26).toInt() and 0xffff
                val localExtra = localHeader.getShort(28).toInt() and 0xffff
                result[name] = local + 30 + localName + localExtra
            }
            cursor += 46 + nameLength + extra + comment
        }
        result
    }

    fun verify(file: File) {
        storedOffsets(file).forEach { (name, offset) ->
            val alignment = if (name.endsWith(".so") || name == ApkFiles.ORIGINAL) NonRootEngine.PAGE else 4
            require(offset % alignment == 0L) { "Unaligned APK member: $name" }
        }
    }
}
