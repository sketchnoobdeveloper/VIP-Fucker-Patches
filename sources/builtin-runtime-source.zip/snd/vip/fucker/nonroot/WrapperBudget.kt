package snd.vip.fucker.nonroot

import java.util.zip.ZipEntry

/** Nested links reuse payload bytes. Only native copies and origin need page padding. */
object WrapperBudget {
    const val RESERVE = 16L * 1024 * 1024

    fun memberOverhead(entry: ZipEntry): Long {
        val name = entry.name.toByteArray(Charsets.UTF_8).size
        val extra = entry.extra?.size ?: 0
        val comment = entry.comment?.toByteArray(Charsets.UTF_8)?.size ?: 0
        require(name in 1..65535 && extra <= 65535 && comment <= 65535) { "Unsupported ZIP metadata" }
        // Local + central headers, linking segment, both encoded names/extras,
        // comment and worst alignment. Includes skipped members conservatively.
        return 80L + 2L * name + 2L * extra + comment + if (entry.name.endsWith(".so")) NonRootEngine.PAGE else 4
    }

    fun expansion(archive: ApkArchive): Long {
        require(archive.materializedBytes in 0..ApkFiles.MAX_APK && archive.wrapperOverheadBytes in 0..ApkFiles.MAX_APK)
        return archive.materializedBytes + archive.wrapperOverheadBytes
    }

    fun output(originalBytes: Long, moduleBytes: Long, archive: ApkArchive): Long {
        require(originalBytes in 1..ApkFiles.MAX_APK && moduleBytes in 1..ApkFiles.MAX_APK)
        return originalBytes + moduleBytes + expansion(archive) + RESERVE
    }
}
