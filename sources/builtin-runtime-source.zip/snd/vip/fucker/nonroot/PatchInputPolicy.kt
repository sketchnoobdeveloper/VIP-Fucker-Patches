package snd.vip.fucker.nonroot

import snd.vip.fucker.core.Profiles

/** Package visibility and patchability are separate; a split base is never a complete input. */
object PatchInputPolicy {
    fun requireInstalled(packageName: String, hasSplits: Boolean, systemApp: Boolean) {
        require(Profiles.byPackage(packageName)?.wrapperSupported == true) {
            "Choose a listed wrapper target; direct-only targets use their smali patch"
        }
        require(!hasSplits) { "Installed app uses split APKs; choose a standalone distribution" }
        require(!systemApp) { "System apps cannot be patched" }
    }

    fun requireIdentity(expectedPackage: String?, actualPackage: String) {
        require(expectedPackage == null || expectedPackage == actualPackage) {
            "Installed APK package changed during selection"
        }
    }
}
