package snd.vip.fucker.nonroot

import android.app.Application
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.StatFs
import android.provider.DocumentsContract
import android.system.Os
import android.system.OsConstants
import android.util.AtomicFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import org.json.JSONObject
import snd.vip.fucker.R
import snd.vip.fucker.core.*
import java.io.File
import java.io.InputStream
import java.util.UUID

data class PatchOutput(val file: File, val packageName: String, val version: String?, val sha256: String,
    val signer: String, val receipt: PatchReceipt, val installed: Boolean = false)
data class PatchScreenState(val busy: Boolean = false, val stage: Int = R.string.nonroot_pick_hint,
    val archive: ApkArchive? = null, val match: BuildMatch? = null, val config: Config = Config(),
    val acknowledged: Boolean = false, val output: PatchOutput? = null, val error: String? = null,
    val cancellable: Boolean = false, val installRequest: PatchInstallRequest? = null,
    val signatureCompatibility: Boolean = true)

/** Jobs outlive activity recreation, not process death. Interrupted work is never marked ready. */
class NonRootViewModel(application: Application) : AndroidViewModel(application) {
    private val context get() = getApplication<Application>()
    private val mutable = MutableStateFlow(PatchScreenState())
    val state = mutable.asStateFlow()
    private var original: File? = null
    private var work: File? = null
    private var operation: Job? = null
    private val outputs = File(application.filesDir, "nonroot/outputs")
    private val store = NonRootStore(outputs, File(application.noBackupFilesDir, "nonroot/jobs"),
        readIndex = { AtomicFile(File(outputs, "last-success.json")).openRead().use { input ->
            java.io.ByteArrayOutputStream().also { ApkFiles.copy(input, it, PatchReceipt.MAX_RECORD) }.toByteArray()
        } }, commitIndex = { bytes ->
            val atomic = AtomicFile(File(outputs, "last-success.json"))
            PatchJournal.commit(bytes, atomic::startWrite, atomic::finishWrite, atomic::failWrite,
                read = { atomic.openRead().use { input ->
                    java.io.ByteArrayOutputStream().also { ApkFiles.copy(input, it, PatchReceipt.MAX_RECORD) }.toByteArray()
                } }, syncDirectory = {
                val descriptor = Os.open(outputs.path, OsConstants.O_RDONLY, 0)
                try { Os.fsync(descriptor) } finally { Os.close(descriptor) }
            })
        }, syncDirectory = { directory ->
            val descriptor = Os.open(directory.path, OsConstants.O_RDONLY, 0)
            try { Os.fsync(descriptor) } finally { Os.close(descriptor) }
        })
    private val savedConfig get() = ConfigStore(context.getSharedPreferences(Config.PREFS + "_nonroot", 0))
    private fun StoredPatch.screenOutput() = PatchOutput(file, receipt.packageName, receipt.version,
        receipt.sha256, receipt.signer, receipt)

    init { viewModelScope.launch {
        val previous = runInterruptible(Dispatchers.IO) {
            try { store.exclusive { recover(PatchOutputVerifier::verify)?.screenOutput() } }
            catch (error: InterruptedException) { throw error }
            catch (_: Exception) { null }
        }
        // History may finish during a selection; add it without replacing the user's archive/draft.
        mutable.update { if (it.output == null) it.copy(output = previous) else it }
        if (previous != null) refreshInstalled()
    } }

    fun select(uri: Uri, expectedPackage: String? = null) {
        if (uri.scheme != "content") return
        selectInput(expectedPackage) { requireNotNull(context.contentResolver.openInputStream(uri)) }
    }
    fun clearInput() {
        if (mutable.value.busy) return
        original = null
        mutable.value = PatchScreenState(output = mutable.value.output)
    }
    /** Only narrow, registered package identities; never silently drop split members. */
    fun selectInstalled(packageName: String) {
        if (Profiles.byPackage(packageName)?.wrapperSupported != true) return
        selectInput(packageName) {
            val app = context.packageManager.getApplicationInfo(packageName, 0)
            PatchInputPolicy.requireInstalled(packageName, !app.splitSourceDirs.isNullOrEmpty(),
                app.flags and (android.content.pm.ApplicationInfo.FLAG_SYSTEM or
                    android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0)
            File(app.sourceDir).inputStream()
        }
    }
    fun repatchLast() {
        val output = mutable.value.output ?: return
        selectInput(output.packageName) {
            PatchOutputVerifier.verify(output.file, output.receipt)
            output.file.inputStream()
        }
    }
    private fun selectInput(expectedPackage: String? = null, open: () -> InputStream) {
        if (mutable.value.busy) return
        val previousOutput = mutable.value.output
        original = null
        mutable.value = PatchScreenState(busy = true, stage = R.string.nonroot_inspecting,
            output = previousOutput, cancellable = true)
        operation = viewModelScope.launch {
            var selectionDirectory: File? = null
            var selectedSuccessfully = false
            try {
                val operationContext = coroutineContext
                val selected = runInterruptible(Dispatchers.IO) { store.exclusive {
                    require(Build.VERSION.SDK_INT >= 28) { "Android 9+ required" }
                    val job = newJob()
                    selectionDirectory = job
                    // Only our previous, UUID-scoped scratch directory is removed. Outputs are retained.
                    work?.let(::removeJob)
                    work = job
                    val input = File(job, "input.apk")
                    val available = StatFs(context.noBackupFilesDir.path).availableBytes - 64L * 1024 * 1024
                    require(available > 0) { "Not enough free storage to inspect APK" }
                    open().use { source -> input.outputStream().use { ApkFiles.copy(source, it, minOf(ApkFiles.MAX_APK, available)) } }
                    val restored = ApkFiles.recover(input, File(job, "original.apk"))
                    val archive = ApkFiles.inspect(restored)
                    PatchInputPolicy.requireIdentity(expectedPackage, archive.packageName)
                    require(archive.minSdk <= Build.VERSION.SDK_INT) { "APK needs a newer Android version" }
                    require(archive.nativeAbis.isEmpty() || archive.nativeAbis.any { it in Build.SUPPORTED_ABIS }) { "APK ABI not supported on this device" }
                    val profile = requireNotNull(Profiles.byPackage(archive.packageName)) { "Choose a listed target, not this manager" }
                    require(profile.wrapperSupported) { "Target does not support the non-root wrapper" }
                    // Input APK signatures are advisory only. A locally built,
                    // re-signed or otherwise modified target must still be patchable;
                    // package identity, ABI, SDK and the reference digest policy
                    // remain the actual gates.
                    val match = TargetPolicy.inspect(profile, archive.versionCode, archive.versionName, ApkFiles.digest(restored), false)
                    operationContext.ensureActive()
                    original = restored
                    Triple(archive, match, savedConfig.load())
                } }
                mutable.value = mutable.value.copy(busy = false, stage = R.string.nonroot_choose_features,
                    archive = selected.first, match = selected.second, config = selected.third, cancellable = false)
                selectedSuccessfully = true
            } catch (error: CancellationException) {
                original = null
                mutable.value = PatchScreenState(stage = R.string.nonroot_cancelled, output = mutable.value.output ?: previousOutput)
                throw error
            } catch (error: Exception) { original = null; fail(error) }
            finally {
                if (!selectedSuccessfully) withContext(NonCancellable + Dispatchers.IO) {
                    store.exclusive { selectionDirectory?.let(::removeJob) }
                    if (work == selectionDirectory) work = null
                }
            }
        }
    }
    fun cancel() {
        if (!mutable.value.busy || !mutable.value.cancellable) return
        mutable.value = mutable.value.copy(stage = R.string.nonroot_cancelling, cancellable = false)
        operation?.cancel()
    }
    fun edit(key: String, value: Boolean) {
        val current = mutable.value
        if (current.busy) return
        val profile = current.archive?.let { Profiles.byPackage(it.packageName) } ?: return
        val values = current.config.values + ("${profile.id}.$key" to value)
        Config.validate(values)?.let { mutable.value = current.copy(config = it, error = null) }
    }
    fun acknowledge(value: Boolean) { if (!mutable.value.busy) mutable.value = mutable.value.copy(acknowledged = value) }
    fun signatureCompatibility(value: Boolean) {
        if (!mutable.value.busy) mutable.value = mutable.value.copy(signatureCompatibility = value, acknowledged = false, error = null)
    }
    fun patch() {
        val current = mutable.value
        val archive = current.archive ?: return
        val input = original ?: return
        val profile = requireNotNull(Profiles.byPackage(archive.packageName))
        if (current.busy || !current.acknowledged || !TargetPolicy.mayAttempt(profile, current.match, current.config.allowUnverified(profile))) return
        mutable.value = current.copy(busy = true, stage = R.string.nonroot_building, error = null, cancellable = true)
        operation = viewModelScope.launch {
            var prepared: StoredPatch? = null
            var published = false
            try {
                val operationContext = coroutineContext
                runInterruptible(Dispatchers.IO) { store.exclusive {
                    val manager = File(context.applicationInfo.sourceDir)
                    require(context.applicationInfo.splitSourceDirs.isNullOrEmpty()) { "Split manager build not supported" }
                    val expansion = WrapperBudget.expansion(archive)
                    require(StatFs(context.noBackupFilesDir.path).availableBytes >= input.length() * 4 + manager.length() * 3 +
                        expansion * 2 + 64L * 1024 * 1024) { "Not enough free storage" }
                    require(WrapperBudget.output(input.length(), manager.length(), archive) < ApkFiles.MAX_APK) { "Combined APK exceeds budget" }
                    val key = NonRootSigner.entry { context.assets.open(it) }
                    val job = requireNotNull(work)
                    val lock = context.assets.open("nonroot-loader/provenance.json").use { JSONObject(it.bufferedReader().readText()) }
                    val engine = NonRootEngine(key, job) { name ->
                        val bytes = context.assets.open("nonroot-loader/$name").use { it.readBytes() }
                        val expected = lock.getJSONObject("files").getJSONObject("app/src/main/assets/nonroot-loader/$name")
                        require(bytes.size == expected.getInt("bytes") && bytes.inputStream().use(ApkFiles::digest) == expected.getString("sha256")) { "Bundled loader integrity failure" }
                        bytes.inputStream()
                    }
                    val module = File(job, "configured-module-${UUID.randomUUID()}.apk")
                    try {
                        val originalHash = ApkFiles.digest(input)
                        engine.configureModule(manager, module, profile, current.config, originalHash)
                        operationContext.ensureActive()
                        mutable.value = mutable.value.copy(stage = R.string.nonroot_signing)
                        prepared = prepare { pending, id ->
                            engine.patch(input, module, pending, archive, current.signatureCompatibility)
                            operationContext.ensureActive()
                            PatchReceipt(id, profile.packageName, archive.versionName, ApkFiles.digest(pending),
                                NonRootSigner.fingerprint(key), originalHash, ApkFiles.digest(module), archive.versionCode, pending.length())
                        }
                    } finally { module.delete() }
                } }
                coroutineContext.ensureActive()
                mutable.value = mutable.value.copy(cancellable = false)
                // Once this boundary is crossed, cancellation cannot interrupt durable publication.
                withContext(NonCancellable + Dispatchers.IO) { store.exclusive {
                    val output = requireNotNull(prepared)
                    commit(output)
                    published = true
                    mutable.value = mutable.value.copy(busy = false, stage = R.string.nonroot_ready,
                        output = output.screenOutput(), cancellable = false)
                    runCatching { savedConfig.save(current.config) }
                } }
            } catch (error: CancellationException) {
                // Cancellation during the atomic commit must not hide a successfully published APK.
                if (!published)
                    mutable.value = current.copy(stage = R.string.nonroot_cancelled, cancellable = false)
                else mutable.value = mutable.value.copy(busy = false)
                throw error
            }
            catch (error: Exception) { fail(error) }
            finally {
                if (!published) withContext(NonCancellable + Dispatchers.IO) {
                    store.exclusive { prepared?.let(::discard) }
                }
            }
        }
    }
    fun export(uri: Uri) {
        val output = mutable.value.output ?: return
        if (mutable.value.busy || uri.scheme != "content") return
        mutable.value = mutable.value.copy(busy = true, stage = R.string.nonroot_verifying, error = null)
        operation = viewModelScope.launch {
            var opened = false
            try {
                runInterruptible(Dispatchers.IO) { store.exclusive {
                    PatchOutputVerifier.verify(output.file, output.receipt)
                    VerifiedApkExport.transfer(output.file, output.sha256,
                        openOutput = { requireNotNull(context.contentResolver.openOutputStream(uri, "wt")).also { opened = true } },
                        openInput = { requireNotNull(context.contentResolver.openInputStream(uri)) })
                } }
                mutable.value = mutable.value.copy(busy = false, stage = R.string.nonroot_exported)
            } catch (error: CancellationException) {
                mutable.value = mutable.value.copy(busy = false, cancellable = false)
                if (opened) removeFailedExport(uri)
                throw error
            } catch (error: Exception) {
                if (opened) removeFailedExport(uri)
                fail(error)
            }
        }
    }
    private suspend fun removeFailedExport(uri: Uri) = withContext(NonCancellable + Dispatchers.IO) {
        // CreateDocument returns a new user-requested document. Providers may refuse deletion.
        runCatching { if (DocumentsContract.isDocumentUri(context, uri)) DocumentsContract.deleteDocument(context.contentResolver, uri) }
        Unit
    }
    fun prepareInstall() {
        val output = mutable.value.output ?: return
        if (mutable.value.busy) return
        verifyInstall(output)
    }
    fun confirmUninstall() {
        val request = mutable.value.installRequest ?: return
        if (request.step != PatchInstallStep.CONFIRM_UNINSTALL) return
        // Reverify before a destructive hand-off, not just before displaying the warning.
        verifyInstall(request.output, confirmed = true)
    }
    fun cancelInstall() {
        if (mutable.value.installRequest?.step != PatchInstallStep.CONFIRM_UNINSTALL) return
        mutable.value = mutable.value.copy(busy = false, stage = R.string.nonroot_install_cancelled, installRequest = null)
    }
    fun uninstallReturned() {
        val request = mutable.value.installRequest ?: return
        if (request.step != PatchInstallStep.WAIT_UNINSTALL) return
        // No automatic retry/removal if cancelled or blocked, even if an OEM reports RESULT_OK.
        verifyInstall(request.output, requireRemoved = true)
    }
    private fun verifyInstall(output: PatchOutput, confirmed: Boolean = false, requireRemoved: Boolean = false) {
        mutable.value = mutable.value.copy(busy = true, stage = R.string.nonroot_verifying, error = null,
            cancellable = false, installRequest = null)
        operation = viewModelScope.launch {
            try {
                val step = runInterruptible(Dispatchers.IO) { store.exclusive {
                    PatchOutputVerifier.verify(output.file, output.receipt)
                    val installed = installedIdentity(output.packageName)
                    if (requireRemoved && !PatchInstallPolicy.removed(installed)) return@exclusive null
                    when (PatchInstallPolicy.route(output.packageName, output.signer, installed)) {
                        PatchInstallRoute.INSTALL -> PatchInstallStep.INSTALL
                        PatchInstallRoute.CONFIRM_UNINSTALL -> if (confirmed) PatchInstallStep.UNINSTALL else PatchInstallStep.CONFIRM_UNINSTALL
                    }
                } }
                coroutineContext.ensureActive()
                // Retained state, not an Activity callback: rotation cannot skip or relaunch a hand-off.
                mutable.value = if (step == null) mutable.value.copy(busy = false,
                    stage = R.string.nonroot_uninstall_not_completed, installRequest = null)
                else mutable.value.copy(stage = if (step == PatchInstallStep.INSTALL) R.string.nonroot_ready
                    else R.string.nonroot_uninstall_required, installRequest = PatchInstallRequest(output, step))
            } catch (error: CancellationException) {
                mutable.value = mutable.value.copy(busy = false, installRequest = null); throw error
            }
            catch (error: Exception) { fail(error) }
        }
    }
    @Suppress("DEPRECATION")
    private fun installedIdentity(packageName: String): InstalledPatchIdentity? {
        if (Build.VERSION.SDK_INT < 28) throw IllegalStateException("Android 9+ required")
        val info = try { context.packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES) }
        catch (_: PackageManager.NameNotFoundException) { return null }
        val signers = requireNotNull(info.signingInfo?.apkContentsSigners).map {
            it.toByteArray().inputStream().use(ApkFiles::digest)
        }.toSet()
        val flags = requireNotNull(info.applicationInfo).flags
        return InstalledPatchIdentity(signers, flags and (android.content.pm.ApplicationInfo.FLAG_SYSTEM or
            android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0)
    }
    fun installLaunched(request: PatchInstallRequest) {
        if (mutable.value.installRequest != request) return
        val next = when (request.step) {
            PatchInstallStep.UNINSTALL -> PatchInstallStep.WAIT_UNINSTALL
            PatchInstallStep.INSTALL -> PatchInstallStep.WAIT_INSTALL
            else -> return
        }
        mutable.value = mutable.value.copy(installRequest = request.copy(step = next),
            stage = if (next == PatchInstallStep.WAIT_UNINSTALL) R.string.nonroot_wait_uninstall else R.string.nonroot_wait_install)
    }
    fun installReturned() {
        if (mutable.value.installRequest?.step == PatchInstallStep.WAIT_INSTALL)
            mutable.value = mutable.value.copy(busy = false, stage = R.string.nonroot_ready, installRequest = null)
        refreshInstalled()
    }
    fun refreshInstalled() {
        val output = mutable.value.output ?: return
        viewModelScope.launch {
            val matches = runInterruptible(Dispatchers.IO) { runCatching {
                if (Build.VERSION.SDK_INT < 28) return@runCatching false
                @Suppress("DEPRECATION")
                val info = context.packageManager.getPackageInfo(output.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                info.signingInfo?.apkContentsSigners?.singleOrNull()?.toByteArray()?.inputStream()?.use(ApkFiles::digest) == output.signer &&
                    ApkFiles.digest(File(requireNotNull(info.applicationInfo).sourceDir)) == output.sha256
            }.getOrDefault(false) }
            if (mutable.value.output?.file == output.file) mutable.value = mutable.value.copy(output = output.copy(installed = matches))
        }
    }
    fun showError(error: Exception) = fail(error)
    private fun fail(error: Exception) { mutable.value = mutable.value.copy(busy = false,
        cancellable = false, installRequest = null, error = (error.message ?: error.javaClass.simpleName).take(240)) }
}
