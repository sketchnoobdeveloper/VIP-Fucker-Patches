package snd.vip.fucker.nonroot

import snd.vip.fucker.core.Profiles

data class InstalledPatchIdentity(val signers: Set<String>, val systemApp: Boolean = false)
enum class PatchInstallRoute { INSTALL, CONFIRM_UNINSTALL }
enum class PatchInstallStep { CONFIRM_UNINSTALL, UNINSTALL, WAIT_UNINSTALL, INSTALL, WAIT_INSTALL }
data class PatchInstallRequest(val output: PatchOutput, val step: PatchInstallStep)

/** Same package does not imply update compatibility. Never remove an app just to refresh it. */
object PatchInstallPolicy {
    fun route(packageName: String, signer: String, installed: InstalledPatchIdentity?): PatchInstallRoute {
        require(Profiles.byPackage(packageName)?.wrapperSupported == true) {
            "Not a registered wrapper target; use the direct smali patch where provided"
        }
        require(signer.matches(Regex("[0-9a-f]{64}"))) { "Invalid output signing identity" }
        if (installed == null) return PatchInstallRoute.INSTALL
        require(installed.signers.isNotEmpty() && installed.signers.all { it.matches(Regex("[0-9a-f]{64}")) }) {
            "Installed signing identity unavailable"
        }
        if (installed.signers == setOf(signer)) return PatchInstallRoute.INSTALL
        require(!installed.systemApp) { "Cannot replace a system app with a differently signed APK" }
        return PatchInstallRoute.CONFIRM_UNINSTALL
    }

    /** Android/OEM result codes alone are not evidence that removal happened. */
    fun removed(installed: InstalledPatchIdentity?) = installed == null
}
