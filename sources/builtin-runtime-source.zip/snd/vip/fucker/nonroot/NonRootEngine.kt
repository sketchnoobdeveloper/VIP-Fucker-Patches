package snd.vip.fucker.nonroot

import com.android.apksig.ApkVerifier
import com.android.tools.build.apkzlib.sign.SigningExtension
import com.android.tools.build.apkzlib.sign.SigningOptions
import com.android.tools.build.apkzlib.zip.AlignmentRules
import com.android.tools.build.apkzlib.zip.ZFile
import com.android.tools.build.apkzlib.zip.ZFileOptions
import com.android.tools.build.apkzlib.bytestorage.ChunkBasedByteStorageFactory
import com.android.tools.build.apkzlib.bytestorage.OverflowToDiskByteStorageFactory
import com.android.tools.build.apkzlib.bytestorage.TemporaryDirectoryFactory
import com.google.gson.Gson
import com.wind.meditor.core.ManifestEditor
import com.wind.meditor.property.AttributeItem
import com.wind.meditor.property.ModificationProperty
import org.lsposed.lspatch.share.Constants
import org.json.JSONObject
import snd.vip.fucker.core.Config
import snd.vip.fucker.core.ConfigJson
import snd.vip.fucker.core.NonRootConfig
import snd.vip.fucker.core.Profile
import snd.vip.fucker.core.Profiles
import snd.vip.fucker.recipe.RootPatchVerifier
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.security.KeyStore
import java.security.cert.X509Certificate
import java.util.Base64
import java.util.zip.ZipFile

/** GPL-3.0: adapted from JingMatrix/LSPatch ApkPatcher at the commit in vendor-lock.json.
 * Only integrated mode, one supplied module, optional app-local signature compatibility.
 * No installer bypass/downgrade/provider injection.
 * The original signed APK is preserved byte-for-byte in a nested ZIP.
 */
class NonRootEngine(private val key: KeyStore.PrivateKeyEntry, private val scratchDirectory: File? = null,
    private val payload: (String) -> InputStream) {
    companion object {
        val ABIS = listOf("arm64-v8a", "armeabi-v7a", "x86", "x86_64")
        const val PAGE = 16384
        fun signatureEntry(name: String) = Regex("META-INF/(?:MANIFEST\\.MF|[^/]+\\.(?:SF|RSA|DSA|EC))", RegexOption.IGNORE_CASE).matches(name)
    }
    private fun options(destination: File): ZFileOptions {
        val scratch = File(scratchDirectory ?: destination.parentFile, "backend")
        require(scratch.isDirectory || scratch.mkdirs()) { "Cannot create backend scratch directory" }
        return ZFileOptions().setAlignmentRule(AlignmentRules.compose(
            AlignmentRules.constantForSuffix(".so", PAGE), AlignmentRules.constantForSuffix(ApkFiles.ORIGINAL, PAGE),
            AlignmentRules.constant(4))).setStorageFactory(ChunkBasedByteStorageFactory(
                OverflowToDiskByteStorageFactory(4L * 1024 * 1024, TemporaryDirectoryFactory.fixed(scratch))))
    }
    private fun signer(zip: ZFile) {
        val certificates = key.certificateChain.map { it as X509Certificate }.toTypedArray()
        SigningExtension(SigningOptions.builder().setMinSdkVersion(28).setV2SigningEnabled(true)
            .setCertificates(*certificates).setKey(key.privateKey).build()).register(zip)
    }
    fun verify(file: File, ownKey: Boolean = false) {
        val result = ApkVerifier.Builder(file).setMinCheckedPlatformVersion(28).build().verify()
        require(result.isVerified) { "APK signature verification failed" }
        if (ownKey) require(result.signerCertificates.size == 1 &&
            result.signerCertificates.single().encoded.contentEquals(key.certificate.encoded)) { "Unexpected APK signer" }
    }

    fun configureModule(source: File, destination: File, profile: Profile, config: Config, originalSha256: String): ByteArray {
        require(profile.wrapperSupported) { "Target does not support the non-root wrapper" }
        require(!destination.exists())
        val template = ApkFiles.inspect(source)
        require(template.packageName == "snd.vip.fucker" && !template.patched) { "Module template must be the plain manager APK" }
        verify(source)
        val rootAsset = profile.rootPatchAsset?.let {
            RootPatchVerifier.bundled(source, profile)
            "assets/$it"
        }
        val scoped = Config(config.values.filterKeys { it.startsWith("${profile.id}.") })
        val document = JSONObject().put("schema", 2).put("package", profile.packageName)
            .put("originalSha256", originalSha256).put("config", JSONObject(ConfigJson.export(scoped))).toString()
        NonRootConfig.parse(document, profile)
        val bytes = document.toByteArray(Charsets.UTF_8)
        ZipFile(source).use { src -> ZFile.openReadWrite(destination, options(destination)).use { dst ->
            signer(dst)
            src.entries().asSequence().forEach { entry ->
                if (Thread.currentThread().isInterrupted) throw InterruptedException()
                if (signatureEntry(entry.name) || entry.name == NonRootConfig.ASSET || entry.name.startsWith("assets/nonroot-loader/") ||
                    entry.name.startsWith("assets/nonroot-signer/") || entry.name.startsWith("assets/patch-recipes/") ||
                    (entry.name.startsWith("assets/root-patches/") && entry.name != rootAsset)) return@forEach
                ApkFiles.bounded(src.getInputStream(entry), entry.size).use { dst.add(entry.name, it, !entry.name.endsWith(".so")) }
            }
            dst.add(NonRootConfig.ASSET, ByteArrayInputStream(bytes))
            dst.realign()
        } }
        verify(destination, true)
        require(NonRootConfig.read(destination.path, profile).config == scoped) { "Module snapshot mismatch" }
        if (rootAsset != null) require(RootPatchVerifier.bundled(destination, profile) == RootPatchVerifier.bundled(source, profile))
        return bytes
    }

    fun patch(original: File, module: File, destination: File, archive: ApkArchive, signatureCompatibility: Boolean = true) {
        require(!destination.exists() && !archive.patched)
        require(ApkFiles.inspect(original) == archive) { "Input APK identity changed" }
        val profile = requireNotNull(Profiles.byPackage(archive.packageName)) { "Unregistered target APK" }
        val snapshot = NonRootConfig.read(module.path, profile)
        require(snapshot.present && snapshot.config != null && snapshot.originalSha256 == ApkFiles.digest(original)) {
            "Module is not bound to this original APK"
        }
        // Compatibility-off retains unsigned/re-signed input support. Compatibility-on
        // additionally needs a verified single signer; neither mode requires the reference
        // developer's certificate. The original bytes remain bound to the module digest.
        verify(module, true)
        if (profile.rootPatchAsset != null) {
            val patch = RootPatchVerifier.bundled(module, profile)
            val actions = profile.actions.filter { snapshot.config.action(profile, it) }.map { it.id }.toSet()
            if (actions.isNotEmpty()) RootPatchVerifier.verify(original, patch.operations.filter { it.action in actions })
        }
        val budget = WrapperBudget.output(original.length(), module.length(), archive)
        require(budget < ApkFiles.MAX_APK) { "Patched APK exceeds output budget" }
        // Read the actual original certificate before writing an output. Do not substitute
        // the shared patch certificate or infer a certificate from a common name.
        val config = PatchSignaturePolicy.configuration(original, archive.factory, signatureCompatibility)
        val bytes = Gson().toJson(config).toByteArray(Charsets.UTF_8)
        val changes = ModificationProperty()
        if (archive.minSdk < 28) changes.addUsesSdkAttribute(AttributeItem("minSdkVersion", 28))
        changes.addApplicationAttribute(AttributeItem("debuggable", false))
        changes.addApplicationAttribute(AttributeItem("appComponentFactory", Constants.PROXY_APP_COMPONENT_FACTORY))
        changes.addMetaData(ModificationProperty.MetaData("lspatch", Base64.getEncoder().encodeToString(bytes)))
        ZFile.openReadWrite(destination, options(destination)).use { dst ->
            dst.addNestedZip({ ApkFiles.ORIGINAL }, original, false).use { src ->
                signer(dst)
                val manifest = ByteArrayOutputStream()
                requireNotNull(src.get("AndroidManifest.xml")).open().use { ManifestEditor(it, manifest, changes).processManifest() }
                dst.add("AndroidManifest.xml", ByteArrayInputStream(manifest.toByteArray()))
                dst.add(ApkFiles.CONFIG, ByteArrayInputStream(bytes))
                payload("metaloader.dex").use { dst.add("classes.dex", it) }
                payload("loader.dex").use { dst.add(Constants.LOADER_DEX_ASSET_PATH, it) }
                for (abi in ABIS) payload("so/$abi/liblspatch.so").use { dst.add("assets/lspatch/so/$abi/liblspatch.so", it, false) }
                module.inputStream().use { dst.add(ApkFiles.MODULE, it) }
                for (entry in src.entries()) {
                    if (Thread.currentThread().isInterrupted) throw InterruptedException()
                    val name = entry.centralDirectoryHeader.name
                    require(!name.startsWith("assets/lspatch/")) { "Unexpected reserved LSPatch member" }
                    if (dst.get(name) != null || name == "AndroidManifest.xml" || signatureEntry(name) || Regex("classes\\d*\\.dex").matches(name)) continue
                    // Copy native members into newly page-aligned outer entries; all other payloads are links.
                    if (name.endsWith(".so")) ApkFiles.bounded(entry.open(), entry.centralDirectoryHeader.uncompressedSize)
                        .use { dst.add(name, it, false) }
                    else require(src.addFileLink(name, name)) { "Unable to link original APK member: $name" }
                }
                dst.realign()
            }
        }
        require(destination.length() in 1..ApkFiles.MAX_APK && destination.length() <= budget) { "Actual patched APK exceeds output budget" }
        verify(destination, true)
        ApkAlignment.verify(destination)
        val result = ApkFiles.inspect(destination)
        require(result.patched && result.packageName == archive.packageName && result.versionCode == archive.versionCode)
        ZipFile(destination).use { zip ->
            require(zip.entries().asSequence().filter { it.name.startsWith("assets/lspatch/modules/") }
                .map { it.name }.toSet() == setOf(ApkFiles.MODULE)) { "Unexpected embedded module inventory" }
            require(zip.getInputStream(zip.getEntry(ApkFiles.ORIGINAL)).use(ApkFiles::digest) == ApkFiles.digest(original)) { "Original APK not intact" }
            require(zip.getInputStream(zip.getEntry(ApkFiles.MODULE)).use(ApkFiles::digest) == ApkFiles.digest(module)) { "Embedded module not intact" }
            val storedConfig = zip.getInputStream(zip.getEntry(ApkFiles.CONFIG)).use { it.readBytes() }
            require(storedConfig.contentEquals(bytes))
        }
    }
}
