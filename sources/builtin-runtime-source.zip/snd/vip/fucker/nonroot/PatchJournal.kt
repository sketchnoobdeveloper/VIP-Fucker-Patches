package snd.vip.fucker.nonroot

import java.io.FileOutputStream

/** Keep rollback strictly before finish: old Android AtomicFile can delete the base on failWrite. */
object PatchJournal {
    fun commit(bytes: ByteArray, start: () -> FileOutputStream, finish: (FileOutputStream) -> Unit,
        rollback: (FileOutputStream) -> Unit, read: () -> ByteArray, syncDirectory: () -> Unit,
        syncFile: (FileOutputStream) -> Unit = { it.fd.sync() }) {
        require(bytes.size.toLong() in 1..PatchReceipt.MAX_RECORD)
        val stream = start()
        try {
            stream.write(bytes)
            syncFile(stream) // Do not rely on AtomicFile's log-only sync error handling.
            finish(stream)
        } catch (error: Exception) {
            try { rollback(stream) } catch (cleanup: Exception) { error.addSuppressed(cleanup) }
            throw error
        }
        // A finished journal must never be passed to failWrite, even if these checks fail.
        require(read().contentEquals(bytes)) { "Patch journal commit read-back failed" }
        syncDirectory()
    }
}
