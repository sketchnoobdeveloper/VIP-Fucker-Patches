package snd.vip.fucker.nonroot

import java.io.File
import java.util.zip.ZipFile

/** Original-byte binding for bundled hooks; only the uniquely owned temporary file is deleted. */
object HookOriginalApk {
    fun <T> use(source: File, expectedSha256: String, scratch: File, block: (File) -> T): T {
        require(Regex("[a-f0-9]{64}").matches(expectedSha256))
        require(source.isFile && source.length() in 1..ApkFiles.MAX_APK)
        if (ApkFiles.digest(source) == expectedSha256) {
            require(!ApkFiles.inspect(source).patched) { "Expected an original standalone APK" }
            return block(source)
        }
        val outer = ApkFiles.inspect(source)
        require(outer.patched) { "Original APK identity mismatch" }
        require(scratch.isDirectory && scratch.canonicalFile == scratch.absoluteFile) { "Unsafe preflight scratch" }
        return ZipFile(source).use { zip ->
            val entry = zip.entries().asSequence().filter { it.name == ApkFiles.ORIGINAL }.toList().single()
            require(entry.size in 1..ApkFiles.MAX_APK && scratch.usableSpace > entry.size + 16L * 1024 * 1024) {
                "Original preflight storage budget exceeded"
            }
            val original = File.createTempFile("vip-hook-original-", ".apk", scratch)
            try {
                zip.getInputStream(entry).use { input -> ApkFiles.bounded(input, entry.size).use { bounded ->
                    original.outputStream().use { bounded.copyTo(it) }
                } }
                require(original.length() == entry.size && ApkFiles.digest(original) == expectedSha256) {
                    "Embedded original identity mismatch"
                }
                val archive = ApkFiles.inspect(original)
                require(!archive.patched && archive.packageName == outer.packageName && archive.versionCode == outer.versionCode &&
                    archive.versionName == outer.versionName) { "Nested original identity mismatch" }
                block(original)
            } finally { original.delete() }
        }
    }
}
