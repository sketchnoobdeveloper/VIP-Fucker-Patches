package snd.vip.fucker.nonroot

/** Public key-material identities; immutable across releases unless migration is deliberate. */
object SharedPatchKey {
    const val PKCS12_SHA256 = "87769688a81b740e80bc9d30e2585127d004a65f9af10751ce14e8ffc8f1e690"
    const val JKS_SHA256 = "18030a33c471456540a537b91fb88be88b9841d5e3c6d234582f06fc571f406d"
    const val CERTIFICATE_SHA256 = "8aa67011b6ce0b24d9e73ded85f39e46acc7bec30abea372fd639cb7b056841d"
}
