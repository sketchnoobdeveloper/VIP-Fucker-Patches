package snd.vip.fucker.nonroot

import pxb.android.axml.AxmlParser
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.io.FilterInputStream
import java.security.MessageDigest
import java.util.zip.ZipFile

/** Strict, bounded APK inspection. Never extracts member-controlled paths. */
data class ApkArchive(val packageName: String, val versionCode: Long, val versionName: String?,
    val minSdk: Int, val factory: String?, val nativeAbis: Set<String>, val patched: Boolean,
    val materializedBytes: Long = 0, val entryCount: Int = 0,
    val wrapperOverheadBytes: Long = entryCount.toLong() * NonRootEngine.PAGE)

object ApkFiles {
    const val MAX_APK = 512L * 1024 * 1024
    const val MAX_MANIFEST = 4L * 1024 * 1024
    const val ORIGINAL = "assets/lspatch/origin.apk"
    const val MODULE = "assets/lspatch/modules/snd.vip.fucker.apk"
    const val CONFIG = "assets/lspatch/config.json"
    private const val ANDROID = "http://schemas.android.com/apk/res/android"
    private val androidAttributes = mapOf(0x0101021b to "versionCode", 0x0101021c to "versionName",
        0x01010576 to "versionCodeMajor", 0x0101020c to "minSdkVersion", 0x0101057a to "appComponentFactory",
        0x0101000b to "sharedUserId", 0x01010591 to "isSplitRequired", 0x0101064e to "requiredSplitTypes",
        0x010103a9 to "isolatedProcess", 0x01010597 to "useAppZygote", 0x01010003 to "name", 0x01010024 to "value")

    fun bounded(input: InputStream, limit: Long): InputStream {
        require(limit in 0..MAX_APK)
        return object : FilterInputStream(input) {
            private var consumed = 0L
            override fun read(): Int {
                if (Thread.currentThread().isInterrupted) throw InterruptedException()
                val result = `in`.read()
                if (result >= 0) require(++consumed <= limit) { "Decompression budget exceeded" }
                return result
            }
            override fun read(bytes: ByteArray, offset: Int, length: Int): Int {
                if (Thread.currentThread().isInterrupted) throw InterruptedException()
                val count = `in`.read(bytes, offset, minOf(length.toLong(), limit - consumed + 1).toInt())
                require(count != 0 || length == 0) { "Input stream made no progress" }
                if (count > 0) { consumed += count; require(consumed <= limit) { "Decompression budget exceeded" } }
                return count
            }
            override fun skip(count: Long): Long {
                val buffer = ByteArray(4096)
                var skipped = 0L
                while (skipped < count) {
                    val read = read(buffer, 0, minOf(buffer.size.toLong(), count - skipped).toInt())
                    if (read < 0) break
                    skipped += read
                }
                return skipped
            }
        }
    }

    fun copy(input: InputStream, output: OutputStream, limit: Long = MAX_APK): Long {
        require(limit in 0..MAX_APK)
        val buffer = ByteArray(65536)
        var total = 0L
        while (true) {
            if (Thread.currentThread().isInterrupted) throw InterruptedException()
            val count = input.read(buffer)
            if (count < 0) return total
            require(count > 0) { "Input stream made no progress" }
            total += count
            require(total <= limit) { "File budget exceeded" }
            output.write(buffer, 0, count)
        }
    }

    fun digest(input: InputStream): String {
        val hash = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(65536)
        while (true) {
            if (Thread.currentThread().isInterrupted) throw InterruptedException()
            val count = input.read(buffer)
            if (count < 0) break
            require(count > 0) { "Input stream made no progress" }
            hash.update(buffer, 0, count)
        }
        return hash.digest().joinToString("") { "%02x".format(it) }
    }
    fun digest(file: File) = file.inputStream().use(::digest)

    fun inspect(file: File): ApkArchive {
        require(file.length() in 1..MAX_APK) { "APK size not supported" }
        ZipFile(file).use { zip ->
            val names = HashSet<String>()
            val abis = HashSet<String>()
            var inflated = 0L
            var materialized = 0L
            var wrapperOverhead = 0L
            zip.entries().asSequence().forEach { entry ->
                require(names.size < 100000 && names.add(entry.name)) { "Duplicate/excessive ZIP entries" }
                require(!entry.name.startsWith('/') && '\\' !in entry.name && entry.name.split('/').none { it == ".." }) { "Unsafe ZIP name" }
                require(entry.size in 0..MAX_APK) { "Invalid ZIP size" }
                inflated += entry.size
                require(inflated <= 2L * 1024 * 1024 * 1024) { "ZIP expansion budget exceeded" }
                if (entry.name.endsWith(".so")) materialized += entry.size
                require(materialized <= MAX_APK) { "Native materialization budget exceeded" }
                wrapperOverhead += WrapperBudget.memberOverhead(entry)
                require(wrapperOverhead <= MAX_APK) { "Wrapper metadata budget exceeded" }
                Regex("lib/([^/]+)/[^/]+\\.so").matchEntire(entry.name)?.let { abis += it.groupValues[1] }
            }
            require("classes.dex" in names) { "No primary DEX" }
            val entry = requireNotNull(zip.getEntry("AndroidManifest.xml")) { "No manifest" }
            require(entry.size in 1..MAX_MANIFEST) { "Manifest too large" }
            val bytes = zip.getInputStream(entry).use { input ->
                java.io.ByteArrayOutputStream().also { copy(input, it, MAX_MANIFEST) }.toByteArray()
            }
            AxmlFraming.validate(bytes)
            val parser = AxmlParser(bytes)
            var pkg: String? = null
            var version = 0L
            var major = 0L
            var name: String? = null
            var minimum = 1
            var factory: String? = null
            var split = false
            var sharedUid = false
            var metadata = false
            var applications = 0
            var sdkNodes = 0
            val tags = ArrayDeque<String>()
            fun truth(value: Any?): Boolean = when (value) {
                null -> false
                is Boolean -> value
                is Number -> value.toLong().also { require(it in setOf(0L, 1L, -1L)) {
                    "Resource-valued/invalid manifest boolean not supported"
                } } != 0L
                "true" -> true
                "false" -> false
                else -> throw IllegalArgumentException("Resource-valued/invalid manifest boolean not supported")
            }
            while (true) {
                val type = parser.next()
                if (type == AxmlParser.END_FILE) break
                if (type == AxmlParser.END_TAG) { tags.removeLast(); continue }
                if (type != AxmlParser.START_TAG) continue
                val tag = parser.name
                val depth = tags.size
                require(depth != 0 || tag == "manifest") { "Root element must be manifest" }
                require(tag != "manifest" || depth == 0) { "Nested manifest" }
                if (tag == "application") require(depth == 1 && ++applications == 1) { "Invalid/duplicate application" }
                if (tag == "uses-sdk") require(depth == 1 && ++sdkNodes == 1) { "Invalid/duplicate uses-sdk" }
                if (tag == "uses-split") { require(depth == 1); split = true }
                var metaName: String? = null
                var metaValue: Any? = null
                var metaValueType: Int? = null
                val attributes = HashSet<String>()
                for (index in 0 until parser.attributeCount) {
                    val namespace = parser.getAttrNs(index)
                    val localName = parser.getAttrName(index)
                    val mappedName = androidAttributes[parser.getAttrResId(index)]
                    val attr = when {
                        namespace == ANDROID && localName !in setOf("package", "split") -> mappedName ?: localName
                        namespace == null && mappedName != null -> mappedName
                        namespace == null && localName in setOf("package", "split") && tag == "manifest" -> localName
                        else -> continue
                    }
                    require(attributes.add(attr)) { "Duplicate manifest attribute" }
                    if (attr in setOf("isSplitRequired", "isolatedProcess", "useAppZygote"))
                        require(parser.getAttrType(index) in setOf(3, 16, 18)) { "Resource-valued manifest boolean not supported" }
                    if (attr in setOf("versionCode", "versionCodeMajor", "minSdkVersion"))
                        require(parser.getAttrType(index) in setOf(16, 17)) { "Resource-valued/preview integer not supported" }
                    val value = parser.getAttrValue(index)
                    when (tag) {
                        "manifest" -> when (attr) {
                            "package" -> pkg = value?.toString()
                            "versionCode" -> version = (value as? Number)?.toLong()?.and(0xffffffffL) ?: 0
                            "versionCodeMajor" -> major = (value as? Number)?.toLong()?.also { require(it in 0..0x7fffffffL) } ?: 0
                            "versionName" -> name = value as? String
                            "split" -> split = split || !value?.toString().isNullOrEmpty()
                            "sharedUserId" -> sharedUid = !value?.toString().isNullOrEmpty()
                            "isSplitRequired" -> split = split || truth(value)
                            "requiredSplitTypes" -> split = split || !value?.toString().isNullOrEmpty()
                        }
                        "uses-sdk" -> if (attr == "minSdkVersion") minimum = (value as? Number)?.toInt()
                            ?: throw IllegalArgumentException("Preview SDK not supported")
                        "application" -> when (attr) {
                            "appComponentFactory" -> factory = (value as? String)
                                ?: throw IllegalArgumentException("Resource-valued factory not supported")
                            "isSplitRequired" -> split = split || truth(value)
                            "requiredSplitTypes" -> split = split || !value?.toString().isNullOrEmpty()
                        }
                        "service" -> if (depth == 2 && tags.lastOrNull() == "application" &&
                            attr in setOf("isolatedProcess", "useAppZygote")) require(!truth(value)) {
                            "Isolated/app-zygote services require an unsupported DEX injection mode"
                        }
                        "meta-data" -> when (attr) {
                            "name" -> metaName = value as? String
                            "value" -> { metaValue = value; metaValueType = parser.getAttrType(index) }
                        }
                    }
                }
                if (tag == "meta-data" && depth == 2 && tags.lastOrNull() == "application") {
                    if (metaName == "lspatch") metadata = true
                    if (metaName == "com.android.vending.splits.required") {
                        require(metaValueType == null || metaValueType in setOf(3, 16, 18)) { "Resource-valued split metadata not supported" }
                        split = split || truth(metaValue)
                    }
                }
                tags.addLast(tag)
            }
            require(applications == 1 && minimum >= 1) { "Invalid application/SDK declaration" }
            require(!split) { "Split APK/set required; choose a standalone APK" }
            require(!sharedUid) { "Shared-UID APK cannot be re-signed safely" }
            val patched = ORIGINAL in names
            require(patched == metadata) { "Incomplete/unknown existing patch" }
            require(patched || names.none { it.startsWith("assets/lspatch/") }) { "Reserved LSPatch assets in unpatched APK" }
            val packageName = requireNotNull(pkg)
            require(Regex("[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+").matches(packageName)) { "Invalid package" }
            factory = factory?.takeIf { it.isNotEmpty() }?.let {
                when { it.startsWith('.') -> packageName + it; '.' !in it -> "$packageName.$it"; else -> it }
            }
            return ApkArchive(packageName, (major shl 32) or version, name, minimum, factory, abis, patched,
                materialized, names.size, wrapperOverhead)
        }
    }

    fun recover(input: File, destination: File): File {
        val outer = inspect(input)
        if (!outer.patched) return input
        require(!destination.exists())
        ZipFile(input).use { zip -> zip.getInputStream(zip.getEntry(ORIGINAL)).use { source ->
            destination.outputStream().use { copy(source, it) }
        } }
        val original = inspect(destination)
        require(!original.patched && original.packageName == outer.packageName && original.versionCode == outer.versionCode) {
            "Nested original identity mismatch"
        }
        return destination
    }
}
