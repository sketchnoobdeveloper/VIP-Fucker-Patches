package snd.vip.fucker.nonroot

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Validate allocation/progress bounds BEFORE giving untrusted bytes to the vendor parser/editor. */
object AxmlFraming {
    fun validate(bytes: ByteArray) {
        require(bytes.size in 8..ApkFiles.MAX_MANIFEST.toInt()) { "Invalid binary manifest size" }
        val data = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        fun u16(at: Int) = data.getShort(at).toInt() and 0xffff
        fun int(at: Int) = data.getInt(at)
        require(u16(0) == 3 && u16(2) == 8 && int(4) == bytes.size) { "Invalid XML document header" }
        var strings = -1
        var mapped = false
        var offset = 8
        var events = 0
        var roots = 0
        val elements = ArrayDeque<Pair<Int, Int>>()
        val namespaces = mutableListOf<Pair<Int, Int>>()
        fun ref(index: Int, optional: Boolean = false) {
            require(index in 0 until strings || optional && index == -1) { "Invalid manifest string reference" }
        }
        while (offset < bytes.size) {
            if (Thread.currentThread().isInterrupted) throw InterruptedException()
            require(++events <= 100000 && bytes.size - offset >= 8) { "Manifest event budget exceeded" }
            val type = u16(offset)
            val header = u16(offset + 2)
            val size = int(offset + 4)
            require(header >= 8 && size >= header && size <= bytes.size - offset && size % 4 == 0) { "Invalid XML chunk framing" }
            val end = offset + size
            when (type) {
                1 -> {
                    require(strings == -1 && roots == 0 && header == 28 && size >= 28) { "Invalid string pool header" }
                    strings = int(offset + 8)
                    val styles = int(offset + 12)
                    val flags = int(offset + 16)
                    val start = int(offset + 20)
                    val styleStart = int(offset + 24)
                    require(strings in 1..65536 && styles in 0..strings &&
                        (strings.toLong() + styles) * 4 <= size - header) { "String pool allocation budget exceeded" }
                    require(start >= header + (strings + styles) * 4 && start < size) { "Invalid string pool offset" }
                    require(styleStart == 0 && styles == 0) { "Styled manifest string pools are not supported" }
                    require(flags and 0x101.inv() == 0) { "Unknown string pool encoding" }
                    val utf8 = flags and 0x100 != 0
                    var decodedBudget = 0L
                    for (index in 0 until strings) {
                        val relative = int(offset + header + index * 4)
                        require(relative >= 0 && relative < size - start) { "Invalid string offset" }
                        var at = offset + start + relative
                        fun length8(): Int {
                            require(at < end)
                            val first = bytes[at++].toInt() and 0xff
                            if (first and 0x80 == 0) return first
                            require(at < end)
                            return ((first and 0x7f) shl 8) or (bytes[at++].toInt() and 0xff)
                        }
                        fun length16(): Int {
                            require(end - at >= 2)
                            val first = u16(at); at += 2
                            if (first and 0x8000 == 0) return first
                            // The pinned vendor decoder shifts extended lengths incorrectly.
                            throw IllegalArgumentException("Extended UTF-16 strings are not supported")
                        }
                        if (utf8) {
                            val characters = length8()
                            val length = length8()
                            require(length < end - at && bytes[at + length] == 0.toByte() && characters <= length) { "Truncated UTF-8 string" }
                            decodedBudget += length
                        } else {
                            val length = length16()
                            require((length.toLong() + 1) * 2 <= end - at && u16(at + length * 2) == 0) { "Truncated UTF-16 string" }
                            decodedBudget += length.toLong() * 2
                        }
                        require(decodedBudget <= 8L * 1024 * 1024) { "String decoding budget exceeded" }
                    }
                }
                0x180 -> {
                    require(strings > 0 && !mapped && roots == 0 && header == 8 && (size - 8) / 4 <= strings) { "Invalid resource map" }
                    mapped = true
                }
                0x100, 0x101, 0x102, 0x103, 0x104 -> {
                    require(strings > 0 && header == 16 && size >= 24) { "Invalid XML node header" }
                    ref(int(offset + 12), true)
                    when (type) {
                        0x100, 0x101 -> {
                            require(size == 24)
                            val pair = int(offset + 16) to int(offset + 20)
                            // The editor's reader cannot handle a -1 namespace prefix index.
                            ref(pair.first); ref(pair.second)
                            if (type == 0x100) {
                                require(namespaces.size < 64)
                                namespaces.add(pair)
                            } else require(namespaces.remove(pair)) { "Unbalanced XML namespace" }
                        }
                        0x102 -> {
                            require(size >= 36 && u16(offset + 24) == 20 && u16(offset + 26) == 20) { "Invalid XML attribute layout" }
                            val count = u16(offset + 28)
                            require(count <= 4096 && 36L + count * 20L == size.toLong()) { "Invalid XML attribute count" }
                            for (at in listOf(30, 32, 34)) require(u16(offset + at) <= count)
                            val pair = int(offset + 16) to int(offset + 20)
                            ref(pair.first, true); ref(pair.second)
                            if (elements.isEmpty()) require(++roots == 1) { "Multiple XML roots" }
                            require(elements.size < 64) { "Manifest depth budget exceeded" }
                            elements.addLast(pair)
                            val identities = HashSet<Pair<Int, Int>>()
                            for (index in 0 until count) {
                                val at = offset + 36 + index * 20
                                val identity = int(at) to int(at + 4)
                                ref(identity.first, true); ref(identity.second); ref(int(at + 8), true)
                                require(identities.add(identity) && u16(at + 12) == 8 && bytes[at + 14] == 0.toByte()) { "Invalid/duplicate XML attribute" }
                                if (bytes[at + 15].toInt() and 0xff == 3) ref(int(at + 16))
                            }
                        }
                        0x103 -> {
                            require(size == 24)
                            require(elements.removeLastOrNull() == (int(offset + 16) to int(offset + 20))) { "Unbalanced XML element" }
                        }
                        0x104 -> {
                            require(size == 28 && elements.isNotEmpty() && u16(offset + 20) == 8)
                            ref(int(offset + 16))
                            if (bytes[offset + 23].toInt() and 0xff == 3) ref(int(offset + 24))
                        }
                    }
                }
                else -> throw IllegalArgumentException("Unsupported binary XML chunk")
            }
            offset = end
        }
        require(roots == 1 && elements.isEmpty() && namespaces.isEmpty()) { "Incomplete XML document" }
    }
}
