package snd.vip.fucker.nonroot

import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.io.InputStream
import java.security.KeyStore
import java.security.MessageDigest
import javax.security.auth.x500.X500Principal

/** Public shared PATCH key, not the private manager release key or an original app identity.
 * JKS is retained for desktop tools; PKCS12 contains the same entry for Android.
 * Never generate/rotate a replacement on load failure. Legacy AndroidKeyStore keys are untouched.
 */
object NonRootSigner {
    const val ASSET = "nonroot-signer/patch-signer.p12"
    const val ALIAS = "vip-fucker-patch"
    // Intentionally public: embedding a password/key cannot make a shared signer secret.
    const val PASSWORD = "vip-fucker-public-patch-key"
    fun entry(open: (String) -> InputStream): KeyStore.PrivateKeyEntry {
        val bytes = open(ASSET).use { ApkFiles.bounded(it, 32 * 1024L).readBytes() }
        require(bytes.inputStream().use(ApkFiles::digest) == SharedPatchKey.PKCS12_SHA256) { "Bundled patch key integrity failure" }
        // Explicit provider avoids relying on Android's absent JKS provider or PKCS12 variants.
        val store = KeyStore.getInstance("PKCS12", BouncyCastleProvider()).apply {
            bytes.inputStream().use { load(it, PASSWORD.toCharArray()) }
        }
        val entry = requireNotNull(store.getEntry(ALIAS, KeyStore.PasswordProtection(PASSWORD.toCharArray())) as? KeyStore.PrivateKeyEntry) {
            "Shared patch signing key unavailable; not regenerated"
        }
        require(entry.certificateChain.size == 1 && entry.privateKey.algorithm == "RSA" &&
            (entry.certificate as java.security.cert.X509Certificate).subjectX500Principal == X500Principal("CN=VIP Fucker") &&
            fingerprint(entry) == SharedPatchKey.CERTIFICATE_SHA256) { "Unexpected shared patch signer" }
        return entry
    }
    fun fingerprint(entry: KeyStore.PrivateKeyEntry): String = MessageDigest.getInstance("SHA-256")
        .digest(entry.certificate.encoded).joinToString("") { "%02x".format(it) }
}
