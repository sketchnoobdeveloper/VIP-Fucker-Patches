package snd.vip.fucker.nonroot

import com.android.apksig.ApkVerifier
import java.io.File
import java.util.zip.ZipFile

/** Revalidate persisted/exported/installer inputs; receipt metadata alone is not proof. */
object PatchOutputVerifier {
    fun verify(file: File, receipt: PatchReceipt) {
        require(file.canonicalFile == file.absoluteFile && file.isFile && file.length() in 1..ApkFiles.MAX_APK &&
            (receipt.bytes == null || file.length() == receipt.bytes) && ApkFiles.digest(file) == receipt.sha256) { "Output integrity failure" }
        val signature = ApkVerifier.Builder(file).setMinCheckedPlatformVersion(28).build().verify()
        require(signature.isVerified && signature.isVerifiedUsingV2Scheme && signature.signerCertificates.size == 1 &&
            signature.signerCertificates.single().encoded.inputStream().use(ApkFiles::digest) == receipt.signer) { "Output signature mismatch" }
        val archive = ApkFiles.inspect(file)
        if (receipt.kind == "smali-method-v1") {
            snd.vip.fucker.recipe.RecipeApkEngine.verifyReceipt(file, archive, receipt)
            return
        }
        require(receipt.kind == "lspatch")
        require(archive.patched && archive.packageName == receipt.packageName && archive.versionName == receipt.version &&
            (receipt.versionCode == null || archive.versionCode == receipt.versionCode)) { "Output package identity mismatch" }
        ApkAlignment.verify(file)
        ZipFile(file).use { zip ->
            PatchSignaturePolicy.verifyStored(file, zip)
            require(zip.entries().asSequence().filter { it.name.startsWith("assets/lspatch/modules/") }
                .map { it.name }.toSet() == setOf(ApkFiles.MODULE)) { "Unexpected embedded module inventory" }
            for ((name, hash) in listOf(ApkFiles.ORIGINAL to receipt.originalSha256, ApkFiles.MODULE to receipt.moduleSha256)) {
                val entry = requireNotNull(zip.getEntry(name)) { "Missing embedded APK" }
                require(entry.size in 1..ApkFiles.MAX_APK && zip.getInputStream(entry).use {
                    ApkFiles.bounded(it, entry.size).use(ApkFiles::digest)
                } == hash) { "Embedded APK integrity failure" }
            }
        }
    }
}
