package snd.vip.fucker.nonroot

import java.io.File
import java.io.InputStream
import java.io.OutputStream

/** Provider success is reported only after close + bounded read-back of the stored bytes. */
object VerifiedApkExport {
    fun transfer(source: File, sha256: String, openOutput: () -> OutputStream, openInput: () -> InputStream) {
        require(source.isFile && source.length() in 1..ApkFiles.MAX_APK && ApkFiles.digest(source) == sha256) { "Export source integrity failure" }
        val expectedBytes = source.length()
        openOutput().use { target ->
            source.inputStream().use { require(ApkFiles.copy(it, target, expectedBytes) == expectedBytes) { "Export byte count mismatch" } }
        }
        openInput().use { input ->
            require(ApkFiles.bounded(input, expectedBytes).use(ApkFiles::digest) == sha256) { "Export read-back integrity failure" }
        }
    }
}
