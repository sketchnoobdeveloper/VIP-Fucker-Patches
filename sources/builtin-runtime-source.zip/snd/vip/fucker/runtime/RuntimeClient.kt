package snd.vip.fucker.runtime

import android.content.Context
import android.net.Uri
import snd.vip.fucker.core.*

data class RuntimeSnapshot(val reports: Map<String, StoredRuntime>, val boot: Int)
object RuntimeClient {
    val uri: Uri = Uri.parse("content://${RuntimeProtocol.AUTHORITY}")
    fun read(context: Context): RuntimeSnapshot {
        val result = requireNotNull(context.contentResolver.call(uri, "read", null, null))
        return RuntimeSnapshot(Profiles.all.mapNotNull { target ->
            result.getString(target.id)?.let { text -> target.id to StoredRuntime(RuntimeProtocol.decode(text),
                result.getLong("${target.id}.wall"), result.getLong("${target.id}.elapsed"), result.getInt("${target.id}.boot")) }
        }.toMap(), result.getInt("boot", -1))
    }
    fun clear(context: Context): Boolean = context.contentResolver.call(uri, "clear", null, null)?.getBoolean("cleared") == true
}
