package snd.vip.fucker.runtime

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.Binder
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import snd.vip.fucker.core.*

/** Exported for scoped target IPC. Authorization precedes decoding and every operation. */
class RuntimeProvider : ContentProvider() {
    private val lock = Any()
    override fun onCreate() = true
    private fun manager() = requireNotNull(context)
    private fun prefs() = manager().getSharedPreferences("runtime_reports_v1", android.content.Context.MODE_PRIVATE)
    private fun boot() = Settings.Global.getInt(manager().contentResolver, Settings.Global.BOOT_COUNT, -1)
    private fun requireManager() {
        if (!RuntimePolicy.canRead(Binder.getCallingUid(), manager().applicationInfo.uid)) throw SecurityException("Manager only")
    }
    private fun stored(id: String): StoredRuntime? = runCatching {
        val prefs = prefs()
        StoredRuntime(RuntimeProtocol.decode(requireNotNull(prefs.getString(id, null))),
            prefs.getLong("$id.wall", 0), prefs.getLong("$id.elapsed", 0), prefs.getInt("$id.boot", -1))
    }.getOrNull()

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle = synchronized(lock) {
        when (method) {
            "publish" -> {
                val target = Profiles.byId(arg ?: "") ?: throw SecurityException("Unknown target")
                val uid = Binder.getCallingUid()
                val packages = manager().packageManager.getPackagesForUid(uid)?.toSet().orEmpty()
                if (!RuntimePolicy.canPublish(uid, manager().applicationInfo.uid, packages, target)) {
                    throw SecurityException("Target UID required")
                }
                val report = RuntimeProtocol.decode(requireNotNull(extras?.getString("report")))
                require(report.target == target.id)
                val elapsed = SystemClock.elapsedRealtime()
                val boot = boot()
                val accepted = RuntimePolicy.accept(stored(target.id), report, boot, elapsed) && prefs().edit()
                    .putString(target.id, RuntimeProtocol.encode(report)).putLong("${target.id}.wall", System.currentTimeMillis())
                    .putLong("${target.id}.elapsed", elapsed).putInt("${target.id}.boot", boot).commit()
                Bundle().apply { putBoolean("accepted", accepted) }
            }
            "read" -> {
                requireManager()
                Bundle().apply {
                    putInt("boot", boot())
                    Profiles.all.forEach { target -> stored(target.id)?.let {
                        putString(target.id, RuntimeProtocol.encode(it.report))
                        putLong("${target.id}.wall", it.receivedWall)
                        putLong("${target.id}.elapsed", it.receivedElapsed)
                        putInt("${target.id}.boot", it.boot)
                    } }
                }
            }
            "clear" -> {
                requireManager()
                Bundle().apply { putBoolean("cleared", prefs().edit().clear().commit()) }
            }
            else -> throw UnsupportedOperationException("Unsupported runtime operation")
        }
    }
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor? {
        requireManager(); throw UnsupportedOperationException()
    }
    override fun getType(uri: Uri): String? { requireManager(); return null }
    override fun insert(uri: Uri, values: ContentValues?): Uri? { requireManager(); throw UnsupportedOperationException() }
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int { requireManager(); throw UnsupportedOperationException() }
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int { requireManager(); throw UnsupportedOperationException() }
}
