package snd.vip.fucker.hook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XC_MethodReplacement
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.XSharedPreferences
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.callbacks.XC_LoadPackage
import android.app.Application
import android.content.Context
import snd.vip.fucker.core.*
import snd.vip.fucker.nonroot.ApkFiles
import snd.vip.fucker.nonroot.HookOriginalApk
import snd.vip.fucker.recipe.RootPatchVerifier
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class MainHook : IXposedHookLoadPackage, IXposedHookZygoteInit {
    private val attached = AtomicBoolean(false)
    private var modulePath: String? = null
    override fun initZygote(param: IXposedHookZygoteInit.StartupParam) {
        modulePath = param.modulePath
    }
    override fun handleLoadPackage(param: XC_LoadPackage.LoadPackageParam) {
        if (param.packageName == Config.MODULE && param.processName == Config.MODULE) {
            XposedHelpers.findAndHookMethod("snd.vip.fucker.core.Activation", param.classLoader,
                "isActive", XC_MethodReplacement.returnConstant(true))
        }
        val profile = Profiles.byPackage(param.packageName) ?: return
        if (!profile.runnable || param.processName != profile.packageName) return
        // Even disabled/unreadable targets report lifecycle status; feature hooks remain off.
        val embedded = NonRootConfig.read(modulePath, profile)
        val config = if (embedded.present) {
            log("${profile.id}: embedded configuration; manager switches do not update this snapshot")
            embedded.config
        } else try {
            val prefs = XSharedPreferences(Config.MODULE, Config.PREFS)
            prefs.reload()
            if (prefs.getInt("schema", 0) != Config.SCHEMA) {
                log("${profile.id}: unreadable/missing config; skipped")
                null
            } else {
                Config.validate(prefs.all.filterKeys { it != "schema" })
            }
        } catch (_: Throwable) {
            log("${profile.id}: config read failed; skipped")
            null
        }
        XposedHelpers.findAndHookMethod(Application::class.java, "attach", Context::class.java,
            object : XC_MethodHook() {
                override fun afterHookedMethod(p: MethodHookParam) {
                    if (p.hasThrowable()) return
                    val context = p.args[0] as? Context ?: return
                    if (context.packageName != profile.packageName || !attached.compareAndSet(false, true)) return
                    // Telemetry creation/transport is best effort and never gates actual hooks.
                    val reporter = runCatching { RuntimeReporter(context, profile, config).also { it.start() } }.getOrNull()
                    fun report(state: RuntimeState, failure: RuntimeFailure = RuntimeFailure.NONE) {
                        runCatching { reporter?.state(state, failure) }
                    }
                    if (config == null) { report(RuntimeState.CONFIG_UNAVAILABLE); return }
                    if (!config.requiresHooks(profile)) {
                        report(RuntimeState.DISABLED); return
                    }
                    val transaction = HookTransaction(signalObserver = { key -> reporter?.signal(key); Unit }) {
                        key, error -> runCatching { reporter?.observe(key, error) }; Unit
                    }
                    try {
                        val app = installedApp(context, profile)
                        if (app == null) { report(RuntimeState.BUILD_REJECTED, RuntimeFailure.METADATA_UNAVAILABLE); return }
                        // Embedded snapshots bind the original target, which the loader may expose
                        // either as sourceDir or as the nested origin.apk inside the wrapper. Verify
                        // the bytes ourselves; never trust the claimed hash alone.
                        val digest = if (embedded.originalSha256 != null) {
                            originalDigest(context.applicationInfo.sourceDir, embedded.originalSha256)
                        } else if (profile.hasReference) {
                            runCatching { ArtifactIdentity.sha256(File(app.apkPath)) }.getOrNull()
                        } else null
                        if (embedded.originalSha256 != null && digest != embedded.originalSha256) {
                            report(RuntimeState.BUILD_REJECTED, RuntimeFailure.BUILD_POLICY)
                            log("${profile.id}: embedded original identity mismatch; skipped")
                            return
                        }
                        val match = TargetPolicy.inspect(profile, app.code, app.version, digest, app.hasSplits)
                        runCatching { reporter?.build(app, match) }
                        if (!TargetPolicy.mayAttempt(profile, match, config.allowUnverified(profile))) {
                            report(RuntimeState.BUILD_REJECTED, RuntimeFailure.BUILD_POLICY)
                            log("${profile.id}: build rejected: $match")
                            return
                        }
                        if (match != BuildMatch.VERIFIED) {
                            log("${profile.id}: explicit unverified-build mode; $match; ${app.version}/${app.code}; selectors still required")
                        }
                        if (profile.rootPatchAsset != null) {
                            require(!app.hasSplits && (!embedded.present || profile.rootWrapperSupported))
                            val patch = RootPatchVerifier.bundled(File(requireNotNull(modulePath)), profile)
                            val actions = profile.actions.filter { config.action(profile, it) }.map { it.id }.toSet()
                            if (embedded.present) {
                                HookOriginalApk.use(File(context.applicationInfo.sourceDir), requireNotNull(embedded.originalSha256),
                                    context.cacheDir.canonicalFile) { original ->
                                    RootAssetHooks.install(original, patch, context.classLoader, transaction, actions)
                                }
                            } else RootAssetHooks.install(File(app.apkPath), patch, context.classLoader, transaction, actions)
                        } else when (profile.hookFamily) {
                            "telegram" -> TelegramHooks.install(context.classLoader, transaction,
                                profile.actions.filter { config.action(profile, it) }.map { it.id }.toSet())
                            "tm" -> TmProfile.install(context.classLoader, transaction,
                                config.action(profile, profile.actions.single { it.id == "timer" }),
                                config.action(profile, profile.actions.single { it.id == "ads" }))
                            "idm" -> IdmProfile.install(context, transaction,
                                profile.actions.filter { config.action(profile, it) }.map { it.id }.toSet())
                             "netcut" -> NetcutProfile.install(context.classLoader, transaction,
                                 profile.actions.filter { config.action(profile, it) }.map { it.id }.toSet())
                            else -> error("Unsupported hook family")
                        }
                        log("${profile.id}: ${transaction.size} hooks installed; runtime behavior unverified")
                        runCatching { reporter?.installed(transaction.size, transaction.observationComplete) }
                    } catch (error: Throwable) {
                        transaction.rollback()
                        report(RuntimeState.INSTALL_FAILED, RuntimeFailure.SELECTOR_OR_INSTALL)
                        log("${profile.id}: skipped/rolled back (${error.javaClass.simpleName}: ${error.message})")
                    }
                }
            })
    }

    /** Digest of the loader's original APK, or of the wrapper's embedded copy, else null. */
    private fun originalDigest(sourceDir: String, expected: String): String? {
        val file = File(sourceDir)
        runCatching { ArtifactIdentity.sha256(file) }.getOrNull()?.let { if (it == expected) return it }
        return runCatching {
            java.util.zip.ZipFile(file).use { zip ->
                val entry = zip.getEntry("assets/lspatch/origin.apk") ?: return@use null
                zip.getInputStream(entry).use(ApkFiles::digest).takeIf { it == expected }
            }
        }.getOrNull()
    }
}
