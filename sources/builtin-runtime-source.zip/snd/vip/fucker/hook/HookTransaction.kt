package snd.vip.fucker.hook

import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import java.lang.reflect.Method
import java.lang.reflect.Member
import java.lang.reflect.Constructor
import java.lang.reflect.Modifier
import snd.vip.fucker.core.BoundaryIdentity
import snd.vip.fucker.core.NetcutSignal

class HookTransaction(private val signalObserver: ((NetcutSignal) -> Unit)? = null,
                      private val observer: ((String, Boolean) -> Unit)? = null) {
    private val hooks = mutableListOf<XC_MethodHook.Unhook>()
    private val observations = mutableListOf<XC_MethodHook.Unhook>()
    private val observed = mutableSetOf<Member>()
    private var featureCount = 0
    var observationComplete = true
        private set
    val size get() = featureCount
    fun hook(method: Member, callback: XC_MethodHook) {
        hooks += XposedBridge.hookMethod(method, callback)
        featureCount++
        val observe = observer
        if (observe != null && observed.add(method)) runCatching {
            val params = when (method) {
                is Method -> method.parameterTypes
                is Constructor<*> -> method.parameterTypes
                else -> error("Not a method or constructor")
            }
            val key = BoundaryIdentity.key(method.declaringClass.name,
                if (method is Constructor<*>) "init" else method.name, params.map { it.name })
            // Separate highest-priority observation also sees boundaries skipped by replacements.
            observations += XposedBridge.hookMethod(method, object : XC_MethodHook(Int.MAX_VALUE) {
                override fun beforeHookedMethod(param: MethodHookParam) { runCatching { observe(key, false) } }
                override fun afterHookedMethod(param: MethodHookParam) {
                    if (param.hasThrowable()) runCatching { observe(key, true) }
                }
            })
        }.onFailure { observationComplete = false }
    }
    /** Read-only probes share rollback ownership but never inflate feature-hook counts. */
    fun probe(method: Member, callback: XC_MethodHook) {
        observations += XposedBridge.hookMethod(method, callback)
    }
    fun signal(key: NetcutSignal) { runCatching { signalObserver?.invoke(key) } }
    fun incompleteObservation() { observationComplete = false }
    fun rollback() {
        observations.asReversed().forEach { runCatching { it.unhook() } }
        observations.clear()
        observed.clear()
        hooks.asReversed().forEach { runCatching { it.unhook() } }
        hooks.clear()
        featureCount = 0
    }
}

fun method(cl: ClassLoader, owner: String, name: String, returns: Class<*>,
           vararg args: Class<*>, static: Boolean? = null): Method {
    val result = Class.forName(owner, false, cl).getDeclaredMethod(name, *args)
    require(result.returnType == returns && !Modifier.isAbstract(result.modifiers) &&
        !Modifier.isNative(result.modifiers)) { "Signature mismatch: $owner.$name" }
    require(static == null || Modifier.isStatic(result.modifiers) == static) { "Static mismatch: $owner.$name" }
    return result
}

fun constant(value: Any?): XC_MethodHook = object : XC_MethodHook() {
    override fun beforeHookedMethod(param: MethodHookParam) { param.result = value }
}

fun log(message: String) { XposedBridge.log("[VIP Fucker] $message") }
