package snd.vip.fucker.hook

import android.app.Application
import android.app.Service
import android.app.job.JobParameters
import android.content.Context
import android.content.Intent
import android.content.pm.ProviderInfo
import android.os.Bundle
import android.view.View
import de.robv.android.xposed.XC_MethodHook
import snd.vip.fucker.core.IdmPolicy
import snd.vip.fucker.core.IdmPrivacy
import java.lang.reflect.Member
import java.lang.reflect.Modifier
import java.lang.reflect.InvocationTargetException

/** Runtime port of the supplied 20.0 guide; never changes the installed APK or system signatures. */
object IdmProfile {
    private const val ACTIVITY = "acr.browser.lightning.activity.MyAppCompatActivity"
    private const val MAIN = "idm.internet.download.manager.MainActivity"
    private const val AMAZON = "idm.internet.download.manager.amazon.AmazonService"
    private const val BANNER = "acr.browser.lightning.view.BannerManager"
    private const val NEW_BANNER = "idm.internet.download.manager.manager.NewBannerView"
    private const val FCM = "com.google.firebase.messaging.FirebaseMessaging"
    private const val SALE = "ۦۘۚ"
    private val configRequest = ThreadLocal<Boolean>()
    private val amazonConstructor = ThreadLocal<Boolean>()

    fun install(context: Context, tx: HookTransaction, actions: Set<String>) {
        val cl = context.classLoader
        val planned = mutableListOf<Pair<Member, XC_MethodHook>>()
        fun type(name: String) = Class.forName(name, false, cl)
        fun exact(owner: String, name: String, returns: Class<*>, vararg args: Class<*>, static: Boolean = false) =
            method(cl, owner, name, returns, *args, static = static)
        fun add(owner: String, name: String, returns: Class<*>, value: Any?, vararg args: Class<*>) {
            planned += exact(owner, name, returns, *args) to constant(value)
        }
        fun scoped(local: ThreadLocal<Boolean>) = object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                param.setObjectExtra("idm.previous", local.get())
                local.set(true)
            }
            override fun afterHookedMethod(param: MethodHookParam) {
                val old = param.getObjectExtra("idm.previous") as? Boolean
                if (old == null) local.remove() else local.set(old)
            }
        }
        // Implicit with the app master switch, even when all three optional actions are off.
        planned += exact("i.oj7", "ۦۥ۬", String::class.java, Context::class.java,
            String::class.java, static = true) to object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                IdmPolicy.fingerprint(param.args[1] as? String)?.let { param.result = it }
                // Other packages execute the untouched original method.
            }
        }
        val ads = "ads" in actions
        val trackers = "trackers" in actions
        val banners = "banners" in actions
        if (ads) {
            val activity = type(ACTIVITY)
            val holder = type("i.x73").getDeclaredField("ۦۘۤ").apply {
                require(this.type == activity && Modifier.isStatic(modifiers)); isAccessible = true
            }
            fun continueAds(result: Any?) = object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    try {
                        holder.set(null, param.thisObject)
                        param.result = result
                        (param.args[0] as? Runnable)?.run()
                    } catch (error: Throwable) {
                        // Preserve continuation failure instead of Xposed falling back to SDK startup.
                        param.throwable = error
                    }
                }
            }
            planned += exact(ACTIVITY, "initializeAdsAndRun", Void.TYPE, Runnable::class.java) to continueAds(null)
            planned += exact(ACTIVITY, "initializeConsentAndAds", java.lang.Boolean.TYPE, Runnable::class.java) to continueAds(true)
            add("i.om", "ۦۖۤ", Void.TYPE, null, activity, type("i.pp0"))
            add("i.om", "ۦۖ۟", Void.TYPE, null)
            for (name in listOf("ۦۖۥ", "ۦۖۙ")) add("i.om", name, java.lang.Boolean.TYPE, false)
            for (name in listOf("ۦۖۦ", "ۦۖ۬")) add("i.om", name, java.lang.Boolean.TYPE, false, activity)
            planned += exact("i.om", "ۦۖۢ", Void.TYPE, activity, Runnable::class.java) to object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    param.result = null
                    try { (param.args[1] as? Runnable)?.run() }
                    catch (error: Throwable) { param.throwable = error }
                }
            }
            add(AMAZON, "start", Void.TYPE, null, java.lang.Boolean.TYPE)
            // Keep Object.<init> and every service field initialization; skip only APS registration.
            planned += type(AMAZON).getDeclaredConstructor(Context::class.java) to scoped(amazonConstructor)
            planned += exact("com.amazon.device.ads.AdRegistration", "getInstance",
                type("com.amazon.device.ads.AdRegistration"), String::class.java, Context::class.java,
                static = true) to object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (amazonConstructor.get() == true) param.result = null
                }
            }
            add("i.l82", "ۦۖۥ", java.lang.Boolean.TYPE, false)
            add("i.l82", "ۦۖۦ", java.lang.Boolean.TYPE, false, activity)
            for (owner in listOf("com.appodeal.ads.AppodealPackageAddedReceiver",
                "com.startapp.sdk.adsbase.remoteconfig.BootCompleteListener")) {
                add(owner, "onReceive", Void.TYPE, null, Context::class.java, Intent::class.java)
            }
            add("com.startapp.sdk.cachedservice.BackgroundService", "onStartCommand", Integer.TYPE,
                Service.START_NOT_STICKY, Intent::class.java, Integer.TYPE, Integer.TYPE)
            add("com.startapp.sdk.jobs.SchedulerService", "onStartJob", java.lang.Boolean.TYPE, false, JobParameters::class.java)
            add("com.startapp.sdk.jobs.SchedulerService", "onCreate", Void.TYPE, null)
        }
        if (ads || banners) add(ACTIVITY, "startBannerManager", Void.TYPE, null)
        if (banners) {
            val disable = exact(BANNER, "disable", Void.TYPE).apply { isAccessible = true }
            val loadArgs: Array<Class<*>> = arrayOf(java.lang.Boolean.TYPE)
            val resumeArgs: Array<Class<*>> = emptyArray()
            for ((name, args) in listOf("load" to loadArgs, "resume" to resumeArgs)) {
                planned += exact(BANNER, name, Void.TYPE, *args) to object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.result = null
                        try { disable.invoke(param.thisObject) }
                        catch (error: InvocationTargetException) { param.throwable = error.targetException }
                        catch (error: Throwable) { param.throwable = error }
                    }
                }
            }
            add(BANNER, "repostAd", Void.TYPE, null)
            val bannerClass = type(NEW_BANNER)
            require(View::class.java.isAssignableFrom(bannerClass))
            planned += exact(View::class.java.name, "setVisibility", Void.TYPE, Integer.TYPE) to object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (bannerClass.isInstance(param.thisObject)) param.args[0] = View.GONE
                }
            }
            planned += exact(NEW_BANNER, "onFinishInflate", Void.TYPE) to object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    if (!param.hasThrowable()) (param.thisObject as View).visibility = View.GONE
                }
            }
            val sale = type(MAIN).getDeclaredField(SALE).apply {
                require(this.type == java.lang.Boolean.TYPE && !Modifier.isStatic(modifiers)); isAccessible = true
            }
            val upgradeId = context.resources.getIdentifier("nav_upgrade", "id", IdmPolicy.PACKAGE)
            require(upgradeId != 0) { "Missing nav_upgrade resource" }
            // This lookup follows the sale-field assignment and precedes the sale-click branch in 20.0.
            planned += exact("androidx.appcompat.app.AppCompatActivity", "findViewById", View::class.java,
                Integer.TYPE) to object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    if (param.hasThrowable() || param.thisObject.javaClass.name != MAIN || param.args[0] != upgradeId) return
                    sale.setBoolean(param.thisObject, false)
                    (param.result as? View)?.visibility = View.GONE
                }
            }
            planned += exact(MAIN, "ۦۗۦ", type("i.rj3"), String::class.java) to object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) { sale.setBoolean(param.thisObject, false) }
            }
        }
        if (trackers) {
            for (owner in listOf("i.ac", "i.bc")) add(owner, "ۦۖ۫",
                type("io.bidmachine.AdvertisingDataManager\$AdvertisingData"), null, Context::class.java)
            val browserInit = exact("acr.browser.lightning.app.BrowserApp", "initApp", Void.TYPE,
                Application::class.java, Context::class.java, static = true)
            val referrerInit = ThreadLocal<Boolean>()
            planned += browserInit to scoped(referrerInit)
            planned += exact("com.android.installreferrer.api.InstallReferrerClientImpl", "startConnection",
                Void.TYPE, type("com.android.installreferrer.api.InstallReferrerStateListener")) to object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (referrerInit.get() == true) param.result = null
                }
            }
            planned += exact("i.oj7", "ۦۗۛ", Map::class.java, Context::class.java, static = true) to scoped(configRequest)
            planned += exact("i.oj7", "ۦ۟۫", String::class.java, Context::class.java, static = true) to object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (configRequest.get() == true) param.result = ""
                }
            }
            planned += exact("i.pr5", "ۦۗ۫", type("i.qa3"), type("i.oa3"), String::class.java,
                static = true) to object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (configRequest.get() == true) param.args[1] = IdmPrivacy.scrubForm(param.args[1] as String)
                }
            }
            // Keep FirebaseApp available for d34's getInstance calls; don't replace normal startup/download work.
            add(FCM + "\$AutoInit", "isEnabled", java.lang.Boolean.TYPE, false)
            add(FCM, "isAutoInitEnabled", java.lang.Boolean.TYPE, false)
            for (name in listOf("startSync", "startSyncIfNecessary")) add(FCM, name, Void.TYPE, null)
            val taskType = type("com.google.android.gms.tasks.Task")
            val complete = exact("com.google.android.gms.tasks.Tasks", "forResult", taskType,
                Any::class.java, static = true).apply { isAccessible = true }
            val nullResult: Array<Any?> = arrayOfNulls(1)
            for (name in listOf("subscribeToTopic", "unsubscribeFromTopic")) {
                planned += exact(FCM, name, taskType, String::class.java) to object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) { param.result = complete.invoke(null, *nullResult) }
                }
            }
            for ((name, args) in listOf<Pair<String, Array<Class<*>>>>(
                "getToken" to emptyArray(), "register" to emptyArray())) {
                planned += exact(FCM, name, taskType, *args) to object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) { param.result = complete.invoke(null, "") }
                }
            }
            add(FCM, "blockingGetToken", String::class.java, "")
            add(FCM, "blockingRegister", String::class.java, "", java.lang.Boolean.TYPE)
            add("com.google.firebase.messaging.FirebaseMessagingService", "handleIntent", Void.TYPE, null, Intent::class.java)
            add("idm.internet.download.manager.IDMFirebaseMessagingService", "onMessageReceived", Void.TYPE,
                null, type("com.google.firebase.messaging.RemoteMessage"))
            val receive = exact("com.google.android.gms.cloudmessaging.CloudMessagingReceiver", "onReceive",
                Void.TYPE, Context::class.java, Intent::class.java)
            planned += receive to object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (param.thisObject.javaClass.name == "com.google.firebase.iid.FirebaseInstanceIdReceiver") param.result = null
                }
            }
            val metrica = type("io.appmetrica.analytics.internal.AppMetricaService")
            for ((name, returns, args, value) in listOf(
                ServiceBoundary("onCreate", Void.TYPE, emptyArray(), null),
                ServiceBoundary("onStartCommand", Integer.TYPE, arrayOf(Intent::class.java, Integer.TYPE, Integer.TYPE), Service.START_NOT_STICKY),
                ServiceBoundary("onBind", android.os.IBinder::class.java, arrayOf(Intent::class.java), null))) {
                val m = metrica.getMethod(name, *args)
                require(m.returnType == returns && !Modifier.isAbstract(m.modifiers))
                planned += m to object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (metrica.isInstance(param.thisObject)) param.result = value
                    }
                }
            }
        }
        if (ads || trackers) {
            // App-local provider installation, not a permanent PackageManager/component change.
            val blocked = IdmPolicy.blockedProviders(ads, trackers)
            planned += exact("android.app.ActivityThread", "installContentProviders", Void.TYPE,
                Context::class.java, List::class.java) to object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if ((param.args[0] as? Context)?.packageName != IdmPolicy.PACKAGE) return
                    val providers = param.args[1] as? List<*> ?: return
                    param.args[1] = providers.mapNotNull { item ->
                        val info = item as? ProviderInfo ?: return@mapNotNull item
                        if (info.packageName != IdmPolicy.PACKAGE) return@mapNotNull info
                        if (info.name in blocked) return@mapNotNull null
                        if (ads && info.name == "androidx.startup.InitializationProvider") {
                            ProviderInfo(info).apply {
                                metaData = info.metaData?.let { Bundle(it).apply {
                                    remove("com.unity3d.services.core.configuration.AdsSdkInitializer")
                                } }
                            }
                        } else info
                    }
                }
            }
        }
        // Full preflight before the first hook; MainHook rolls back every handle on installation failure.
        planned.forEach { (m, callback) -> tx.hook(m, callback) }
    }
    private data class ServiceBoundary(val name: String, val returns: Class<*>, val args: Array<Class<*>>, val value: Any?)
}
