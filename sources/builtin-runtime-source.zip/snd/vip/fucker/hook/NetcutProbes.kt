package snd.vip.fucker.hook

import de.robv.android.xposed.XC_MethodHook
import snd.vip.fucker.core.NetcutDiagnostics
import snd.vip.fucker.core.NetcutSignal
import java.lang.reflect.Modifier

/** No replacements or writes. Probe failure must not disable working feature hooks. */
object NetcutProbes {
    private const val DRIVER = "com.arcai.netcut.JNetCutDriver2"
    private const val ID_VALUE = "com.arcai.netcut.JIPCMessage.JIPCMessageIDValue"

    fun install(cl: ClassLoader, tx: HookTransaction) {
        runCatching {
            val node = Class.forName("com.arcai.netcut.JNetWorkNode2", false, cl)
            val message = Class.forName(ID_VALUE, false, cl)
            val id = message.getDeclaredField("m_nID").apply {
                require(type == Integer.TYPE && !Modifier.isStatic(modifiers))
                isAccessible = true
            }
            val pro = method(cl, DRIVER, "GetIsPro", java.lang.Boolean.TYPE, static = false)
            val ui = method(cl, "com.arcai.netcut.UI.JNetCutUserListFragment", "SetTotalSpeedLimit", Void.TYPE, static = false)
            val speed = method(cl, DRIVER, "NodeSpeed", Void.TYPE, node, Integer.TYPE, static = false)
            val incoming = method(cl, DRIVER, "OnIdValueMessage", Void.TYPE, message, static = false)
            // Highest-priority after callback observes the outcome after lower-priority replacements.
            tx.probe(pro, object : XC_MethodHook(Int.MAX_VALUE) {
                override fun afterHookedMethod(param: MethodHookParam) {
                    runCatching { tx.signal(NetcutDiagnostics.proResult(param.result, param.hasThrowable())) }
                }
            })
            tx.probe(ui, object : XC_MethodHook(Int.MAX_VALUE) {
                override fun beforeHookedMethod(param: MethodHookParam) { tx.signal(NetcutSignal.TOTAL_SPEED_UI) }
            })
            tx.probe(speed, object : XC_MethodHook(Int.MAX_VALUE) {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (param.args[0] == null) tx.signal(NetcutSignal.TOTAL_SPEED_REQUEST)
                }
                override fun afterHookedMethod(param: MethodHookParam) {
                    if (param.args[0] == null && param.hasThrowable()) tx.signal(NetcutSignal.TOTAL_SPEED_ERROR)
                }
            })
            tx.probe(incoming, object : XC_MethodHook(Int.MAX_VALUE) {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    runCatching { NetcutDiagnostics.incoming(id.getInt(param.args[0]))?.let(tx::signal) }
                        .onFailure { tx.signal(NetcutSignal.PROBE_ERROR) }
                }
            })
        }.onFailure {
            tx.incompleteObservation()
            log("netcut: optional Pro-origin probes unavailable; feature hooks retained")
        }
    }
}
