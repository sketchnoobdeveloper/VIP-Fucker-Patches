package snd.vip.fucker.hook

import android.content.Context
import android.os.Bundle
import android.os.SystemClock
import snd.vip.fucker.BuildConfig
import snd.vip.fucker.core.*
import snd.vip.fucker.runtime.RuntimeClient
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Hook threads only increment bounded counters. JSON and Binder IPC run on a daemon worker. */
class RuntimeReporter(private val context: Context, profile: Profile, config: Config?) {
    private val lock = Any()
    private var report = RuntimeReport(profile.id, UUID.randomUUID().toString(), SystemClock.elapsedRealtime(),
        1, BuildConfig.VERSION_CODE, config?.let { RuntimeProtocol.configHash(it, profile) },
        if (config == null) RuntimeState.CONFIG_UNAVAILABLE else RuntimeState.STARTING,
        actions = config?.let { c -> profile.actions.filter { c.action(profile, it) }.map { it.id }.toSet() }.orEmpty())
    private val counters = linkedMapOf<String, BoundaryCount>()
    private val signals = linkedMapOf<NetcutSignal, Long>()

    fun start() {
        Executors.newSingleThreadScheduledExecutor { task -> Thread(task, "VF-runtime").apply { isDaemon = true } }
            .scheduleWithFixedDelay({ runCatching { publish() } }, 2, 5, TimeUnit.SECONDS)
    }
    fun state(state: RuntimeState, failure: RuntimeFailure = RuntimeFailure.NONE) = synchronized(lock) {
        report = report.copy(state = state, failure = failure)
    }
    fun build(app: InstalledApp, match: BuildMatch) = synchronized(lock) {
        val version = app.version?.take(64)?.takeIf { name -> name.isNotEmpty() && name.all { it.isLetterOrDigit() || it in ".-_+ " } }
        report = report.copy(version = version, versionCode = app.code, build = match)
    }
    fun installed(hooks: Int, complete: Boolean) = synchronized(lock) {
        report = report.copy(state = RuntimeState.INSTALLED, hookCount = hooks, observationComplete = complete)
    }
    fun observe(key: String, error: Boolean) = synchronized(lock) {
        if (key !in counters && counters.size >= RuntimeProtocol.MAX_BOUNDARIES) {
            report = report.copy(observationComplete = false)
            return@synchronized
        }
        val old = counters[key] ?: BoundaryCount()
        counters[key] = if (error) old.copy(errors = minOf(old.calls, old.errors + 1))
            else old.copy(calls = minOf(RuntimeProtocol.MAX_COUNT, old.calls + 1))
    }
    fun signal(key: NetcutSignal) = synchronized(lock) {
        if (report.target != "netcut" || "premium" !in report.actions) return@synchronized
        signals[key] = minOf(RuntimeProtocol.MAX_COUNT, (signals[key] ?: 0L) + 1L)
    }
    private fun publish() {
        val snapshot = synchronized(lock) {
            report = report.copy(sequence = minOf(RuntimeProtocol.MAX_COUNT, report.sequence + 1))
            report.copy(boundaries = if (report.state == RuntimeState.INSTALLED) counters.toMap() else emptyMap(),
                netcutSignals = if (report.state == RuntimeState.INSTALLED) signals.toMap() else emptyMap())
        }
        val accepted = runCatching {
            context.contentResolver.call(RuntimeClient.uri, "publish", snapshot.target,
                Bundle().apply { putString("report", RuntimeProtocol.encode(snapshot)) })?.getBoolean("accepted") == true
        }.getOrDefault(false)
        if (!accepted) synchronized(lock) {
            report = report.copy(deliveryFailures = minOf(RuntimeProtocol.MAX_COUNT, report.deliveryFailures + 1))
        }
    }
}
