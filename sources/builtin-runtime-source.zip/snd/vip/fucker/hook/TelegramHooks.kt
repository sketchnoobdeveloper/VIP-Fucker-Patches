package snd.vip.fucker.hook

import android.content.Context
import android.view.View
import android.view.Window
import android.view.WindowManager
import de.robv.android.xposed.XC_MethodHook
import java.lang.reflect.Field
import java.lang.reflect.Modifier
import snd.vip.fucker.core.TelegramPolicy
import snd.vip.fucker.core.PremiumGate

/** Verified web selectors; unknown builds require opt-in and the same reflection checks. */
object TelegramHooks {
    private const val CONFIG = "org.telegram.messenger.UserConfig"
    private const val CONTROLLER = "org.telegram.messenger.MessagesController"
    private const val MESSAGE = "org.telegram.messenger.MessageObject"
    private const val FILE = "org.telegram.messenger.FileLoadOperation"
    private const val TL = "org.telegram.tgnet.TLRPC\$"
    private val bool = Boolean::class.javaPrimitiveType!!
    private val int = Int::class.javaPrimitiveType!!
    private val long = Long::class.javaPrimitiveType!!
    private val void = Void.TYPE

    fun install(cl: ClassLoader, tx: HookTransaction, actions: Set<String>) {
        val allowed = snd.vip.fucker.core.Profiles.byId("telegram")!!.actions.filter { it.available }.map { it.id }.toSet()
        require(actions.isNotEmpty() && actions.all { it in allowed }) { "Unavailable Telegram feature" }
        fun type(name: String) = Class.forName(name, false, cl)
        fun replace(owner: String, name: String, returns: Class<*>, value: Any?, vararg args: Class<*>) {
            tx.hook(method(cl, owner, name, returns, *args, static = false), constant(value))
        }

        if (actions.any { it in setOf("premium", "icon", "wallpaper", "translation") }) {
            // Independent gates without changing User objects or immutable icon flags.
            val gateContext = ThreadLocal<PremiumGate>()
            fun gateScope(target: java.lang.reflect.Method, gate: PremiumGate,
                predicate: (XC_MethodHook.MethodHookParam) -> Boolean = { true }) {
                tx.hook(target, object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (predicate(param)) {
                            param.setObjectExtra("vip.premium.previous", gateContext.get() ?: PremiumGate.GENERAL)
                            gateContext.set(gate)
                        }
                    }
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val previous = param.getObjectExtra("vip.premium.previous") as? PremiumGate ?: return
                        if (previous == PremiumGate.GENERAL) gateContext.remove() else gateContext.set(previous)
                    }
                })
            }
            if ("premium" in actions || "icon" in actions) {
                val iconView = type("org.telegram.ui.Cells.u")
                val holder = type("n4.h1")
                val holderView = holder.getField("a").apply {
                    require(type == View::class.java && !Modifier.isStatic(modifiers)) { "Icon holder field mismatch" }
                    isAccessible = true
                }
                gateScope(method(cl, "org.telegram.ui.Cells.v", "x1", void, static = false), PremiumGate.ICON)
                gateScope(method(cl, "org.telegram.ui.Cells.p", "d", void, int, View::class.java, static = false), PremiumGate.ICON) {
                    iconView.isInstance(it.args[1])
                }
                gateScope(method(cl, "org.telegram.ui.a8", "v", void, holder, int, static = false), PremiumGate.ICON) {
                    it.args[0] != null && iconView.isInstance(holderView.get(it.args[0]))
                }
                tx.hook(method(cl, CONTROLLER, "premiumFeaturesBlocked", bool, static = false), object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (gateContext.get() == PremiumGate.ICON && "icon" in actions) param.result = false
                    }
                })
            }
            if ("premium" in actions || "wallpaper" in actions) {
                // Exact preview/apply methods. Channel boost checks before the Premium gate remain intact.
                gateScope(method(cl, "org.telegram.ui.ie1", "N0", void, bool, static = false), PremiumGate.WALLPAPER)
                gateScope(method(cl, "org.telegram.ui.ie1", "createView", View::class.java, Context::class.java,
                    static = false), PremiumGate.WALLPAPER)
            }
            if ("premium" in actions || "translation" in actions) {
                // Only eligibility's own Premium check changes. Native settings, free autotranslation,
                // dialog state, hidden-dialog policy and server requests remain untouched.
                val translate = "org.telegram.messenger.TranslateController"
                gateScope(method(cl, translate, "isFeatureAvailable", bool, static = false), PremiumGate.TRANSLATION)
                gateScope(method(cl, translate, "isFeatureAvailable", bool, long, static = false), PremiumGate.TRANSLATION)
                gateScope(method(cl, translate, "isLanguageRestricted", bool, String::class.java,
                    static = false), PremiumGate.NATIVE)
                // Do not scope the shared click listener or ko.Uc: nested calls include unrelated
                // Premium checks. UI upsell coverage is deliberately partial, not silently broadened.
            }
            val current = method(cl, CONFIG, "getCurrentUser", type(TL + "User"), static = false)
            current.isAccessible = true
            tx.hook(method(cl, CONFIG, "isPremium", bool, static = false), object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    // Keep logged-out accounts false; never mutate shared User objects or prime/crypto checks.
                    if (!param.hasThrowable()) {
                        val loggedIn = runCatching { current.invoke(param.thisObject) != null }.getOrDefault(false)
                        param.result = TelegramPolicy.premiumResult(param.result == true, loggedIn,
                            gateContext.get() ?: PremiumGate.GENERAL, actions)
                    }
                }
            })
        }
        if ("sponsored" in actions) {
            replace(CONTROLLER, "getSponsoredMessages", type(CONTROLLER + "\$SponsoredMessagesInfo"), null, long)
            replace(CONTROLLER, "isSponsoredDisabled", bool, true)
            // Empty in this APK already, retained as an exact boundary rather than altering sponsoredId fields.
            replace(CONTROLLER, "markSponsoredAsRead", void, null, long, type(MESSAGE))
        }
        if ("proxy" in actions) {
            // Called both by periodic updates and the public async wrapper. Does not touch proxy credentials.
            replace(CONTROLLER, "checkPromoInfoInternal", void, null, bool)
        }
        if ("download" in actions) {
            val small = field(cl, FILE, "forceSmallChunk", bool)
            val maximum = field(cl, FILE, "maxDownloadRequestsBig", int)
            tx.hook(method(cl, FILE, "updateParams", void, static = false), object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    if (!param.hasThrowable()) {
                        // Preserve chunk sizes, offsets, CDN hash windows, encryption and small-file parameters.
                        maximum.setInt(param.thisObject, TelegramPolicy.largeFileRequests(
                            maximum.getInt(param.thisObject), small.getBoolean(param.thisObject)))
                    }
                }
            })
        }
        if ("ghost" in actions) {
            replace(CONTROLLER, "completeReadTask", void, null, type(CONTROLLER + "\$ReadTask"))
            replace(CONTROLLER, "sendTyping", bool, false, long, long, int, int)
            replace(CONTROLLER, "sendTyping", bool, false, long, long, int, String::class.java, int)
            replace(CONTROLLER, "markMessageContentAsRead", void, null, type(MESSAGE))
        }
        if ("save" in actions) {
            replace(CONTROLLER, "isChatNoForwards", bool, false, long)
            replace(CONTROLLER, "isChatNoForwards", bool, false, type(TL + "Chat"))
        }
        if ("updates" in actions) {
            // Preserve unrelated TL requests, package installation and native validation.
            replace("org.telegram.ui.LaunchActivity", "z", void, null, bool)
            replace("org.telegram.ui.LaunchActivity", "M0", void, null, int, type(TL + "TL_help_appUpdate"), bool)
            tx.hook(method(cl, "org.telegram.messenger.SharedConfig", "isAppUpdateAvailable", bool,
                static = true), constant(false))
        }
        if ("access" in actions) {
            // Remove the local restriction text only; keep chat loading/access-hash/server checks intact.
            replace(CONTROLLER, "getRestrictionReason", String::class.java, null, java.util.ArrayList::class.java)
        }
        if ("stories" in actions) {
            // Exact obfuscated controller and overload, not a regex over arbitrary boolean methods.
            replace("xg.o5", "V", bool, false, type("org.telegram.tgnet.tl.TL_stories\$PeerStories"),
                type("org.telegram.tgnet.tl.TL_stories\$StoryItem"), bool)
        }
        if ("screenshot" in actions) {
            tx.hook(method(cl, "org.telegram.messenger.AndroidUtilities", "allowScreenCapture", bool, static = true), constant(true))
            tx.hook(method(cl, Window::class.java.name, "setFlags", void, int, int, static = false), object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    param.args[0] = TelegramPolicy.screenshotFlags(param.args[0] as Int)
                }
            })
            tx.hook(method(cl, Window::class.java.name, "setAttributes", void, WindowManager.LayoutParams::class.java,
                static = false), object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val attributes = param.args[0] as? WindowManager.LayoutParams ?: return
                    if (attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0) {
                        // Copy rather than mutating Telegram's own LayoutParams instance.
                        val copy = WindowManager.LayoutParams()
                        copy.copyFrom(attributes)
                        copy.flags = TelegramPolicy.screenshotFlags(copy.flags)
                        param.args[0] = copy
                    }
                }
            })
        }
    }

    private fun field(cl: ClassLoader, owner: String, name: String, type: Class<*>): Field {
        val field = Class.forName(owner, false, cl).getDeclaredField(name)
        require(field.type == type && !Modifier.isStatic(field.modifiers) && !Modifier.isFinal(field.modifiers)) {
            "Field mismatch: $owner.$name"
        }
        field.isAccessible = true
        return field
    }
}
