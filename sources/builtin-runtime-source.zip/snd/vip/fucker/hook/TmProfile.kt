package snd.vip.fucker.hook

import android.app.Activity
import android.app.Notification
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.TextView
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import java.lang.reflect.Method
import java.lang.reflect.Modifier

/** Port of the separately analyzed TM Tunnel 2.7 local selectors, not a VPN/auth hook. */
object TmProfile {
    private const val ACTIVITIES = "tmsoft.javacodez.vpn.activities."
    private const val MAIN = ACTIVITIES + "TMTunnelVPNMain"
    private const val ADS = ACTIVITIES + "AdsManagerActivity"
    private const val APP = ACTIVITIES + "TMTunnelVPNApplication"
    private const val SERVICE = "tmsoft.javacodez.vpn.service.TimeManagerService"
    private const val BALANCE = 86400 // Safe display seconds; never multiply a giant Int by 1000.
    private const val LABEL = "Unlimited (local)"
    private val callbacks = setOf("l81", "k91", SERVICE + "\$a", ADS + "\$b")
    private val notice = ThreadLocal<Boolean>()
    private val adSelectors = listOf(
        MAIN to "f0", MAIN to "i0", MAIN to "k0", ADS to "K", ADS to "L", APP to "onMoveToForeground",
        "com.google.android.gms.ads.BaseAdView" to "loadAd",
        "com.google.android.gms.ads.AdLoader" to "loadAd",
        "com.google.android.gms.ads.AdLoader" to "loadAds",
        "com.google.android.gms.ads.interstitial.InterstitialAd" to "load",
        "com.google.android.gms.ads.admanager.AdManagerInterstitialAd" to "load",
        "com.google.android.gms.ads.rewarded.RewardedAd" to "load",
        "com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd" to "load",
        "com.google.android.gms.ads.appopen.AppOpenAd" to "load",
        "com.google.android.gms.internal.ads.zzbfk" to "show",
        "com.google.android.gms.internal.ads.zzbrq" to "show",
        "com.google.android.gms.internal.ads.zzcbw" to "show",
        "com.google.android.gms.internal.ads.zzcch" to "show",
    )

    fun install(cl: ClassLoader, tx: HookTransaction, timer: Boolean, ads: Boolean) {
        val constants = mutableListOf<Pair<Method, Any?>>()
        val starts = mutableListOf<Pair<Method, String>>()
        val adMethods = mutableListOf<Method>()
        val updates = mutableListOf<Pair<Method, Boolean>>()
        var serviceUpdate: Method? = null
        var contentText: Method? = null
        fun exact(owner: String, name: String, returns: Class<*>, vararg params: Class<*>) =
            method(cl, owner, name, returns, *params)
        fun field(owner: String, name: String, expected: Class<*>) {
            require(expected.isAssignableFrom(Class.forName(owner, false, cl).getDeclaredField(name).type)) {
                "Field mismatch: $owner.$name"
            }
        }
        if (timer) {
            constants += exact("qh", "x", java.lang.Boolean.TYPE) to true
            constants += exact("hc1", "b", Integer.TYPE) to BALANCE
            constants += exact("hc1", "a", Integer.TYPE) to 0
            constants += exact("hc1", "d", java.lang.Boolean.TYPE) to false
            constants += exact("hc1", "e", Void.TYPE, Integer.TYPE) to null
            constants += exact(MAIN, "t0", String::class.java, Integer.TYPE) to LABEL
            constants += exact(ADS, "M", String::class.java, Integer.TYPE) to LABEL
            field("o3", "a", CountDownTimer::class.java)
            field("o3", "c", java.lang.Boolean.TYPE)
            require(Class.forName("o3", false, cl).getDeclaredField("b").type.name == "o3\$d")
            for (name in listOf("a", "b")) starts += exact("o3", name, Void.TYPE, Integer.TYPE) to name
            callbacks.forEach {
                constants += exact(it, "a", Void.TYPE) to null
                exact(it, "b", Void.TYPE, Integer.TYPE)
                exact(it, "onStart", Void.TYPE)
            }
            field(MAIN, "L0", TextView::class.java)
            field(MAIN, "O0", View::class.java)
            field(ADS, "p", TextView::class.java)
            field(ADS, "q", TextView::class.java)
            serviceUpdate = exact(SERVICE, "a", Void.TYPE, Class.forName(SERVICE, false, cl), Integer.TYPE)
            contentText = method(cl, Notification.Builder::class.java.name, "setContentText",
                Notification.Builder::class.java, CharSequence::class.java)
        }
        if (ads) {
            adSelectors.forEach { (owner, name) ->
                val matches = Class.forName(owner, false, cl).declaredMethods.filter {
                    it.name == name && it.returnType == Void.TYPE &&
                        !Modifier.isAbstract(it.modifiers) && !Modifier.isNative(it.modifiers)
                }
                require(matches.isNotEmpty()) { "Missing concrete ad selector: $owner.$name" }
                adMethods += matches
            }
            constants += exact(APP + "\$b", "a", java.lang.Boolean.TYPE) to false
            constants += exact(APP + "\$b", "b", Void.TYPE, Activity::class.java) to null
            field(MAIN, "q0", View::class.java)
            field(ADS, "j", View::class.java)
        }
        if (timer || ads) for (owner in listOf(MAIN, ADS)) {
            updates += exact(owner, "onCreate", Void.TYPE, Bundle::class.java) to (owner == MAIN)
            updates += exact(owner, "onResume", Void.TYPE) to (owner == MAIN)
        }
        // All selected action selectors are preflighted before the first feature hook.
        constants.forEach { (m, value) -> tx.hook(m, constant(value)) }
        adMethods.forEach { tx.hook(it, constant(null)) }
        starts.forEach { (m, name) -> tx.hook(m, object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val callback = XposedHelpers.getObjectField(param.thisObject, "b") ?: return
                if (callback.javaClass.name !in callbacks) return
                param.result = null
                try {
                    (XposedHelpers.getObjectField(param.thisObject, "a") as? CountDownTimer)?.cancel()
                    val inert = object : CountDownTimer(1L, 1000L) {
                        override fun onTick(remaining: Long) = Unit
                        override fun onFinish() = Unit
                    }
                    XposedHelpers.setObjectField(param.thisObject, "a", inert)
                    XposedHelpers.setBooleanField(param.thisObject, "c", name == "b")
                    XposedHelpers.callMethod(callback, "onStart")
                    XposedHelpers.callMethod(callback, "b", BALANCE)
                } catch (error: Throwable) {
                    log("tm: timer suppressed, callback failed (${error.javaClass.simpleName})")
                }
            }
        }) }
        if (serviceUpdate != null && contentText != null) {
            tx.hook(serviceUpdate, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    param.setObjectExtra("vip.previous", notice.get())
                    notice.set(true)
                }
                override fun afterHookedMethod(param: MethodHookParam) {
                    val previous = param.getObjectExtra("vip.previous") as? Boolean
                    if (previous == null) notice.remove() else notice.set(previous)
                }
            })
            tx.hook(contentText, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (notice.get() == true) param.args[0] = LABEL
                }
            })
        }
        updates.forEach { (m, main) -> tx.hook(m, object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                if (param.hasThrowable()) return
                runCatching {
                    if (ads) hide(param.thisObject, if (main) "q0" else "j")
                    if (timer) {
                        if (main) { hide(param.thisObject, "O0"); text(param.thisObject, "L0", LABEL) }
                        else { text(param.thisObject, "p", "Unlimited VPN time (local)"); text(param.thisObject, "q", LABEL) }
                    }
                }.onFailure { log("tm: UI update failed (${it.javaClass.simpleName})") }
            }
        }) }
    }
    private fun hide(owner: Any, name: String) {
        val view = XposedHelpers.getObjectField(owner, name) as? View ?: return
        view.visibility = View.GONE
        view.layoutParams?.let { it.height = 0; view.layoutParams = it }
    }
    private fun text(owner: Any, name: String, value: String) {
        (XposedHelpers.getObjectField(owner, name) as? TextView)?.text = value
    }
}
