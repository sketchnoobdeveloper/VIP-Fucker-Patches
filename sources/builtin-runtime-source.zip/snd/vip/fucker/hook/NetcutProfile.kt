package snd.vip.fucker.hook

import android.view.View
import de.robv.android.xposed.XC_MethodHook
import snd.vip.fucker.core.NetcutPolicy
import snd.vip.fucker.core.NetcutExpiry
import snd.vip.fucker.core.NetcutDiagnostics
import java.lang.reflect.Member
import java.nio.ByteBuffer

object NetcutProfile {
    fun install(cl: ClassLoader, tx: HookTransaction, actions: Set<String>) {
        val planned = mutableListOf<Pair<Member, XC_MethodHook>>()
        fun type(name: String): Class<*> = when (name) {
            "void" -> Void.TYPE
            "boolean" -> java.lang.Boolean.TYPE
            else -> Class.forName(name, false, cl)
        }
        NetcutPolicy.predicates(actions).forEach { predicate ->
            planned += method(cl, predicate.owner, predicate.name, java.lang.Boolean.TYPE,
                static = false) to constant(predicate.value)
        }
        NetcutPolicy.ads(actions).forEach { boundary ->
            planned += method(cl, boundary.owner, boundary.name, type(boundary.returns),
                *boundary.args.map(::type).toTypedArray(), static = boundary.static) to constant(boundary.value)
        }
        if ("ads" in actions) {
            val googleView = type("com.google.android.gms.ads.BaseAdView")
            val somaView = type("com.smaato.soma.BaseView")
            require(View::class.java.isAssignableFrom(googleView) && View::class.java.isAssignableFrom(somaView))
            fun adView(value: Any?) = googleView.isInstance(value) || somaView.isInstance(value)
            // Only ad-view instances, never ordinary app views or global package/component settings.
            planned += method(cl, View::class.java.name, "setVisibility", Void.TYPE,
                Integer.TYPE, static = false) to object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (adView(param.thisObject)) param.args[0] = View.GONE
                }
            }
            planned += method(cl, View::class.java.name, "onAttachedToWindow", Void.TYPE,
                static = false) to object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    if (!param.hasThrowable() && adView(param.thisObject))
                        (param.thisObject as View).visibility = View.GONE
                }
            }
        }
        if (NetcutPolicy.expiry(actions)) {
            val account = type(NetcutExpiry.ACCOUNT)
            val expiry = NetcutExpiry(account) // Preflight both exact writable fields.
            planned += method(cl, NetcutExpiry.ACCOUNT, "LoadBuffer", java.lang.Boolean.TYPE,
                ByteBuffer::class.java, static = false) to object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    expiry.afterLoad(param.thisObject, param.result, param.hasThrowable())
                }
            }
            planned += method(cl, "com.arcai.netcut.JNetCutDriver2", "UpdateProAcc", Void.TYPE,
                account, static = false) to object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) { expiry.apply(param.args[0]) }
            }
            planned += method(cl, "com.arcai.netcut.JNetCutDriver2", "GetProAccount", account,
                static = false) to object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    if (!param.hasThrowable()) expiry.apply(param.result)
                }
            }
            planned += method(cl, "com.arcai.netcut.tools2", "getCurrentTimeStamp", String::class.java,
                java.lang.Long.TYPE, static = true) to object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    NetcutExpiry.label(param.args[0] as Long)?.let { param.result = it }
                }
            }
        }
        // Suppress native-engine Pro warning (ID 14) when the Java Pro gate is open.
        // The native CNetCutService replies with ID 14 independently of Java GetIsPro;
        // divert it to the harmless default case only when Java Pro is confirmed true.
        if ("premium" in actions) {
            val idValueCls = type("com.arcai.netcut.JIPCMessage.JIPCMessageIDValue")
            val idField = idValueCls.getDeclaredField("m_nID").apply { isAccessible = true }
            val getIsPro = method(cl, "com.arcai.netcut.JNetCutDriver2", "GetIsPro", java.lang.Boolean.TYPE)
            val onIdValue = method(cl, "com.arcai.netcut.JNetCutDriver2", "OnIdValueMessage", Void.TYPE, idValueCls)
            planned += onIdValue to object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val msg = param.args[0] ?: return
                    if (idField.getInt(msg) != 14) return
                    val driver = param.thisObject ?: return
                    val isPro = runCatching {
                        getIsPro.invoke(driver, emptyArray<Any>())
                    }.getOrNull() == true
                    if (isPro) {
                        idField.setInt(msg, 0) // divert to default case (harmless log)
                        tx.signal(NetcutDiagnostics.diverted())
                    }
                }
            }
        }
        // All methods/types/fields resolve before any registration; normal transaction rollback applies.
        planned.forEach { (boundary, callback) -> tx.hook(boundary, callback) }
        if ("premium" in actions) NetcutProbes.install(cl, tx)
        // Purchases, account identity/login, raw buffers, outgoing order IPC and native engine stay intact.
    }
}
