package snd.vip.fucker.hook

import de.robv.android.xposed.XC_MethodHook
import snd.vip.fucker.recipe.*
import java.io.File
import java.util.zip.ZipFile

/** Only explicitly selected bundled declarations; no downloaded/imported DEX or code execution. */
object RootAssetHooks {
    fun load(modulePath: String, asset: String): RootPatch = ZipFile(modulePath).use { zip ->
        require(asset.startsWith("root-patches/") && ".." !in asset)
        val entry = requireNotNull(zip.getEntry("assets/$asset"))
        require(entry.size in 1..RootPatchDocument.MAX_BYTES)
        zip.getInputStream(entry).use { RootPatchDocument.parse(RootPatchVerifier.bounded(it, RootPatchDocument.MAX_BYTES)) }
    }

    fun install(apk: File, patch: RootPatch, loader: ClassLoader, transaction: HookTransaction, actions: Set<String>) {
        val operations = patch.operations.filter { it.action in actions }
        require(operations.isNotEmpty())
        val prepared = RootPatchVerifier.verify(apk, operations).map { it.operation to RootPatchVerifier.resolve(it, loader) }
        val scopes = RootBooleanScope()
        val preference = if (operations.any { it.mode == RootHookMode.SCOPED_PREFERENCE_BOOLEAN })
            method(loader, "android.app.SharedPreferencesImpl", "getBoolean", Boolean::class.javaPrimitiveType!!,
                String::class.java, Boolean::class.javaPrimitiveType!!, static = false) else null
        // Preflight is complete. Caller-scoped preference hook cannot change unrelated reads.
        preference?.let { transaction.hook(it, object : XC_MethodHook(Int.MAX_VALUE) {
            override fun afterHookedMethod(param: MethodHookParam) {
                if (!param.hasThrowable()) param.result = scopes.result(param.args[0], param.result, false)
            }
        }) }
        prepared.forEach { (operation, method) ->
            val tokenKey = "vip-root-scope-${operation.owner}-${operation.method}"
            transaction.hook(method, object : XC_MethodHook(Int.MAX_VALUE) {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (operation.mode == RootHookMode.SCOPED_PREFERENCE_BOOLEAN)
                        param.setObjectExtra(tokenKey, scopes.enter(requireNotNull(operation.key), operation.value))
                }
                override fun afterHookedMethod(param: MethodHookParam) {
                    if (operation.mode == RootHookMode.SCOPED_PREFERENCE_BOOLEAN) {
                        param.getObjectExtra(tokenKey)?.let(scopes::leave)
                    } else if (!param.hasThrowable() && param.result is Boolean) param.result = operation.value
                }
            })
        }
    }
}
