package snd.vip.fucker.core

import java.lang.reflect.Modifier

/** Only decoded Java fields are changed. Raw account buffers and identity stay intact. */
class NetcutExpiry(private val accountType: Class<*>) {
    companion object {
        const val ACCOUNT = "com.arcai.netcut.JIPCMessage.JIPCMessageProAccount"
        // tools2 multiplies seconds by 1000: Long.MAX_VALUE would overflow.
        const val NO_EXPIRY_SECONDS = 253402300799L // 9999-12-31T23:59:59Z
        fun label(seconds: Long): String? =
            if (seconds == NO_EXPIRY_SECONDS) "Lifetime (local override)" else null
    }

    private fun field(name: String, type: Class<*>) = accountType.getDeclaredField(name).apply {
        require(this.type == type && !Modifier.isStatic(modifiers) && !Modifier.isFinal(modifiers)) {
            "NetCut expiry field mismatch: $name"
        }
        isAccessible = true
    }

    private val expired = field("m_bExpired", java.lang.Boolean.TYPE)
    private val expires = field("m_nExpireTime", java.lang.Long.TYPE)

    fun apply(account: Any?): Boolean {
        if (account == null) return false // No invented account when the engine is unavailable.
        require(accountType.isInstance(account)) { "NetCut account type mismatch" }
        synchronized(account) {
            expired.setBoolean(account, false)
            expires.setLong(account, NO_EXPIRY_SECONDS)
        }
        return true
    }

    fun afterLoad(account: Any?, result: Any?, failed: Boolean): Boolean =
        !failed && result == true && apply(account)
}
