package snd.vip.fucker.core

enum class ClientSelectionMode { SINGLE, MULTIPLE, ALL }

/** Durable user intent; installed-client scans are only a view of this selection. */
data class ClientSelectionState(
    val mode: ClientSelectionMode = ClientSelectionMode.SINGLE,
    val selected: List<String> = emptyList(),
) {
    fun active(installed: List<String>): List<String> = ClientSelection.normalize(mode, selected, installed)

    fun withMode(next: ClientSelectionMode, installed: List<String>): ClientSelectionState =
        if (next == mode) this else ClientSelectionState(next, ClientSelection.normalize(next, active(installed), installed))

    fun toggle(id: String, installed: List<String>): ClientSelectionState {
        if (id !in installed) return this
        return when (mode) {
            ClientSelectionMode.SINGLE -> copy(selected = listOf(id))
            ClientSelectionMode.MULTIPLE -> copy(selected =
                if (id in selected) selected - id else (selected + id).distinct())
            ClientSelectionMode.ALL -> this
        }
    }
}

/** Selection only changes the UI batch, never silently enables or clears saved hooks. */
object ClientSelection {
    fun initial(config: Config): ClientSelectionState {
        val enabled = Profiles.telegramClients.filter { config.enabled(it) }.map { it.id }
        return ClientSelectionState(if (enabled.size > 1) ClientSelectionMode.MULTIPLE else ClientSelectionMode.SINGLE, enabled)
    }

    fun normalize(mode: ClientSelectionMode, selected: List<String>, installed: List<String>): List<String> {
        val valid = selected.distinct().filter { it in installed }
        return when (mode) {
            ClientSelectionMode.SINGLE -> listOfNotNull(valid.firstOrNull() ?: installed.firstOrNull())
            ClientSelectionMode.MULTIPLE -> valid
            ClientSelectionMode.ALL -> installed.distinct()
        }
    }

    fun toggle(mode: ClientSelectionMode, selected: List<String>, id: String, installed: List<String>): List<String> {
        if (id !in installed) return normalize(mode, selected, installed)
        return when (mode) {
            ClientSelectionMode.SINGLE -> listOf(id)
            ClientSelectionMode.MULTIPLE -> normalize(mode,
                if (id in selected) selected - id else selected + id, installed)
            ClientSelectionMode.ALL -> normalize(mode, selected, installed)
        }
    }

    fun edit(config: Config, targets: List<Profile>, key: String, value: Boolean, allowEnable: Boolean = true): Config =
        if (value && !allowEnable) config else Config(config.values + targets.associate { "${it.id}.$key" to value })
}
