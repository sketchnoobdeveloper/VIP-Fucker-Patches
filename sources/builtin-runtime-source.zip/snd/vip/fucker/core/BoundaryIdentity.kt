package snd.vip.fucker.core

/** ASCII metadata identifiers also support Unicode-obfuscated target methods. */
object BoundaryIdentity {
    private val unsafe = Regex("[^A-Za-z0-9_.$#(),\\[\\];]")
    fun key(owner: String, method: String, params: List<String>): String {
        val full = "$owner#$method(${params.joinToString(",")})"
        val escaped = unsafe.replace(full) { "_u${it.value[0].code.toString(16)}_" }
        return if (escaped.length <= 240) escaped else
            escaped.take(220) + "(" + Integer.toHexString(full.hashCode()) + ")"
    }
}
