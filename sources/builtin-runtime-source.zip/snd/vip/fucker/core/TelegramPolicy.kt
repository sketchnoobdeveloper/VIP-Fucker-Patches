package snd.vip.fucker.core

enum class PremiumGate { GENERAL, ICON, WALLPAPER, TRANSLATION, NATIVE }

/** Pure decisions shared by runtime callbacks and JVM tests. Paid state is never removed. */
object TelegramPolicy {
    fun premiumResult(original: Boolean, loggedIn: Boolean, gate: PremiumGate, actions: Set<String>): Boolean {
        val action = when (gate) {
            PremiumGate.GENERAL -> "premium"
            PremiumGate.ICON -> "icon"
            PremiumGate.WALLPAPER -> "wallpaper"
            PremiumGate.TRANSLATION -> "translation"
            PremiumGate.NATIVE -> return original
        }
        return original || (loggedIn && action in actions)
    }

    fun largeFileRequests(original: Int, forceSmall: Boolean): Int = if (forceSmall) original else maxOf(original, 12)
    fun screenshotFlags(flags: Int): Int = flags and 0x2000.inv()
}
