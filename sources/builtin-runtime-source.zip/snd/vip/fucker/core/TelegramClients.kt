package snd.vip.fucker.core

data class TelegramClient(val id: String, val title: String, val packageName: String, val source: String)

/** Package identities only, not hook-compatibility certification. See evidence/telegram-clients.md. */
object TelegramClients {
    val supportedNames = listOf("Normal", "Web", "Beta", "Cherrygram", "Plus Messenger", "İme / Direct",
        "TurboTel", "Nicegram", "Nagram / X", "Momogram", "Exteragram", "Ayugram", "Forkgram", "Vidogram / Lite", "Hulugram")
    val known = listOf(
        TelegramClient("telegram_normal", "Telegram Normal", "org.telegram.messenger", "Official Google Play listing"),
        TelegramClient("telegram_beta", "Telegram Beta", "org.telegram.messenger.beta", "Official HockeyApp Gradle"),
        TelegramClient("telegram_cherrygram", "Cherrygram", "uz.unnarsx.cherrygram", "Official Google Play listing / Gradle"),
        TelegramClient("telegram_plus", "Plus Messenger", "org.telegram.plus", "Official Google Play listing"),
        TelegramClient("telegram_ime", "iMe", "com.iMe.android", "Official Google Play listing / Gradle"),
        TelegramClient("telegram_ime_direct", "iMe Direct", "com.iMe.android.web", "Official 13.0.2 APK manifest"),
        TelegramClient("telegram_turbotel", "TurboTel", "ellipi.messenger", "Official Google Play listing"),
        TelegramClient("telegram_nicegram", "Nicegram", "app.nicegram", "Official Google Play listing"),
        TelegramClient("telegram_nagram", "Nagram", "xyz.nextalone.nagram", "Official application-module Gradle"),
        TelegramClient("telegram_nagram_x", "Nagram X", "nu.gpu.nagram", "Official application-module Gradle (archived source)"),
        TelegramClient("telegram_momogram", "Momogram", "momo.gram", "Official application-module Gradle"),
        TelegramClient("telegram_exteragram", "exteraGram", "com.exteragram.messenger", "Official Gradle (known package; older public source)"),
        TelegramClient("telegram_ayugram", "AyuGram", "com.radolyn.ayugram", "Official Gradle (known package; older public source)"),
        TelegramClient("telegram_forkgram", "Forkgram · F-Droid", "org.forkgram.messenger", "F-Droid listing / official Gradle"),
        TelegramClient("telegram_forkclient", "Forkgram · GitHub", "org.forkclient.messenger.beta", "Official Gradle / release workflow"),
        TelegramClient("telegram_vidogram", "Vidogram", "org.vidogram.messenger", "Official Google Play listing"),
        TelegramClient("telegram_vidogram_lite", "Vidogram Lite", "org.vidogram.lite", "Official Google Play listing"),
        TelegramClient("telegram_hulugram", "Hulugram", "plus.ride.huluchat", "Official Google Play listing"),
    )
}
