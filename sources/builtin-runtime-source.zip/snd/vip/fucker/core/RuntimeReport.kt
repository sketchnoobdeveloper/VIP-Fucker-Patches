package snd.vip.fucker.core

import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

enum class RuntimeState { CONFIG_UNAVAILABLE, DISABLED, STARTING, BUILD_REJECTED, INSTALLED, INSTALL_FAILED }
enum class RuntimeFailure { NONE, METADATA_UNAVAILABLE, BUILD_POLICY, SELECTOR_OR_INSTALL }
data class BoundaryCount(val calls: Long = 0, val errors: Long = 0)
data class RuntimeReport(
    val target: String, val session: String, val startedElapsed: Long, val sequence: Long,
    val moduleCode: Int, val configHash: String?, val state: RuntimeState,
    val failure: RuntimeFailure = RuntimeFailure.NONE, val version: String? = null,
    val versionCode: Long = 0, val build: BuildMatch? = null, val actions: Set<String> = emptySet(),
    val hookCount: Int = 0, val observationComplete: Boolean = true,
    val deliveryFailures: Long = 0, val boundaries: Map<String, BoundaryCount> = emptyMap(),
    val netcutSignals: Map<NetcutSignal, Long> = emptyMap(),
)
data class StoredRuntime(val report: RuntimeReport, val receivedWall: Long, val receivedElapsed: Long, val boot: Int)

/** Bounded counters and fixed NetCut outcome categories only; no raw arguments/results/payloads. */
object RuntimeProtocol {
    const val AUTHORITY = "snd.vip.fucker.runtime"
    const val SCHEMA = 1
    const val MAX_BYTES = 32768
    const val MAX_BOUNDARIES = 96
    const val MAX_COUNT = 1_000_000_000_000L
    const val STALE_MS = 30000L
    private val identifier = Regex("[A-Za-z0-9_.$#(),\\[\\];]+")
    private val sessionId = Regex("[a-f0-9-]{36}")
    private val digest = Regex("[a-f0-9]{64}")

    fun configHash(config: Config, profile: Profile): String {
        val canonical = "${Config.SCHEMA}\n" + Config.keys.filter { it.startsWith("${profile.id}.") }
            .sorted().joinToString("\n") { "$it=${config.values[it] == true}" }
        return MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 255) }
    }

    fun valid(report: RuntimeReport): Boolean {
        val target = Profiles.byId(report.target) ?: return false
        return sessionId.matches(report.session) && report.startedElapsed >= 0 && report.sequence in 1..MAX_COUNT &&
            report.moduleCode in 1..1_000_000 && (report.configHash == null || digest.matches(report.configHash)) &&
            (report.configHash != null || report.state == RuntimeState.CONFIG_UNAVAILABLE) &&
            (report.version == null || (report.version.length in 1..64 &&
                report.version.all { it.isLetterOrDigit() || it in ".-_+ " })) &&
            report.versionCode >= 0 && report.hookCount in 0..512 && report.deliveryFailures in 0..MAX_COUNT &&
            report.actions.all { id -> target.actions.any { it.id == id && it.available } } &&
            report.boundaries.size <= MAX_BOUNDARIES && report.boundaries.all { (key, value) ->
                key.length in 1..240 && identifier.matches(key) && value.calls in 0..MAX_COUNT &&
                    value.errors in 0..value.calls
            } && report.netcutSignals.values.all { it in 0..MAX_COUNT } &&
            (report.netcutSignals.isEmpty() || (target.id == "netcut" && "premium" in report.actions)) &&
            (report.state == RuntimeState.INSTALLED ||
                (report.hookCount == 0 && report.boundaries.isEmpty() && report.netcutSignals.isEmpty()))
    }

    fun encode(report: RuntimeReport): String {
        require(valid(report))
        val boundaries = JSONObject()
        report.boundaries.toSortedMap().forEach { (key, value) ->
            boundaries.put(key, JSONArray().put(value.calls).put(value.errors))
        }
        val signals = JSONObject()
        report.netcutSignals.entries.sortedBy { it.key.name }.forEach { (key, value) -> signals.put(key.name, value) }
        return JSONObject().put("schema", SCHEMA).put("target", report.target).put("session", report.session)
            .put("started", report.startedElapsed).put("sequence", report.sequence).put("module", report.moduleCode)
            .put("config", report.configHash ?: JSONObject.NULL).put("state", report.state.name)
            .put("failure", report.failure.name).put("version", report.version ?: JSONObject.NULL)
            .put("code", report.versionCode).put("build", report.build?.name ?: JSONObject.NULL)
            .put("actions", JSONArray(report.actions.sorted())).put("hooks", report.hookCount)
            .put("observed", report.observationComplete).put("deliveryFailures", report.deliveryFailures)
            .put("boundaries", boundaries).put("netcutSignals", signals).toString()
            .also { require(it.toByteArray(Charsets.UTF_8).size <= MAX_BYTES) }
    }

    fun decode(text: String): RuntimeReport {
        require(text.length <= MAX_BYTES && text.toByteArray(Charsets.UTF_8).size <= MAX_BYTES)
        val json = JSONObject(text)
        require(json.getInt("schema") == SCHEMA)
        val actions = json.getJSONArray("actions")
        require(actions.length() <= 32)
        val counts = json.getJSONObject("boundaries")
        require(counts.length() <= MAX_BOUNDARIES)
        // Schema-1 revision-12 reports have no signal field and remain readable.
        val signals = if (json.has("netcutSignals")) json.getJSONObject("netcutSignals") else JSONObject()
        require(signals.length() <= NetcutSignal.entries.size)
        fun optional(key: String) = if (json.isNull(key)) null else json.getString(key)
        return RuntimeReport(json.getString("target"), json.getString("session"), json.getLong("started"),
            json.getLong("sequence"), json.getInt("module"), optional("config"),
            RuntimeState.valueOf(json.getString("state")), RuntimeFailure.valueOf(json.getString("failure")),
            optional("version"), json.getLong("code"), optional("build")?.let(BuildMatch::valueOf),
            (0 until actions.length()).map { actions.getString(it) }.toSet(), json.getInt("hooks"),
            json.getBoolean("observed"), json.getLong("deliveryFailures"), counts.keys().asSequence().associate { key ->
                val pair = counts.getJSONArray(key)
                require(pair.length() == 2)
                key to BoundaryCount(pair.getLong(0), pair.getLong(1))
            }, signals.keys().asSequence().associate { key -> NetcutSignal.valueOf(key) to signals.getLong(key) })
            .also { require(valid(it)) }
    }
}

object RuntimePolicy {
    fun canRead(callerUid: Int, managerUid: Int) = callerUid == managerUid
    fun canPublish(callerUid: Int, managerUid: Int, packages: Set<String>, target: Profile): Boolean =
        callerUid != managerUid && packages == setOf(target.packageName)

    fun fresh(stored: StoredRuntime, boot: Int, elapsed: Long): Boolean =
        boot >= 0 && stored.boot == boot && elapsed >= stored.receivedElapsed &&
            elapsed - stored.receivedElapsed <= RuntimeProtocol.STALE_MS

    fun accept(previous: StoredRuntime?, next: RuntimeReport, boot: Int, elapsed: Long): Boolean {
        if (!RuntimeProtocol.valid(next) || next.startedElapsed > elapsed) return false
        if (previous == null || previous.boot != boot || previous.receivedElapsed > elapsed) return true
        if (elapsed - previous.receivedElapsed < 1000) return false
        val old = previous.report
        if (next.session != old.session) return next.startedElapsed > old.startedElapsed
        return next.startedElapsed == old.startedElapsed && next.configHash == old.configHash &&
            next.moduleCode == old.moduleCode && next.actions == old.actions && next.sequence > old.sequence &&
            (old.state == RuntimeState.STARTING || next.state == old.state) &&
            next.deliveryFailures >= old.deliveryFailures && next.boundaries.all { (key, value) ->
                val before = old.boundaries[key] ?: BoundaryCount()
                value.calls >= before.calls && value.errors >= before.errors
            } && next.netcutSignals.all { (key, value) -> value >= (old.netcutSignals[key] ?: 0L) } &&
            (next.state != RuntimeState.INSTALLED ||
                (next.boundaries.keys.containsAll(old.boundaries.keys) && next.netcutSignals.keys.containsAll(old.netcutSignals.keys)))
    }
}
