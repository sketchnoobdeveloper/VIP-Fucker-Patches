package snd.vip.fucker.core

import org.json.JSONObject
import java.io.File
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipFile

/** Immutable, single-target configuration embedded in the module, not target assets. */
object NonRootConfig {
    const val ASSET = "assets/vip-fucker/nonroot-config.json"
    const val MAX_BYTES = 65536
    data class Read(val present: Boolean, val config: Config? = null, val originalSha256: String? = null)

    fun parse(text: String, target: Profile): Config {
        require(text.toByteArray(Charsets.UTF_8).size <= MAX_BYTES)
        val json = JSONObject(text)
        val schema = json.get("schema")
        require(schema is Int && schema in 1..2)
        require(json.keys().asSequence().toSet() == if (schema == 1) setOf("schema", "package", "config")
            else setOf("schema", "package", "config", "originalSha256"))
        if (schema == 2) require(Regex("[0-9a-f]{64}").matches(json.getString("originalSha256")))
        require(json.getString("package") == target.packageName)
        val config = ConfigJson.parse(json.getJSONObject("config").toString())
        require(config.values.keys.all { it.startsWith("${target.id}.") })
        return config
    }

    fun read(modulePath: String?, target: Profile): Read {
        if (modulePath == null) return Read(false)
        return try {
            ZipFile(File(modulePath)).use { zip ->
                val entries = zip.entries().asSequence().filter { it.name == ASSET }.toList()
                if (entries.isEmpty()) return Read(false)
                require(entries.size == 1 && !entries.single().isDirectory)
                val entry = entries.single()
                require(entry.size in 0..MAX_BYTES.toLong())
                val bytes = zip.getInputStream(entry).use { input ->
                    val out = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(4096)
                    while (out.size() <= MAX_BYTES) {
                        val count = input.read(buffer, 0, minOf(buffer.size, MAX_BYTES + 1 - out.size()))
                        if (count < 0) break
                        out.write(buffer, 0, count)
                    }
                    require(out.size() <= MAX_BYTES)
                    out.toByteArray()
                }
                val text = Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(java.nio.ByteBuffer.wrap(bytes)).toString()
                val config = parse(text, target)
                Read(true, config, JSONObject(text).optString("originalSha256").takeIf { it.isNotEmpty() })
            }
        } catch (_: Exception) {
            // An unreadable/invalid embedded configuration must never fall back to live settings.
            Read(true)
        }
    }
}

object ConfigDeliveryPolicy {
    fun canSave(shared: Boolean, preparingNonRoot: Boolean) = shared || preparingNonRoot
    fun canConfigure(active: Boolean, preparingNonRoot: Boolean) = active || preparingNonRoot
}
