package snd.vip.fucker.core

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

object LauncherVisibility {
    const val ALIAS = "snd.vip.fucker.ui.LauncherAlias"
    fun visible(context: Context): Boolean = context.packageManager.getComponentEnabledSetting(
        ComponentName(context, ALIAS)) !in setOf(PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
        PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER, PackageManager.COMPONENT_ENABLED_STATE_DISABLED_UNTIL_USED)

    fun setVisible(context: Context, visible: Boolean): Boolean = runCatching {
        context.packageManager.setComponentEnabledSetting(ComponentName(context, ALIAS),
            if (visible) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP)
        visible(context) == visible
    }.getOrDefault(false)
}
