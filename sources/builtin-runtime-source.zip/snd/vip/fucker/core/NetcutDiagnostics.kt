package snd.vip.fucker.core

/** Fixed categories only; never retain speed values, message payloads or account data. */
enum class NetcutSignal {
    PRO_TRUE, PRO_FALSE, PRO_ERROR, TOTAL_SPEED_UI, TOTAL_SPEED_REQUEST,
    TOTAL_SPEED_ERROR, IPC_PRO_WARNING, IPC_TOTAL_SPEED_UPDATE, IPC_PRO_DIVERTED,
    PROBE_ERROR,
}

object NetcutDiagnostics {
    fun proResult(result: Any?, threw: Boolean): NetcutSignal = when {
        threw -> NetcutSignal.PRO_ERROR
        result == true -> NetcutSignal.PRO_TRUE
        result == false -> NetcutSignal.PRO_FALSE
        else -> NetcutSignal.PRO_ERROR
    }

    // These are ID-value IDs inside IPC type 6, not account IPC type 14.
    fun incoming(id: Int): NetcutSignal? = when (id) {
        14 -> NetcutSignal.IPC_PRO_WARNING
        13 -> NetcutSignal.IPC_TOTAL_SPEED_UPDATE
        else -> null
    }

    /** ID 14 diverted to the harmless default case because Java Pro was true. */
    fun diverted(): NetcutSignal = NetcutSignal.IPC_PRO_DIVERTED
}