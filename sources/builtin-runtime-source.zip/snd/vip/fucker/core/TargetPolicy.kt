package snd.vip.fucker.core

enum class BuildMatch { VERIFIED, VERSION_MISMATCH, SPLIT, APK_MISMATCH, INSPECTION_FAILED, UNVERIFIED_CLIENT }

object TargetPolicy {
    fun inspect(profile: Profile, code: Long, name: String?, sha256: String?, hasSplits: Boolean): BuildMatch = when {
        !profile.hasReference -> BuildMatch.UNVERIFIED_CLIENT
        !profile.accepts(code, name) -> BuildMatch.VERSION_MISMATCH
        hasSplits -> BuildMatch.SPLIT
        sha256 == null -> BuildMatch.INSPECTION_FAILED
        sha256 != profile.apkSha256 -> BuildMatch.APK_MISMATCH
        else -> BuildMatch.VERIFIED
    }

    /** Unknown builds require an explicit opt-in; selectors are still checked at installation. */
    fun mayAttempt(profile: Profile, match: BuildMatch?, allowUnverified: Boolean): Boolean =
        profile.runnable && match != null && ((profile.hasReference && match == BuildMatch.VERIFIED) || allowUnverified)
}
