package snd.vip.fucker.core

enum class Support { EXPERIMENTAL, PENDING }

data class Action(val id: String, val title: String, val detail: String, val available: Boolean = true)
data class Profile(
    val id: String, val title: String, val packageName: String, val support: Support,
    val detail: String, val actions: List<Action>, val versionCode: Long? = null,
    val versionName: String? = null, val apkSha256: String? = null,
    val source: String = "Local APK analysis",
    val hookFamily: String = id,
    val rootPatchAsset: String? = null,
    val directPatchAsset: String? = null,
    val rootWrapperSupported: Boolean = false,
) {
    val hasReference get() = apkSha256 != null && versionCode != null && versionName != null
    val runnable get() = support == Support.EXPERIMENTAL && (hasReference || hookFamily == "telegram")
    val wrapperSupported get() = runnable && (rootPatchAsset == null || rootWrapperSupported)
    fun accepts(code: Long, name: String?) = runnable && hasReference && code == versionCode && name == versionName
}

object Profiles {
    val categories = listOf(
        Profile("telegram", "Telegram", "org.telegram.messenger.web", Support.EXPERIMENTAL,
            "Reference: Telegram web 13.1.0. Other builds require explicit experimental selector mode.",
            listOf(
                Action("premium", "Premium features", "Local current-account gates only."),
                Action("sponsored", "Remove sponsor trackers", "Known sponsored requests only."),
                Action("proxy", "Remove proxy sponsor", "Suppress verified promo check."),
                Action("download", "Download speed boost", "Experimental large-file request tuning."),
                Action("ghost", "Ghost Mode", "Known read receipts and typing; not total invisibility."),
                Action("icon", "Premium app icon", "Independent local icon-selection gate."),
                Action("translation", "Real-Time Translation", "Independent local eligibility gate; native settings and server authorization remain."),
                Action("emoji", "Profile Emoji View (Client)", "Existing emoji rendering is native; a custom client preview needs clarified intent.", false),
                Action("wallpaper", "Premium wallpaper", "Independent local apply-to-peer gate; server and channel boost checks remain."),
                Action("screenshot", "Allow screenshots", "Also exposes passcode screens and recent-app previews."),
                Action("secret", "Disable secret-media limits", "Lifecycle not safely verified.", false),
                Action("save", "Disable save restrictions", "Local chat no-forwards gate only."),
                Action("updates", "Disable update check", "Disable the verified in-app update check and cached update presentation."),
                Action("timed", "Disable timed photos", "Displayed time is not expiry prevention.", false),
                Action("deleted", "Anti-deleted messages", "Database/UI consistency not verified.", false),
                Action("stories", "Watch stories anonymously", "Suppress known outgoing story-read request."),
                Action("access", "Bypass chat access blocks", "Suppress local restriction-reason gates; not server bans or membership checks.")),
            72299, "13.1.0", "4c122bca5edb997e38fc65360c33e6e726e6f1b31ba23987df0adad0e323a9d8"),
        Profile("tm", "TM Tunnel", "dev.tmsoft.tmtunnelvpn", Support.EXPERIMENTAL,
            "2.7 (27): retained local timer/ad control. Stored balance and server policy unchanged.",
            listOf(Action("timer", "Unlimited time · local timer", "Known expiry callbacks and connection timer; real stored balance unchanged."),
                Action("ads", "Disable ads", "Known app/Google ad requests and banners; unknown ad paths may remain.")),
            27, "2.7", "3efbdbbcb35ccaa43d80a11f3412aeca2fd94591e4d5fd0487270c4bab7043c0"),
        Profile("idm", "1DM", IdmPolicy.PACKAGE, Support.EXPERIMENTAL,
            "Reference: 1DM 20.0 (30257). Other builds require explicit experimental selector mode; future versions are not guaranteed.",
            listOf(
                Action("ads", "Ads", "Disable known SDK ads; unknown ad paths may remain."),
                Action("trackers", "Trackers", "Reduce advertising IDs and install-referrer collection, and suppress FCM; not all network tracking."),
                Action("banners", "Ad Banners", "Hide quiz/Get 1DM+, drawer upgrade and sale promotions.")),
            30257, "20.0", "fa91a96d414428237b2ac3b7229c65bffd058d0484b51ca5e1d5f4867e6b9cc5"),
        Profile("netcut", "Arcai.com's NetCut", NetcutPolicy.PACKAGE, Support.EXPERIMENTAL,
            "Reference: NetCut 1.7.9 (179). Local Pro, ad requests and expiry override; native/server entitlement unverified.",
            listOf(
                Action("premium", "Pro/Premium · local gates", "Known local Pro checks and Pro ad visibility; native controls are not guaranteed."),
                Action("ads", "Disable ads", "Block known Google/Smaato ad requests and hide their banner views."),
                Action("expiry", "Lifetime · local expiry", "Override decoded Java expiry state; no server lifetime membership is granted."),
                Action("subscription", "Paid subscription · unavailable", "A paid server/native account is not granted by these hooks.", false)),
            NetcutPolicy.VERSION_CODE, NetcutPolicy.VERSION_NAME, NetcutPolicy.APK_SHA256),
        Profile("capcut", "CapCut", "com.lemon.lvoverseas", Support.EXPERIMENTAL,
            "19.9.0 (19901600): five local VIP getter results only. Root/Non-Root declarations available; device features and server entitlement unverified.",
            listOf(
                Action("premium", "Pro Unlock", "Five successful local VIP getter results only; original execution, exceptions and server authorization unchanged."),
                Action("effects", "All Effects", "No all-effects patch implemented; availability and downloads unverified.", false),
                Action("templates", "Templates · Use & Edit", "No template patch implemented; loading and editing unverified.", false),
                Action("exports", "Unlimited Exports · No Login", "No guest-export patch implemented; repeated export without login unverified.", false),
                Action("network", "Network Fix", "No network fix implemented; server availability unverified.", false),
                Action("email", "Email Login", "No login patch implemented; original authentication must remain genuine.", false),
                Action("watermark", "No Watermark", "No watermark-removal patch implemented; actual exported media unverified.", false)),
            19901600, "19.9.0", "c6d8a8a3b22102f7b53a3b231ca0c933911afc071f2629987a7b03c7043a354f",
            rootPatchAsset = "root-patches/capcut-19.9.0-local-vip.root",
            rootWrapperSupported = true),
        Profile("ridmik", "Ridmik Keyboard", "ridmik.keyboard", Support.EXPERIMENTAL,
            "19.1.2 (329): two local subscription getters only; token/billing/server authorization unchanged.",
            listOf(Action("premium", "Subscription · local gate", "Successful local subscription getter results only."),
                Action("ai", "AI subscription · local gate", "Successful local preference getter only; server AI access not granted.")),
            329, "19.1.2", "8d1a7802a8f059736301b9ca5d615ab6dab512a132f2662ebba5ae74d0881d7f",
            rootPatchAsset = "root-patches/ridmik-19.1.2-local-subscription.root",
            rootWrapperSupported = true),
        Profile("background_run", "Background Run", "com.shiyunjin.backgroundrun", Support.EXPERIMENTAL,
            "2.3 (150): ten scoped local has_pro readers; no purchases/native/server entitlement.",
            listOf(Action("premium", "Pro · local reads", "Scoped successful has_pro reads only; restart required.")),
            150, "2.3", "a416526a5996f6f8e92d773daf5a63accec6d3f0441fd024436199a7a0917082",
            rootPatchAsset = "root-patches/background-run-2.3-local-pro.root",
            rootWrapperSupported = true),
    )
    val telegramClients = listOf(categories.first().copy(title = "Telegram Web")) +
        TelegramClients.known.map { client -> categories.first().copy(
            id = client.id, title = client.title, packageName = client.packageName,
            detail = "Known client package; explicit experimental selector mode required. No reference APK verified.",
            versionCode = null, versionName = null, apkSha256 = null, source = client.source,
        ) }
    val all = telegramClients + categories.filter { it.hookFamily != "telegram" }
    fun byId(id: String) = all.singleOrNull { it.id == id }
    fun byPackage(name: String) = all.singleOrNull { it.packageName == name }
}

data class Config(val values: Map<String, Boolean> = emptyMap()) {
    fun allowUnverified(profile: Profile) = profile.runnable && values["${profile.id}.allow_unverified"] == true
    fun enabled(profile: Profile) = profile.runnable && values["${profile.id}.enabled"] == true
    fun action(profile: Profile, action: Action) = enabled(profile) && action.available &&
        values["${profile.id}.${action.id}"] == true
    fun requiresHooks(profile: Profile) = enabled(profile) &&
        (profile.hookFamily == "idm" || profile.actions.any { action(profile, it) })
    companion object {
        const val SCHEMA = 2
        const val PREFS = "features_v2"
        const val MODULE = "snd.vip.fucker"
        val keys get() = Profiles.all.flatMap { p ->
            listOf("${p.id}.enabled", "${p.id}.allow_unverified") + p.actions.map { "${p.id}.${it.id}" }
        }.toSet()
        fun validate(values: Map<String, Any?>): Config? {
            if (values.keys.any { it !in keys } || values.values.any { it !is Boolean }) return null
            if (Profiles.all.any { p ->
                (!p.runnable && values["${p.id}.enabled"] == true) || p.actions.any {
                    !it.available && values["${p.id}.${it.id}"] == true
                }
            }) return null
            return Config(values.mapValues { it.value as Boolean })
        }
    }
}
