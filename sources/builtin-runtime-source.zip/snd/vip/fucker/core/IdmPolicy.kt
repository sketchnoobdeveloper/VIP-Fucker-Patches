package snd.vip.fucker.core

object IdmPolicy {
    const val PACKAGE = "idm.internet.download.manager"
    const val FINGERPRINT = "68:A6:70:60:C1:C3:CA:6D:C5:F3:41:24:1B:6E:9E:04:AD:77:FE:E5"

    // App-local fingerprint helper only; other packages retain their actual fingerprint.
    fun fingerprint(packageName: String?): String? = if (packageName == PACKAGE) FINGERPRINT else null

    // Existing provider declarations in the 20.0 reference APK, guide section 6.
    // Unity's AdsSdkInitializer is child metadata, not a provider to block wholesale.
    val adProviders = setOf(
        "com.google.android.gms.ads.MobileAdsInitProvider",
        "com.applovin.sdk.AppLovinInitProvider",
        "io.bidmachine.BidMachineInitProvider",
        "com.vungle.ads.VungleProvider",
        "com.mobilefuse.sdk.MobileFuseSdkInitProvider",
        "com.yandex.mobile.ads.core.initializer.YandexAdsInitializeProvider",
        "com.my.target.common.MyTargetContentProvider",
        "com.taurusx.tax.core.TaurusXProvider",
        "com.ironsource.lifecycle.IronsourceLifecycleProvider",
        "com.ironsource.lifecycle.LevelPlayActivityLifecycleProvider",
        "com.smaato.sdk.core.lifecycle.ProcessLifecycleOwnerInitializer",
        "com.mbridge.msdk.config.component.status.MBComponentLifecycleProvider",
        "sg.bigo.ads.controller.provider.BigoAdsProvider",
    )
    val trackerProviders = setOf(
        "io.appmetrica.analytics.internal.PreloadInfoContentProvider",
        "io.sentry.ndk.SentryNdkPreloadProvider",
    )
    // Keep FirebaseInitProvider so explicit FirebaseMessaging.getInstance() calls still work.
    // FCM auto-init, registration, topics and delivery are suppressed by API hooks instead.

    fun blockedProviders(ads: Boolean, trackers: Boolean): Set<String> =
        (if (ads) adProviders else emptySet()) + (if (trackers) trackerProviders else emptySet())
}
