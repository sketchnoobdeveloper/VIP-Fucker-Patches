package snd.vip.fucker.core

/** Public project links supplied by the developer; opening uses the system browser/app handler. */
object CommunityLinks {
    const val TELEGRAM = "https://t.me/VIPFuckerOfficial"
    const val YOUTUBE = "https://youtube.com/@sketchnoobdeveloper"
}
