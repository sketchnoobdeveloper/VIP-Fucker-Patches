package snd.vip.fucker.core

import android.content.Context
import android.content.SharedPreferences
import android.annotation.SuppressLint

@SuppressLint("WorldReadableFiles") // LSPosed API-93 documented switch sharing; never stores secrets.
class ConfigStore {
    val shared: Boolean
    val preparingNonRoot: Boolean
    val canSave get() = ConfigDeliveryPolicy.canSave(shared, preparingNonRoot)
    val warning: String?
    private val prefs: SharedPreferences
    constructor(context: Context) {
        preparingNonRoot = context.getSharedPreferences("delivery", Context.MODE_PRIVATE)
            .getBoolean("prepare_nonroot", false)
        if (preparingNonRoot) {
            // Separate draft/export storage; never overwrites the rooted manager configuration.
            prefs = context.getSharedPreferences(Config.PREFS + "_nonroot", Context.MODE_PRIVATE)
            shared = false
            warning = null
            return
        }
        // LSPosed API-93 new XSharedPreferences grants this mode only to modules.
        var readable = true
        var error: String? = null
        prefs = try {
            @Suppress("DEPRECATION")
            context.getSharedPreferences(Config.PREFS, Context.MODE_WORLD_READABLE)
        } catch (_: SecurityException) {
            readable = false
            error = context.getString(snd.vip.fucker.R.string.sharing_unavailable)
            context.getSharedPreferences(Config.PREFS, Context.MODE_PRIVATE)
        }
        shared = readable
        warning = error
    }
    internal constructor(preferences: SharedPreferences) {
        prefs = preferences
        shared = true
        preparingNonRoot = false
        warning = null
    }
    fun load(): Config = runCatching {
        if (prefs.getInt("schema", 0) != Config.SCHEMA) return Config()
        Config.validate(prefs.all.filterKeys { it != "schema" }) ?: Config()
    }.getOrDefault(Config())

    @Synchronized fun save(config: Config): Boolean {
        if (Config.validate(config.values) == null) return false
        val previous = prefs.all.toMap()
        val edit = prefs.edit().clear().putInt("schema", Config.SCHEMA)
        config.values.forEach { (key, value) -> edit.putBoolean(key, value) }
        if (runCatching { edit.commit() }.getOrDefault(false)) return true
        // SharedPreferences changes its in-memory map even when disk commit fails.
        // Restore the previous snapshot, not just the UI's saved-state variable.
        runCatching {
            val rollback = prefs.edit().clear()
            previous.forEach { (key, value) -> when (value) {
                is Boolean -> rollback.putBoolean(key, value)
                is Int -> rollback.putInt(key, value)
                is Long -> rollback.putLong(key, value)
                is Float -> rollback.putFloat(key, value)
                is String -> rollback.putString(key, value)
                is Set<*> -> rollback.putStringSet(key, value.filterIsInstance<String>().toSet())
            } }
            rollback.commit()
        }
        return false
    }

    fun export(config: Config): String = ConfigJson.export(config)
    fun parse(text: String): Config = ConfigJson.parse(text)

    companion object {
        fun setPreparation(preferences: SharedPreferences, enabled: Boolean): Boolean {
            val previous = preferences.getBoolean("prepare_nonroot", false)
            if (runCatching { preferences.edit().putBoolean("prepare_nonroot", enabled).commit() }.getOrDefault(false)) return true
            // A failed commit may already have mutated the in-memory preference map.
            runCatching { preferences.edit().putBoolean("prepare_nonroot", previous).commit() }
            return false
        }
    }
}
