package snd.vip.fucker.core

import android.content.Context
import android.os.Build
import android.graphics.Bitmap
import android.graphics.Canvas
import java.io.File

data class InstalledApp(val version: String?, val code: Long, val apkPath: String,
    val icon: Bitmap? = null, val match: BuildMatch? = null, val hasSplits: Boolean = false,
    val sha256: String? = null) {
    val digestMatches get() = match == BuildMatch.VERIFIED
}
fun installedApp(context: Context, profile: Profile, inspectForUi: Boolean = false): InstalledApp? = runCatching {
    @Suppress("DEPRECATION")
    val info = context.packageManager.getPackageInfo(profile.packageName, 0)
    @Suppress("DEPRECATION")
    val code = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
    val path = requireNotNull(info.applicationInfo).sourceDir
    val hasSplits = !info.applicationInfo?.splitSourceDirs.isNullOrEmpty()
    val icon = if (inspectForUi) runCatching {
        val drawable = context.packageManager.getApplicationIcon(profile.packageName)
        Bitmap.createBitmap(144, 144, Bitmap.Config.ARGB_8888).also {
            drawable.setBounds(0, 0, 144, 144)
            drawable.draw(Canvas(it))
        }
    }.getOrNull() else null
    val digest = if (inspectForUi && profile.hasReference) runCatching { ArtifactIdentity.sha256(File(path)) }.getOrNull() else null
    val match = if (inspectForUi) TargetPolicy.inspect(profile, code, info.versionName, digest, hasSplits) else null
    InstalledApp(info.versionName, code, path, icon, match, hasSplits, digest)
}.getOrNull()

object Activation {
    @JvmStatic fun isActive(): Boolean = false // Only LSPosed replaces this method in the manager process.
}
