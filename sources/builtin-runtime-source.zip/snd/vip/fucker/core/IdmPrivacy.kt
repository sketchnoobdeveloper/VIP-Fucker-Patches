package snd.vip.fucker.core

/** Only called inside the verified idm_check form-building method, not on download URLs. */
object IdmPrivacy {
    fun scrubForm(form: String): String = form.split('&').joinToString("&") { part ->
        val key = part.substringBefore('=')
        if (key in setOf("did", "ref_l") && '=' in part) "$key=" else part
    }
}
