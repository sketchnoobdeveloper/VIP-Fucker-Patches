package snd.vip.fucker.core

object AppLanguage {
    val supported = listOf("en", "bn")
    fun normalize(tag: String?) = if (tag == "bn") "bn" else "en"
}
