package snd.vip.fucker.core

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Manager-only state, separate from shared hook settings and their Save/Discard draft. */
class ClientSelectionStore internal constructor(private val prefs: SharedPreferences) {
    constructor(context: Context) : this(context.getSharedPreferences("telegram_selection", Context.MODE_PRIVATE))

    private val knownIds = Profiles.telegramClients.map { it.id }.toSet()

    fun load(config: Config): ClientSelectionState = runCatching {
        val text = prefs.getString(KEY, null) ?: return ClientSelection.initial(config)
        require(text.length <= 4096)
        val json = JSONObject(text)
        val mode = ClientSelectionMode.valueOf(json.getString("mode"))
        val ids = json.getJSONArray("clients")
        require(ids.length() <= knownIds.size)
        val selected = (0 until ids.length()).map { ids.getString(it) }.filter { it in knownIds }.distinct()
        ClientSelectionState(mode, if (mode == ClientSelectionMode.SINGLE) selected.take(1) else selected)
    }.getOrElse { ClientSelection.initial(config) }

    @Synchronized fun save(selection: ClientSelectionState): Boolean {
        if (selection.selected.any { it !in knownIds } || selection.selected != selection.selected.distinct() ||
            (selection.mode == ClientSelectionMode.SINGLE && selection.selected.size > 1)) return false
        val previous = prefs.getString(KEY, null)
        val text = JSONObject().put("mode", selection.mode.name).put("clients", JSONArray(selection.selected)).toString()
        if (runCatching { prefs.edit().putString(KEY, text).commit() }.getOrDefault(false)) return true
        // A failed disk commit still mutates SharedPreferences memory. Restore the last snapshot.
        runCatching {
            val rollback = prefs.edit()
            if (previous == null) rollback.remove(KEY) else rollback.putString(KEY, previous)
            rollback.commit()
        }
        return false
    }

    private companion object { const val KEY = "selection" }
}
