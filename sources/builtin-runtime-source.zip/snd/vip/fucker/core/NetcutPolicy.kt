package snd.vip.fucker.core

/** App-local controls; no purchase, login, outgoing IPC or native-engine changes. */
object NetcutPolicy {
    const val PACKAGE = "com.arcai.netcut"
    const val VERSION_CODE = 179L
    const val VERSION_NAME = "1.7.9"
    const val APK_SHA256 = "8a501a8c4e7a66fdea5d55973599df8f91944b292cb48b51c932bb4c13bf7a1a"
    data class Predicate(val owner: String, val name: String, val value: Boolean)
    data class AdBoundary(val owner: String, val name: String, val returns: String,
        val args: List<String> = emptyList(), val value: Any? = null, val static: Boolean = false)

    private val supported = setOf("premium", "ads", "expiry")

    private val localPro = listOf(
        Predicate("com.arcai.netcut.JNetCutDriver2", "GetIsPro", true),
        Predicate("com.arcai.netcut.JNetCutDriver", "GetIsPro", true),
        Predicate("com.arcai.netcut.UI.MainActivityTabLayout", "bShowAd", false),
    )

    private val adRequests = listOf(
        AdBoundary("com.arcai.netcut.UI.MainActivityTabLayout", "requestNewInterstitial", "void"),
        AdBoundary("com.arcai.netcut.UI.MainActivity2", "requestNewInterstitial", "void"),
        AdBoundary("com.arcai.netcut.UI.JSettingDlg", "requestNewInterstitial", "void"),
        AdBoundary("com.google.android.gms.ads.MobileAds", "initialize", "void", listOf("android.content.Context", "java.lang.String"), static = true),
        AdBoundary("com.google.android.gms.ads.AdView", "loadAd", "void", listOf("com.google.android.gms.ads.AdRequest")),
        AdBoundary("com.google.android.gms.ads.BaseAdView", "loadAd", "void", listOf("com.google.android.gms.ads.AdRequest")),
        AdBoundary("com.google.android.gms.ads.InterstitialAd", "loadAd", "void", listOf("com.google.android.gms.ads.AdRequest")),
        AdBoundary("com.google.android.gms.ads.InterstitialAd", "show", "void"),
        AdBoundary("com.google.android.gms.ads.InterstitialAd", "isLoaded", "boolean", value = false),
        AdBoundary("com.smaato.soma.BaseView", "asyncLoadNewBanner", "void"),
        AdBoundary("com.smaato.soma.internal.requests.AdDownloader", "asyncLoadNewBanner", "void"),
        AdBoundary("com.smaato.soma.internal.requests.AdDownloader", "asyncLoadNewBanner", "boolean", listOf("com.smaato.soma.AdSettings", "com.smaato.soma.internal.requests.settings.UserSettings"), value = false),
    )

    private fun validate(actions: Set<String>) {
        require(actions.all { it in supported }) { "Unsupported NetCut action" }
    }

    fun predicates(actions: Set<String>): List<Predicate> {
        validate(actions)
        return when {
            "premium" in actions -> localPro
            "ads" in actions -> localPro.filter { it.name == "bShowAd" }
            else -> emptyList()
        }
    }

    fun ads(actions: Set<String>): List<AdBoundary> {
        validate(actions)
        return if ("ads" in actions) adRequests else emptyList()
    }

    fun expiry(actions: Set<String>): Boolean {
        validate(actions)
        return "expiry" in actions
    }
}
