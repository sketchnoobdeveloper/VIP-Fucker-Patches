package snd.vip.fucker.core

import org.json.JSONObject

object ConfigJson {
    fun export(config: Config): String {
        require(Config.validate(config.values) != null)
        return JSONObject().put("schema", Config.SCHEMA).put("values", JSONObject(config.values)).toString(2)
    }
    fun parse(text: String): Config {
        require(text.toByteArray(Charsets.UTF_8).size <= 65536) { "Config 64 KiB-er beshi." }
        val root = JSONObject(text)
        require(root.keys().asSequence().toSet() == setOf("schema", "values")) { "Unknown config format." }
        require(root.get("schema") is Int && root.getInt("schema") == Config.SCHEMA) { "Schema mismatch." }
        val values = root.getJSONObject("values")
        return requireNotNull(Config.validate(values.keys().asSequence().associateWith { values.get(it) })) {
            "Unknown key/type ba pending action enable kora hoyeche. Import rejected."
        }
    }
}
